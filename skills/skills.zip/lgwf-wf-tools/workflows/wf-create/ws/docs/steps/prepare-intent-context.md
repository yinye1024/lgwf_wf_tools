# prepare-intent-context

- `step_slug`: `prepare-intent-context`
- `step_name`: 意图上下文整理

## goal

把用户原始任务意图、目标 package 路径约束和 `lgwf-wf-tools` 接管边界整理成可复用的结构化上下文，供后续候选 workflow 发现阶段直接消费。

## inputs

- 用户原始任务意图与补充说明。
- 已确认业务流中的阶段 `intent_intake_and_scope_alignment`、节点 `collect-user-intent`、`normalize-package-constraints`、`capture-handoff-boundaries`。
- `scaffold_plan.target_package_root=skills/lgwf-wf-thinking`。
- `scaffold_plan.package_profile=skill_wrapped_workflow`，目标是独立 Codex skill package。
- `scaffold_template_spec.md` 中关于 `wf/` 为唯一 workflow root、`ws/.lgwf` 为运行状态边界、禁止绝对路径与 `..` 的约束。
- `create-workflow.md` 中关于资源路径、workflow root、子 workflow 拆分和中文文档默认规范。

## outputs

- 面向下游步骤的结构化任务上下文，至少包含业务目标、目标 package 约束、approval 边界和 will-not-do 边界。
- 为后续 `discover-workflow-capabilities` 提供的输入摘要，例如候选 workflow 检索条件和禁止越权说明。
- 对目标初稿范围的说明：当前 workflow 只产出编排方案与 handoff，不直接替代后续执行 workflow。

## dependencies

- 无上游步骤依赖，但依赖已确认的 `business_flow.json` 和现有 `scaffold_plan` 约束。
- 产物会被 `discover-workflow-capabilities` 直接消费。
- 本步骤不经过人工确认；人工确认点从 `compose-plan-proposal` 开始。

## implementation_suggestions

- 建议在目标 package 的 `wf/02_confirm_requirements/00_collect_raw_intent/` 内保留单一职责的收集与归一化节点，不把后续能力发现逻辑混入此阶段。
- 归一化结果建议落到稳定的状态对象，字段至少覆盖 `task_goal`、`target_package_root`、`approval_boundaries`、`monitoring_boundaries`、`will_not_do`。
- 若需要补充说明文档，优先放在 `wf/02_confirm_requirements/resources/`，不要把运行时状态写入 package 根目录。

## acceptance_notes

- 必须明确这是独立 Codex skill package：根目录必须生成 `SKILL.md` 和 `agents/openai.yaml`，内置 workflow 入口是 `wf/workflow.lgwf`。
- 必须明确后续真实运行和 approval 仍由 `lgwf-wf-tools` 接管，当前步骤只做上下文归一化。
- 如果用户原始意图未明确 workflow 清单读取入口，可将该项作为待确认信息记录，但不能虚构固定实现。

## out_of_scope

- 不生成候选 workflow 清单。
- 不启动 `lgwf-wf-tools`、`lgwf-wf-prompt-fix` 或任何真实 workflow run。
- 不承诺端到端执行成功，不实现自动修复链路。
