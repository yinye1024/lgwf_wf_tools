# discover-workflow-capabilities

- `step_slug`: `discover-workflow-capabilities`
- `step_name`: 候选 workflow 能力发现

## goal

读取可用 LGWF workflow 清单及职责摘要，筛选与用户目标相关的候选能力，并形成可供编排方案阶段使用的能力地图。

## inputs

- 上一步 `prepare-intent-context` 产出的归一化任务上下文。
- 已确认业务流中的阶段 `workflow_capability_discovery`、节点 `read-workflow-registry`、`classify-capabilities`、`filter-relevant-workflows`。
- `scaffold_plan.derived_from_business_flow` 中对应阶段映射。
- `create-workflow.md` 中关于普通 step 与子 workflow 责任拆分、相对路径引用和不保存运行态到 package 的约束。
- `workflow-audit-checklist.md` 中关于 workflow 结构、资源引用和父子 workflow 边界的验收规则。

## outputs

- 候选 workflows 分类结果，至少包含 workflow 标识、职责摘要、适用理由、排除理由和组合位置建议。
- 供 `compose-plan-proposal` 使用的能力地图，明确哪些 workflow 可用于方案生成、哪些仅作为后续建议。
- 对 workflow 清单读取入口的说明，例如来自 registry、脚本输出或等价接口的读取方式。

## dependencies

- 依赖 `prepare-intent-context` 先完成并提供筛选条件。
- 产物被 `compose-plan-proposal` 直接消费。
- 本步骤无独立人工确认，但其发现结果会影响后续方案确认内容。

## implementation_suggestions

- 建议在目标 package 的 `wf/04_confirm_business_flow/03_propose_business_flow_react/` 或相邻普通 step 中完成候选能力读取与分类，不要把这一阶段扩展为独立大子 workflow，除非后续需要复用或独立审计。
- 能力地图建议以结构化 JSON 或 Markdown 摘要形式输出，并明确记录来源，避免后续 handoff 阶段重复猜测。
- 如果读取入口本身存在不确定性，输出中应保留待确认字段，而不是硬编码某一实现。

## acceptance_notes

- 必须把“适用理由”和“排除理由”同时写清，避免只列出候选而没有过滤依据。
- 必须体现当前 workflow 只做能力发现和方案编排，不直接代表用户运行这些候选 workflow。
- 发现结果不能与 `lgwf-wf-tools` 的 approval、monitoring、run-handle 边界冲突。

## out_of_scope

- 不生成最终 composition plan。
- 不写目标 package 初稿文件。
- 不调用 `lgwf-wf-tools`、`lgwf-wf-prompt-fix` 或自动修复能力。
