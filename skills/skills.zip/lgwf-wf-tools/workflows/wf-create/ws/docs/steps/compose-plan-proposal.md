# compose-plan-proposal

- `step_slug`: `compose-plan-proposal`
- `step_name`: 编排方案草案起草

## goal

基于候选 workflow 能力地图与用户约束，产出可人工确认的 composition plan proposal，明确推荐 workflow 组合、顺序、输入来源、停止条件和 will-not-do。

## inputs

- `discover-workflow-capabilities` 输出的候选 workflows 分类结果与能力地图。
- 已确认业务流中的阶段 `composition_plan_drafting`、节点 `draft-composition-plan`、`state-selection-rationale`、`prepare-tuning-options`。
- `business_flow.json` 中关于该阶段需要人工确认的约束。
- `scaffold_plan.rules.path_policy` 与 `state_boundary`，确保方案不会要求写入根 `.lgwf` 或越出目标 package。
- `create-workflow.md` 中关于 `APPROVAL` 节点、`FLOW { ... }` 集中编排和根 workflow 保持薄编排的规范。

## outputs

- `composition plan proposal`，至少包含推荐 workflow 组合、执行顺序、每一步输入来源、停止条件和不会做的事项。
- 组合理由、风险说明和可调优选项。
- 面向人工确认节点的审阅摘要，便于 `confirm_step_designs` 后续核对该步骤设计是否足以支撑实现。

## dependencies

- 依赖 `discover-workflow-capabilities` 的能力地图。
- 该步骤对应业务流中的人工确认阶段，后续 `package-handoff-instructions` 只能消费已确认或至少可审阅的方案草案。
- 若人工要求修订，应保留 revise 闭环，而不是直接覆盖为最终结论。

## implementation_suggestions

- 建议在目标 package 中把方案起草设计为普通 step 或薄 ReAct 段落，由独立 `APPROVAL` 节点承接确认，不把确认逻辑塞进起草节点内部。
- 输出结构建议同时适合 JSON 结构化消费和中文 Markdown 审阅，但是否双轨输出应在实现时根据确认结果决定。
- 方案必须显式描述“只给 handoff，不直接运行被推荐 workflow”的边界。

## acceptance_notes

- 必须体现推荐顺序、每个候选 workflow 的作用、停止条件与风险。
- 必须保留人工调优入口，不能将组合决策自动 approve。
- 如展示载体尚未最终定稿，可在此记录待确认项，但不得省略核心字段。

## out_of_scope

- 不封装最终 handoff instructions。
- 不生成真实 workflow 运行记录。
- 不负责 `lgwf-wf-prompt-fix`、自动修复和端到端运行保证。
