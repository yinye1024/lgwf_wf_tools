# package-handoff-instructions

- `step_slug`: `package-handoff-instructions`
- `step_name`: 执行移交说明封装

## goal

把已起草的 composition plan 转成面向 `lgwf-wf-tools` 的 handoff instructions 草案，明确目标 workflow、输入来源、approval 边界、监控方式和最小执行步骤。

## inputs

- `compose-plan-proposal` 产出的 composition plan 草案及人工调优结果。
- 已确认业务流中的阶段 `handoff_instruction_packaging`、节点 `map-plan-to-handoff`、`declare-approval-boundaries`、`package-execution-guidance`。
- `lgwf-wf-tools` 的接管边界：approval、monitoring、run-handle 不得绕过。
- `scaffold_plan.target_package_root`、`package_profile`、`rules.state_boundary`。
- `create-workflow.md` 中关于普通 step、子 workflow、`APPROVAL` 路由和资源相对路径的规范。

## outputs

- handoff instructions 草案，至少包含目标 workflow、输入来源、approval 边界、监控方式、最小执行步骤和输出约定。
- 面向后续包骨架生成阶段的结构化约束，确保脚手架不会偏离移交边界。
- 供人工确认的边界提醒和风险说明。

## dependencies

- 依赖 `compose-plan-proposal` 已经形成可审阅方案。
- 该步骤本身属于人工确认相关阶段，后续 `scaffold-thinking-package` 应只消费已确认的 handoff 结构。
- 若 handoff 边界不清，应在本阶段停住并回到 revise，而不是把不确定内容向下游传播。

## implementation_suggestions

- 建议把 handoff 说明与方案正文分离，避免把组合设计和执行边界写成同一份难以复审的长文。
- 目标 package 内可通过独立普通 step 负责封装 handoff 草案，并把人工确认留给后继确认节点。
- 输出字段建议稳定覆盖 `target_workflow`、`input_sources`、`approval_boundaries`、`monitoring_expectations`、`minimum_execution_steps`、`will_not_do`。

## acceptance_notes

- 必须清楚说明当前 workflow 不越权直接运行后续 workflow。
- 必须指出最小执行步骤与监控方式，但不能伪装成已经执行过。
- 任何引用的文件、目录和 workflow 路径都必须保持包内相对路径语义，不引入绝对路径或 `..`。

## out_of_scope

- 不生成目标 package 最终源码。
- 不替代 facade 做真实 run、approval 提交或 run record 管理。
- 不覆盖 `lgwf-wf-tools`、`lgwf-wf-prompt-fix` 或自动修复职责。
