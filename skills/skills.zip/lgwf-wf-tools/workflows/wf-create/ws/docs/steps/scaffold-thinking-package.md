# scaffold-thinking-package

- `step_slug`: `scaffold-thinking-package`
- `step_name`: thinking 包初稿脚手架落地

## goal

在已确认的 composition plan 与 handoff instructions 基础上，按 `scaffold_plan` 生成 `lgwf-wf-thinking` 的第一版 package 初稿结构、工作流骨架和中文文档占位。

## inputs

- 已确认的 composition plan。
- 已确认的 handoff instructions。
- 已确认业务流中的阶段 `package_initialization_scaffold`、节点 `scaffold-package-layout`、`materialize-workflow-entry`、`write-human-readable-artifacts`。
- `scaffold_plan` 全量约束：
  - `target_package_root=skills/lgwf-wf-thinking`
  - `package_profile=skill_wrapped_workflow`
  - `create_dirs`、`create_files`、`placeholders`
  - `rules.path_policy` 与 `rules.state_boundary`
- `scaffold_template_spec.md` 中关于 `wf/` 为唯一 workflow root、根目录禁止 `workflow.lgwf`、`skill_wrapped_workflow` 必须生成根 `SKILL.md`、状态只写 `ws/.lgwf` 的要求。
- `create-workflow.md` 与 `workflow-audit-checklist.md` 中关于薄根 workflow、子 workflow 拆分、`FLOW { ... }`、审计规则和资源引用的要求。

## outputs

- 目标 package 初稿目录与文件骨架，覆盖 `SKILL.md`、`agents/openai.yaml`、`AGENTS.md`、`README.md`、`wf/workflow.lgwf`、各阶段 workflow、必要脚本与测试占位。
- 与当前步骤设计对应的 `wf/docs/steps/` 占位或同步落位方案，供实现阶段写入正式设计/说明。
- 中文文档、prompt、报告模板等面向人的初稿占位，且全部保持 UTF-8。

## dependencies

- 依赖 `package-handoff-instructions` 提供已确认的移交结构。
- 这是最后一个实现导向步骤，下游只剩总结与报告，不再重新设计业务流。
- 如果上游方案或 handoff 仍未确认，不得提前创建会固化业务决策的文件内容。

## implementation_suggestions

- 根 `wf/workflow.lgwf` 只保留阶段编排骨架，阶段细节拆到 `wf/02_confirm_requirements/`、`wf/04_confirm_business_flow/`、`wf/07_confirm_step_designs/`、`wf/09_summarize_create_result/` 等子 workflow。
- `07_confirm_step_designs` 只负责步骤设计确认与实现衔接；可复用或需单独审计的复杂阶段继续拆分为子 workflow，不把多阶段逻辑压进单个大文件。
- `tests/test_scaffold_package_rules.py` 至少覆盖路径规则、关键文件存在性和状态边界。
- 文档与 prompt 以中文为默认正文语言，脚本与 DSL 保持现有英文标识符。

## acceptance_notes

- 必须完全遵循 `create_dirs` 与 `create_files` 清单，生成根 `SKILL.md`、`agents/openai.yaml`、`AGENTS.md` 与 `README.md`，但不生成根 `workflow.lgwf` 或根 `.lgwf`。
- 必须保证所有 `workflow.lgwf`、`PROMPT`、`SCRIPT`、`CONTEXT` 路径是包内相对路径。
- 必须保持 `ws` 仅作为 work dir，运行状态只写入 `ws/.lgwf`。
- 若某些 prompt、报告字段或 README 细节仍待补充，可保留占位，但不能违背脚手架规则与业务阶段边界。

## out_of_scope

- 不接入 `lgwf-wf-tools` registry 或其他 facade 路由。
- 不自动调用 `lgwf-wf-prompt-fix` 或补 E2E 测试。
- 不承诺端到端业务 happy path 成功，也不提供自动修复链路。
