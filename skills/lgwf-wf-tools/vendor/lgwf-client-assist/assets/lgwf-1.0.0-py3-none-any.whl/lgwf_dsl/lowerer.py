import itertools
import contextlib
import pathlib
from typing import Any

import lgwf_dsl.ast as ast_module
import lgwf_dsl.parser as parser_module
import lgwf_dsl.statements.agent_loop as agent_loop_statement_module
import lgwf_dsl.statements.choice as choice_statement_module
import lgwf_dsl.statements.foreach as foreach_statement_module
import lgwf_dsl.statements.parallel as parallel_statement_module
import lgwf_dsl.statements.react as react_statement_module
import lgwf_dsl.statements.run_workflow as run_workflow_statement_module
import lgwf_dsl.statements.sandbox as sandbox_statement_module
import lgwf_dsl.validator as validator_module


class WorkflowLowerer:
    def lower(
        self,
        ast: ast_module.WorkflowAst,
        package_root: str | pathlib.Path | None = None,
    ) -> dict[str, Any]:
        previous_root = getattr(self, "_workflow_package_root", None)
        previous_source_dir = getattr(self, "_workflow_source_dir", None)
        previous_source_path = getattr(self, "_workflow_source_path", None)
        previous_stack = getattr(self, "_workflow_ref_stack", None)
        previous_instruction_prefix = getattr(self, "_instruction_path_prefix", None)
        if previous_instruction_prefix is None:
            self._instruction_path_prefix = ""
        if previous_root is None:
            self._workflow_package_root = self._resolve_package_root(ast.source_name, package_root)
            self._workflow_ref_stack = []
            if ast.source_name is not None:
                self._workflow_ref_stack.append(self._resolve_source_path(ast.source_name))
        elif package_root is not None and pathlib.Path(package_root).resolve() != previous_root:
            raise ValueError("Nested workflow compilation cannot change package_root.")
        self._workflow_source_dir = self._source_dir(ast.source_name)
        self._workflow_source_path = self._source_path(ast.source_name)
        try:
            return self._lower_with_root(ast)
        finally:
            if previous_root is None:
                delattr(self, "_workflow_package_root")
                delattr(self, "_workflow_source_dir")
                delattr(self, "_workflow_source_path")
                delattr(self, "_workflow_ref_stack")
            else:
                self._workflow_package_root = previous_root
                self._workflow_source_dir = previous_source_dir
                self._workflow_source_path = previous_source_path
                self._workflow_ref_stack = previous_stack
            if previous_instruction_prefix is None:
                delattr(self, "_instruction_path_prefix")
            else:
                self._instruction_path_prefix = previous_instruction_prefix

    def _lower_with_root(self, ast: ast_module.WorkflowAst) -> dict[str, Any]:
        defaults = self._defaults(ast)
        context_sets = self._context_sets(ast)
        flow_aliases = self._flow_aliases(ast)
        nodes = []
        edges = []
        routes = []

        for statement in ast.statements:
            if isinstance(statement, ast_module.PythonDecl):
                nodes.append(self._lower_python(statement, defaults))
            elif isinstance(statement, ast_module.ToolDecl):
                nodes.append(self._lower_tool(statement, defaults))
            elif isinstance(statement, ast_module.CodexDecl):
                nodes.append(self._lower_codex(statement, defaults, context_sets))
            elif isinstance(statement, ast_module.ApprovalDecl):
                nodes.append(self._lower_approval(statement, defaults))
                if statement.routes:
                    routes.append({"from": statement.id, "branches": self._resolve_route_targets(statement.routes, flow_aliases)})
            elif isinstance(statement, ast_module.ReviewDecl):
                nodes.append(self._lower_review(statement, defaults))
                if statement.routes:
                    routes.append({"from": statement.id, "branches": self._resolve_route_targets(statement.routes, flow_aliases)})
            elif isinstance(statement, ast_module.ChoiceDecl):
                nodes.append(self._lower_choice(statement, defaults))
                if statement.routes:
                    routes.append({"from": statement.id, "branches": self._resolve_route_targets(statement.routes, flow_aliases)})
            elif isinstance(statement, ast_module.HandoffDecl):
                nodes.append(self._lower_handoff(statement, defaults))
            elif isinstance(statement, ast_module.HandoffFilesDecl):
                nodes.append(self._lower_handoff_files(statement))
            elif isinstance(statement, ast_module.RunWorkflowDecl):
                nodes.append(self._lower_run_workflow(statement))
            elif isinstance(statement, ast_module.ForeachDecl):
                nodes.append(self._lower_foreach(statement))
            elif isinstance(statement, ast_module.ReactDecl):
                nodes.append(self._lower_react(statement, defaults, context_sets))
            elif isinstance(statement, ast_module.AgentLoopDecl):
                nodes.append(self._lower_agent_loop(statement, defaults, context_sets))
            elif isinstance(statement, ast_module.WorkflowRefDecl):
                nodes.append(self._lower_workflow_ref(statement))
            elif isinstance(statement, ast_module.ParallelDecl):
                nodes.append(self._lower_parallel(statement, defaults, context_sets))
            elif isinstance(statement, ast_module.EdgeDecl):
                edges.append([statement.from_node, statement.to_node])
            elif isinstance(statement, ast_module.FlowDecl):
                for from_node, to_node in itertools.pairwise(statement.nodes):
                    edges.append([from_node, to_node])
            elif isinstance(statement, ast_module.RouteDecl):
                routes.append({"from": statement.from_node, "branches": self._resolve_route_targets(statement.branches, flow_aliases)})
            elif isinstance(statement, ast_module.SwitchRouteDecl):
                nodes.append(self._lower_switch_route(statement))
                routes.append({"from": statement.id, "branches": self._resolve_route_targets(statement.branches, flow_aliases)})

        workflow = {
            "nodes": nodes,
            "edges": edges,
            "routes": routes,
            "entry_point": self._resolve_entry_point(ast, flow_aliases),
        }
        if ast.sandbox is not None:
            workflow = self._wrap_sandbox(ast, workflow)
        self._deduplicate_instruction_paths(workflow)
        return workflow

    def _wrap_sandbox(self, ast: ast_module.WorkflowAst, workflow: dict[str, Any]) -> dict[str, Any]:
        return sandbox_statement_module.wrap_sandbox(ast, workflow)

    def _resolve_package_root(
        self,
        source_name: str | None,
        package_root: str | pathlib.Path | None,
    ) -> pathlib.Path:
        if package_root is not None:
            return pathlib.Path(package_root).resolve()
        if source_name is None:
            return pathlib.Path(".").resolve()
        return pathlib.Path(source_name).resolve().parent

    def _resolve_source_path(self, source_name: str) -> pathlib.Path:
        source_path = pathlib.Path(source_name)
        if source_path.is_absolute():
            return source_path.resolve()
        return (pathlib.Path(self._workflow_package_root) / source_path).resolve()

    def _source_path(self, source_name: str | None) -> pathlib.Path | None:
        if source_name is None:
            return None
        return self._resolve_source_path(source_name)

    def _source_dir(self, source_name: str | None) -> pathlib.Path:
        root = pathlib.Path(self._workflow_package_root).resolve()
        if source_name is None:
            return root
        source_path = self._resolve_source_path(source_name)
        if not source_path.is_relative_to(root):
            raise ValueError("Workflow source must stay within package_root.")
        return source_path.parent

    def _current_workflow_key(self) -> str:
        source_path = getattr(self, "_workflow_source_path", None)
        if source_path is None:
            return "__dynamic__"
        root = pathlib.Path(self._workflow_package_root).resolve()
        try:
            return source_path.relative_to(root).as_posix()
        except ValueError:
            return str(source_path)

    def _defaults(self, ast: ast_module.WorkflowAst) -> ast_module.DefaultsDecl:
        defaults = ast_module.DefaultsDecl()
        for statement in ast.statements:
            if isinstance(statement, ast_module.DefaultsDecl):
                defaults = statement
        return defaults

    def _context_sets(self, ast: ast_module.WorkflowAst) -> dict[str, ast_module.ContextSetDecl]:
        return {
            statement.name: statement
            for statement in ast.statements
            if isinstance(statement, ast_module.ContextSetDecl)
        }

    def _flow_aliases(self, ast: ast_module.WorkflowAst) -> dict[str, str]:
        return {
            statement.name: statement.nodes[0]
            for statement in ast.statements
            if isinstance(statement, ast_module.FlowDecl) and statement.name is not None
        }

    def _resolve_entry_point(self, ast: ast_module.WorkflowAst, flow_aliases: dict[str, str]) -> str:
        if ast.entry_kind == "FLOW":
            return flow_aliases[ast.entry_point]
        if ast.entry_kind == "NODE":
            return ast.entry_point
        return flow_aliases.get(ast.entry_point, ast.entry_point)

    def _resolve_route_targets(self, branches: dict[str, str], flow_aliases: dict[str, str]) -> dict[str, str]:
        return {
            route_key: flow_aliases.get(target, target)
            for route_key, target in branches.items()
        }

    def _lower_python(self, task: ast_module.PythonDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        config = {
            "script_ref": {"path": self._lower_task_resource_path(task.script_path, "SCRIPT", defaults)},
            "timeout_seconds": self._resolve_timeout_seconds(
                task.timeout_seconds,
                task.timeout_unlimited,
                defaults.timeout_seconds,
                inherit_defaults=True,
            ),
            "instruction_path": self._instruction_path_or_default(task.instruction_path, defaults, task.id),
            "result_path": self._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
            "ref_root": self._lower_ref_root(defaults.ref_root),
        }
        if task.updates_state:
            config["state_updates_from_stdout"] = True
            if task.state_update_writes:
                config["state_update_paths"] = [write.path for write in task.state_update_writes]
        if task.input_path is not None:
            config["input_path"] = task.input_path.path
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "exec.run_python",
            "config": config,
        }

    def _lower_codex(
        self,
        task: ast_module.CodexDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> dict[str, Any]:
        config = {
            "prompt_ref": {"path": self._lower_task_resource_path(task.prompt_path, "PROMPT", defaults)},
            "context_refs": self._lower_context_refs(task.contexts, context_sets),
            "timeout_seconds": self._resolve_timeout_seconds(
                task.timeout_seconds,
                task.timeout_unlimited,
                defaults.timeout_seconds,
                inherit_defaults=True,
            ),
            "instruction_path": self._instruction_path_or_default(task.instruction_path, defaults, task.id),
            "result_path": self._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
            "ref_root": self._lower_ref_root(defaults.ref_root),
        }
        if task.target_dirs:
            config["target_dirs"] = list(task.target_dirs)
        if task.target_files:
            config["target_files"] = list(task.target_files)
        if task.target_dirs_path is not None:
            config["target_dirs_path"] = task.target_dirs_path.path
        if task.target_files_path is not None:
            config["target_files_path"] = task.target_files_path.path
        if task.edit_dirs:
            config["edit_dirs"] = list(task.edit_dirs)
        if task.edit_dirs_path is not None:
            config["edit_dirs_path"] = task.edit_dirs_path.path
        if task.edit_files:
            config["edit_files"] = list(task.edit_files)
        if task.edit_files_path is not None:
            config["edit_files_path"] = task.edit_files_path.path
        if task.output_json_path is not None:
            output_json_config = {
                "path": self._validate_relative_path(task.output_json_path, "OUTPUT_JSON").as_posix()
            }
            if task.output_json_mode is not None:
                if task.output_json_mode != "file":
                    raise ValueError("OUTPUT_JSON mode must be 'file'.")
                output_json_config["mode"] = task.output_json_mode
            config["output_json"] = output_json_config
        if task.output_file_path is not None:
            config["output_file"] = {
                "path": self._validate_relative_path(task.output_file_path, "OUTPUT_FILE").as_posix()
            }
        if task.model is not None:
            config["model"] = task.model
        elif task.model_alias is not None:
            config["model_alias"] = task.model_alias
        elif defaults.codex_model is not None:
            config["model"] = defaults.codex_model
        if defaults.model_aliases:
            config["model_aliases"] = {
                alias: dict(override)
                for alias, override in defaults.model_aliases.items()
            }
        if task.plugins_enabled:
            config["plugins_enabled"] = True
        if task.keep_session:
            if task.keep_session_key is not None:
                config["session"] = {
                    "enabled": True,
                    "scope": "work_dir_key",
                    "key": task.keep_session_key,
                }
            else:
                config["session"] = {
                    "enabled": True,
                    "scope": "node_run",
                }
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "exec.codex_prompt",
            "config": config,
        }

    def _lower_tool(self, task: ast_module.ToolDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        config = {
            "tool": task.tool_name,
            "options": task.options,
            "timeout_seconds": self._resolve_timeout_seconds(
                task.timeout_seconds,
                task.timeout_unlimited,
                defaults.timeout_seconds,
                inherit_defaults=True,
            ),
            "result_path": self._state_path_or_default(
                task.result_path,
                defaults.result_path_template,
                task.id,
            ),
        }
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "exec.run_tool",
            "config": config,
        }

    def _lower_approval(self, task: ast_module.ApprovalDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        config = {
            "context_path": task.read_path.path,
            "approved_value_path": task.write_path.path,
            "result_path": self._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
            "timeout_seconds": self._resolve_timeout_seconds(
                task.timeout_seconds,
                task.timeout_unlimited,
                defaults.timeout_seconds,
                inherit_defaults=False,
            ),
        }
        if task.prompt is not None:
            config["prompt"] = task.prompt
        elif task.prompt_ref_path is not None:
            config["prompt_ref"] = {
                "root": "workflow",
                "path": self._package_relative_path(task.prompt_ref_path, "PROMPT_REF"),
            }
        if task.persist_path is not None:
            config["persist_value_path"] = task.persist_path
        if task.route_on_decision:
            config["route_on_decision"] = True
        if task.poll_interval_seconds is not None:
            config["poll_interval_seconds"] = task.poll_interval_seconds
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "flow.human_approval",
            "config": config,
        }

    def _lower_review(self, task: ast_module.ReviewDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        config = {
            "context_path": task.context_path.path,
            "prompt_ref": {
                "root": "workflow",
                "path": self._package_relative_path(task.prompt_ref_path, "PROMPT"),
            },
            "result_path": self._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
            "options": list(task.options),
            **({"persist_value_path": task.persist_path} if task.persist_path is not None else {}),
        }
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "flow.human_review",
            "config": config,
        }

    def _lower_choice(self, task: ast_module.ChoiceDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        return choice_statement_module.lower_choice(self, task, defaults)

    def _lower_switch_route(self, task: ast_module.SwitchRouteDecl) -> dict[str, Any]:
        default = "default"
        if "false" in task.branches:
            default = "false"
        elif task.branches:
            default = next(iter(task.branches))
        return {
            "id": task.id,
            "capability": "flow.switch",
            "config": {
                "path": task.read_path.path,
                "default": default,
            },
        }

    def _lower_handoff(self, task: ast_module.HandoffDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
        config = {
            "context_path": task.context_path.path,
            "prompt_ref": {
                "root": "workflow",
                "path": self._package_relative_path(task.prompt_ref_path, "PROMPT"),
            },
            "result_path": self._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
            "agent_instruction": "handle_handoff",
            "auto_execute": False,
            "wait_for_continue": task.continue_after_ack,
        }
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "flow.handoff",
            "config": config,
        }

    def _lower_handoff_files(self, task: ast_module.HandoffFilesDecl) -> dict[str, Any]:
        items: list[dict[str, str]] = []
        for item in task.items:
            self._validate_relative_path(item.source, "HANDOFF_FILES source")
            self._validate_relative_path(item.target, "HANDOFF_FILES target")
            lowered_item = {
                "kind": item.kind,
                "source": item.source,
                "target": item.target,
            }
            if item.field is not None:
                lowered_item["field"] = item.field
            items.append(lowered_item)
        config: dict[str, Any] = {
            "source_path": task.source_path.path,
            "items": items,
            "result_path": task.result_path.path,
        }
        self._attach_contract(config, task.contract)
        return {
            "id": task.id,
            "capability": "flow.handoff_files",
            "config": config,
        }

    def _lower_run_workflow(self, task: ast_module.RunWorkflowDecl) -> dict[str, Any]:
        return run_workflow_statement_module.lower_run_workflow(self, task)

    def _lower_foreach(self, task: ast_module.ForeachDecl) -> dict[str, Any]:
        return foreach_statement_module.lower_foreach(self, task)

    def _lower_react(
        self,
        react: ast_module.ReactDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> dict[str, Any]:
        return react_statement_module.lower_react(self, react, defaults, context_sets)

    def _lower_agent_loop(
        self,
        loop: ast_module.AgentLoopDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> dict[str, Any]:
        return agent_loop_statement_module.lower_agent_loop(self, loop, defaults, context_sets)

    def _lower_agent_loop_slot_task(
        self,
        task: ast_module.NoopDecl | ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
        loop_context_refs: list[dict[str, str]],
    ) -> dict[str, Any]:
        return agent_loop_statement_module.lower_agent_loop_slot_task(
            self,
            task,
            defaults,
            context_sets,
            loop_context_refs,
        )

    def _lower_parallel(
        self,
        parallel: ast_module.ParallelDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> dict[str, Any]:
        return parallel_statement_module.lower_parallel(self, parallel, defaults, context_sets)

    def _lower_parallel_step(
        self,
        step: ast_module.ParallelStepDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> dict[str, Any]:
        return parallel_statement_module.lower_parallel_step(self, step, defaults, context_sets)

    def _lower_workflow_ref(
        self,
        ref: ast_module.WorkflowRefDecl,
    ) -> dict[str, Any]:
        source_path = self._resolve_workflow_ref(ref.workflow_path)
        stack = self._workflow_ref_stack
        if source_path in stack:
            cycle_start = stack.index(source_path)
            cycle = stack[cycle_start:] + [source_path]
            chain = " -> ".join(self._display_workflow_path(path) for path in cycle)
            raise ValueError(f"Workflow reference cycle: {chain}")

        text = source_path.read_text(encoding="utf-8")
        ast = parser_module.Parser.from_text(text, source_name=str(source_path)).parse_workflow()
        validator_module.WorkflowValidator().validate(ast)
        stack.append(source_path)
        try:
            with self._instruction_path_scope(ref.id):
                workflow = self.lower(ast)
        finally:
            stack.pop()
        config: dict[str, Any] = {"workflow": workflow}
        if ref.result_path is not None:
            config["result_path"] = ref.result_path.path
        self._attach_contract(config, ref.contract)
        return {
            "id": ref.id,
            "capability": "subgraph.workflow",
            "config": config,
        }

    def _resolve_workflow_ref(self, workflow_path: str) -> pathlib.Path:
        ref_path = pathlib.Path(workflow_path)
        if self._is_absolute_or_drive_path(workflow_path) or ".." in ref_path.parts:
            raise ValueError("STEP WORKFLOW path must be relative and must not contain '..'.")
        if ref_path.suffix.lower() != ".lgwf":
            raise ValueError("STEP WORKFLOW path must reference a .lgwf file.")
        root = getattr(self, "_workflow_package_root", None)
        if root is None:
            root = pathlib.Path(".").resolve()
        root = pathlib.Path(root).resolve()
        source_path = (pathlib.Path(self._workflow_source_dir) / ref_path).resolve()
        if not source_path.is_relative_to(root):
            raise ValueError("STEP WORKFLOW path must stay within the workflow package root.")
        if not source_path.is_file():
            raise FileNotFoundError(f"Referenced workflow not found: {source_path}")
        return source_path

    def _validate_external_workflow_path(self, workflow_path: str) -> None:
        path = pathlib.Path(workflow_path)
        if self._is_absolute_or_drive_path(workflow_path) or ".." in path.parts:
            raise ValueError("RUN_WORKFLOW WORKFLOW path must be relative and must not contain '..'.")
        if path.suffix.lower() != ".lgwf":
            raise ValueError("RUN_WORKFLOW WORKFLOW path must reference a .lgwf file.")

    def _display_workflow_path(self, path: pathlib.Path) -> str:
        root = pathlib.Path(self._workflow_package_root).resolve()
        try:
            return path.relative_to(root).as_posix()
        except ValueError:
            return str(path)

    def _lower_context_refs(
        self,
        contexts: list[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[dict[str, str]]:
        refs = []
        for context in contexts:
            if context.resource is not None:
                refs.append(self._lower_resource_ref(context.resource))
            elif context.context_set is not None:
                for resource in self._context_set_resources(context.context_set, context_sets):
                    refs.append(self._lower_resource_ref(resource))
        return refs

    def _context_set_resources(
        self,
        name: str,
        context_sets: dict[str, ast_module.ContextSetDecl],
        stack: tuple[str, ...] = (),
    ) -> list[ast_module.ResourceRef]:
        if name not in context_sets:
            return []
        if name in stack:
            chain = " -> ".join((*stack, name))
            raise ValueError(f"Context set inheritance cycle: {chain}")
        context_set = context_sets[name]
        resources: list[ast_module.ResourceRef] = []
        for parent in context_set.extends:
            resources.extend(self._context_set_resources(parent, context_sets, (*stack, name)))
        resources.extend(context_set.resources)
        return resources

    def _attach_contract(
        self,
        config: dict[str, Any],
        contract: ast_module.ContractDecl | None,
    ) -> None:
        if contract is None:
            return
        config["contract"] = self._lower_contract(contract)

    def _lower_contract(self, contract: ast_module.ContractDecl) -> dict[str, Any]:
        return {
            "reads_state": [item.path for item in contract.reads_state],
            "writes_state": [item.path for item in contract.writes_state],
            "reads_resources": [
                self._lower_resource_ref(resource)
                for resource in contract.reads_resources
            ],
            "writes_resources": [
                self._lower_resource_ref(resource)
                for resource in contract.writes_resources
            ],
        }

    def _lower_resource_ref(self, resource: ast_module.ResourceRef) -> dict[str, str]:
        path = resource.path
        if resource.root == "workflow":
            path = self._package_relative_path(resource.path, "CONTEXT workflow")
        else:
            self._validate_relative_path(resource.path, "CONTEXT workspace")
        return {
            "root": resource.root,
            "path": path,
            "type": resource.type,
        }

    def _lower_task_resource_path(
        self,
        raw_path: str,
        label: str,
        defaults: ast_module.DefaultsDecl,
    ) -> str:
        root_name = defaults.ref_root.get("root")
        if root_name == "workspace":
            self._validate_relative_path(defaults.ref_root.get("path", "."), "ref_root")
            self._validate_relative_path(raw_path, label)
            return raw_path
        if root_name != "workflow":
            raise ValueError("ref_root.root must be one of: workflow, workspace.")

        ref_root_path = defaults.ref_root.get("path", ".")
        self._validate_relative_path(ref_root_path, "ref_root")
        base_dir = (pathlib.Path(self._workflow_source_dir) / ref_root_path).resolve()
        return self._package_relative_path(raw_path, label, base_dir=base_dir)

    def _lower_ref_root(self, ref_root: dict[str, str]) -> dict[str, str]:
        if ref_root.get("root") == "workflow":
            return {"root": "workflow", "path": "."}
        return dict(ref_root)

    def _package_relative_path(
        self,
        raw_path: str,
        label: str,
        base_dir: pathlib.Path | None = None,
    ) -> str:
        path = self._validate_relative_path(raw_path, label)
        root = pathlib.Path(self._workflow_package_root).resolve()
        base = pathlib.Path(base_dir or self._workflow_source_dir).resolve()
        resolved = (base / path).resolve()
        if not resolved.is_relative_to(root):
            raise ValueError(f"{label} path must stay within the workflow package root.")
        return resolved.relative_to(root).as_posix()

    def _validate_relative_path(self, raw_path: str, label: str) -> pathlib.Path:
        path = pathlib.Path(raw_path)
        if self._is_absolute_or_drive_path(raw_path):
            raise ValueError(f"{label} path must be relative.")
        if ".." in path.parts:
            raise ValueError(f"{label} path must not contain '..'.")
        return path

    def _is_absolute_or_drive_path(self, raw_path: str) -> bool:
        return (
            pathlib.PurePosixPath(raw_path.replace("\\", "/")).is_absolute()
            or pathlib.PureWindowsPath(raw_path).is_absolute()
            or bool(pathlib.PureWindowsPath(raw_path).drive)
        )

    def _state_path_or_default(
        self,
        state_ref: ast_module.StateRef | None,
        template: str,
        node_id: str,
    ) -> str:
        if state_ref is not None:
            return state_ref.path
        return template.replace("{node}", node_id)

    def _instruction_path_or_default(
        self,
        state_ref: ast_module.StateRef | None,
        defaults: ast_module.DefaultsDecl,
        node_id: str,
    ) -> str:
        if state_ref is not None:
            return state_ref.path
        return defaults.instruction_path_template.replace("{node}", self._instruction_node_id(node_id))

    def _instruction_node_id(self, node_id: str) -> str:
        prefix = getattr(self, "_instruction_path_prefix", "")
        if not prefix:
            return node_id
        return f"{prefix}__{node_id}"

    @contextlib.contextmanager
    def _instruction_path_scope(self, segment: str):
        previous = getattr(self, "_instruction_path_prefix", "")
        self._instruction_path_prefix = self._join_instruction_segments(previous, segment)
        try:
            yield
        finally:
            self._instruction_path_prefix = previous

    def _join_instruction_segments(self, prefix: str, segment: str) -> str:
        if not prefix:
            return segment
        return f"{prefix}__{segment}"

    def _deduplicate_instruction_paths(self, workflow: dict[str, Any]) -> None:
        used: set[str] = set()
        next_suffix: dict[str, int] = {}
        for config in self._instruction_path_configs(workflow):
            raw_path = config.get("instruction_path")
            if not isinstance(raw_path, str) or not raw_path:
                continue
            if raw_path not in used:
                used.add(raw_path)
                next_suffix.setdefault(raw_path, 2)
                continue
            suffix = next_suffix.get(raw_path, 2)
            while f"{raw_path}__{suffix}" in used:
                suffix += 1
            resolved_path = f"{raw_path}__{suffix}"
            config["instruction_path"] = resolved_path
            used.add(resolved_path)
            next_suffix[raw_path] = suffix + 1

    def _instruction_path_configs(self, value: Any) -> list[dict[str, Any]]:
        configs: list[dict[str, Any]] = []
        if isinstance(value, dict):
            if isinstance(value.get("instruction_path"), str):
                configs.append(value)
            for child in value.values():
                configs.extend(self._instruction_path_configs(child))
        elif isinstance(value, list):
            for child in value:
                configs.extend(self._instruction_path_configs(child))
        return configs

    def _resolve_timeout_seconds(
        self,
        task_timeout: int | None,
        task_unlimited: bool,
        defaults_timeout: int,
        *,
        inherit_defaults: bool,
    ) -> int | None:
        if task_unlimited:
            return None
        if task_timeout is not None:
            return task_timeout
        if inherit_defaults:
            return defaults_timeout
        return None
