import pathlib
from typing import Any

import lgwf.handoff as handoff_module


def submit_main_agent_handoff(
    work_dir: str | pathlib.Path,
    request_id: str,
    *,
    comment: str | None = None,
) -> dict[str, Any]:
    root = pathlib.Path(work_dir).expanduser().resolve()
    result = handoff_module.acknowledge_pending_action(
        root,
        request_id,
        received_by="main_agent",
        comment=comment,
    )
    return {
        "ok": True,
        "request_id": request_id,
        "status": "received",
        "already_received": result["already_received"],
        "continue_required": result["continue_required"],
        "next_action": (
            "complete_handoff_then_continue"
            if result["continue_required"]
            else "workflow_will_continue"
        ),
        "received_path": result["received_path"],
        "work_dir": str(root),
    }


def continue_main_agent_handoff(
    work_dir: str | pathlib.Path,
    request_id: str,
    *,
    comment: str | None = None,
) -> dict[str, Any]:
    root = pathlib.Path(work_dir).expanduser().resolve()
    result = handoff_module.submit_continuation(
        root,
        request_id,
        continued_by="main_agent",
        comment=comment,
    )
    return {
        "ok": True,
        "request_id": request_id,
        "status": "continued",
        "already_continued": result["already_continued"],
        "continued_path": result["continued_path"],
        "work_dir": str(root),
    }
