import io
import json
import pathlib
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.tools.operations as operations_module
import lgwf_dsl.cli as dsl_cli_module


def run(options: dict[str, Any], *, workspace_root: pathlib.Path) -> dict[str, Any]:
    command = options["command"]
    argv = [command]
    raw_input = options.get("input")
    if command != "schema":
        input_path = operations_module.resolve_workspace_path(
            workspace_root,
            raw_input,
            "options.input",
        )
        if not input_path.is_file():
            raise ValueError(f"options.input must be an existing file: {raw_input}")
        argv.append(str(input_path))

    stdout = io.StringIO()
    stderr = io.StringIO()
    exit_code = dsl_cli_module.main(argv, stdout=stdout, stderr=stderr)
    stdout_text = stdout.getvalue()
    stderr_text = stderr.getvalue()
    result: dict[str, Any] = {
        "passed": exit_code == 0,
        "command": command,
        "exit_code": exit_code,
    }
    if isinstance(raw_input, str):
        result["input"] = raw_input
    parsed_output = _parse_json_output(stdout_text)
    if parsed_output is not None:
        result["output"] = parsed_output
    if options.get("include_stdout", False):
        result["stdout"] = stdout_text
    if stderr_text:
        result["stderr"] = stderr_text

    raw_result_path = options.get("result_output_path")
    if isinstance(raw_result_path, str):
        result_path = operations_module.resolve_workspace_path(
            workspace_root,
            raw_result_path,
            "options.result_output_path",
        )
        result["result_output_path"] = raw_result_path
        file_ops_module.write_json_atomic(result_path, result, sort_keys=False)

    if exit_code != 0 and options.get("fail_on_command_failure", True):
        detail = stderr_text.strip() or stdout_text.strip() or "no diagnostics"
        raise RuntimeError(f"lgwf_dsl {command} failed with exit code {exit_code}: {detail}")
    return result


def _parse_json_output(stdout: str) -> Any | None:
    if not stdout.strip():
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        return None
