﻿import argparse
from typing import Any

import lgwf_client.json_io as json_io_module
import lgwf_client.commands.common as command_common_module
import lgwf_client.main_agent.approvals as main_agent_approvals_module
import lgwf_client.main_agent.handoffs as main_agent_handoffs_module
import lgwf_client.main_agent.reviews as main_agent_reviews_module
import lgwf_client.main_agent.status as main_agent_status_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    main_agent_status = subparsers.add_parser("get-main-agent-status")
    main_agent_status.add_argument("--work-dir", required=True)
    main_agent_status.add_argument("--pid", type=command_common_module.positive_pid)
    main_agent_status.add_argument("--session-id")
    main_agent_status.set_defaults(handler=handle_get_main_agent_status)

    submit_main_agent = subparsers.add_parser("submit-main-agent-approval")
    submit_main_agent.add_argument("--work-dir", required=True)
    submit_main_agent.add_argument("--request-id", required=True)
    submit_main_agent.add_argument("--decision", choices=["approve", "reject"], required=True)
    submit_main_agent.add_argument("--value-json")
    submit_main_agent.add_argument("--comment")
    submit_main_agent.set_defaults(handler=handle_submit_main_agent_approval)

    submit_review = subparsers.add_parser("submit-main-agent-review")
    submit_review.add_argument("--work-dir", required=True)
    submit_review.add_argument("--request-id", required=True)
    submit_review.add_argument("--route", required=True)
    submit_review.add_argument("--value-json")
    submit_review.add_argument("--comment")
    submit_review.set_defaults(handler=handle_submit_main_agent_review)

    submit_handoff = subparsers.add_parser("submit-main-agent-handoff")
    submit_handoff.add_argument("--work-dir", required=True)
    submit_handoff.add_argument("--request-id", required=True)
    submit_handoff.add_argument("--comment")
    submit_handoff.set_defaults(handler=handle_submit_main_agent_handoff)

    continue_handoff = subparsers.add_parser("submit-main-agent-handoff-continue")
    continue_handoff.add_argument("--work-dir", required=True)
    continue_handoff.add_argument("--request-id", required=True)
    continue_handoff.add_argument("--comment")
    continue_handoff.set_defaults(handler=handle_continue_main_agent_handoff)


def handle_get_main_agent_status(args: argparse.Namespace) -> dict[str, Any]:
    return main_agent_status_module.get_main_agent_status(
        command_common_module.resolve_work_dir(args.work_dir),
        pid=args.pid,
        session_id=args.session_id,
    )


def handle_submit_main_agent_approval(args: argparse.Namespace) -> dict[str, Any]:
    value = main_agent_approvals_module.MISSING
    if args.value_json is not None:
        value = json_io_module.parse_json_object(args.value_json, "value-json")
    return main_agent_approvals_module.submit_main_agent_approval(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        decision=args.decision,
        value=value,
        comment=args.comment,
    )


def handle_submit_main_agent_review(args: argparse.Namespace) -> dict[str, Any]:
    value = main_agent_reviews_module.MISSING
    if args.value_json is not None:
        value = json_io_module.parse_json_object(args.value_json, "value-json")
    return main_agent_reviews_module.submit_main_agent_review(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        route=args.route,
        value=value,
        comment=args.comment,
    )


def handle_submit_main_agent_handoff(args: argparse.Namespace) -> dict[str, Any]:
    return main_agent_handoffs_module.submit_main_agent_handoff(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        comment=args.comment,
    )


def handle_continue_main_agent_handoff(args: argparse.Namespace) -> dict[str, Any]:
    return main_agent_handoffs_module.continue_main_agent_handoff(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        comment=args.comment,
    )
