﻿import pathlib
import re
import time
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module
import lgwf_client.types as client_types


def write_live_status(
    cwd: pathlib.Path,
    instruction: client_types.Instruction,
    track_dir: pathlib.Path,
    *,
    status: str,
    live_turn_count: int,
    live_token_usage: dict[str, int],
    reason: str | None = None,
    token_budget: dict[str, Any] | None = None,
) -> None:
    path = workspace_layout_module.codex_status_path(cwd)
    payload: dict[str, Any] = {
        "version": 1,
        "status": status,
        "current_instruction_id": instruction["id"],
        "track_dir": str(track_dir),
        "turn_count": live_turn_count,
        "token_usage": dict(live_token_usage),
        "updated_at_unix": time.time(),
    }
    if reason is not None:
        payload["reason"] = reason
    if token_budget is not None:
        payload["token_budget"] = token_budget
    file_ops_module.write_json_atomic(path, payload, sort_keys=False)


def attach_track_result(
    result: client_types.ExecutionResult,
    track_dir: pathlib.Path,
    prompt_text: str,
    stdout_path: pathlib.Path,
    stderr_path: pathlib.Path,
) -> None:
    result["metadata"]["track_dir"] = str(track_dir)
    result["metadata"]["prompt_transport"] = "stdin"
    result["metadata"]["handoff_prompt_path"] = str(track_dir / "handoff_prompt.txt")
    result["metadata"]["handoff_prompt_bytes"] = len(prompt_text.encode("utf-8"))
    result["metadata"]["track_files"] = {
        "prompt": str(track_dir / "prompt.txt"),
        "handoff_prompt": str(track_dir / "handoff_prompt.txt"),
        "command": str(track_dir / "command.json"),
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
        "metadata": str(track_dir / "metadata.json"),
    }
    result["artifacts"].append(
        {
            "type": "codex_track",
            "path": str(track_dir),
        }
    )


def create_track_dir(cwd: pathlib.Path, instruction_id: str) -> pathlib.Path:
    safe_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", instruction_id).strip("._-")
    if not safe_id:
        safe_id = "codex"
    timestamp = time.strftime("%Y%m%dT%H%M%S")
    track_root = file_ops_module.ensure_dir(workspace_layout_module.codex_dir(cwd))
    for attempt in range(1000):
        suffix = f"{timestamp}-{attempt:03d}"
        path = track_root / f"{safe_id}-{suffix}"
        try:
            path.mkdir()
        except FileExistsError:
            continue
        return path
    raise RuntimeError(f"failed to create Codex track directory under {track_root}")


def write_track_start(
    track_dir: pathlib.Path,
    instruction: client_types.Instruction,
    cwd: pathlib.Path,
    command: list[str],
    prompt_text: str,
    mode: str,
    main_prompt_path: str | None,
    context_paths: list[dict[str, str]],
    target_dirs: list[str],
    target_files: list[str],
    edit_dirs: list[str],
    edit_files: list[str],
    output_json_path: pathlib.Path | None = None,
    output_json_mode: str = "managed",
    output_file_path: pathlib.Path | None = None,
    codex_model: dict[str, Any] | None = None,
    *,
    foreground: bool = False,
    background: bool = True,
) -> None:
    file_ops_module.write_text_atomic(track_dir / "prompt.txt", prompt_text)
    handoff_prompt_path = track_dir / "handoff_prompt.txt"
    file_ops_module.write_text_atomic(handoff_prompt_path, prompt_text)
    write_json(
        track_dir / "command.json",
        {
            "instruction_id": instruction["id"],
            "cwd": str(cwd),
            "command": command,
        },
    )
    write_json(
        track_dir / "metadata.json",
        {
            "instruction_id": instruction["id"],
            "cwd": str(cwd),
            "mode": mode,
            "foreground": foreground,
            "background": background,
            "main_prompt_path": main_prompt_path,
            "context_paths": context_paths,
            "target_dirs": target_dirs,
            "target_files": target_files,
            "edit_dirs": edit_dirs,
            "edit_files": edit_files,
            "output_json": (
                {"path": str(output_json_path), "mode": output_json_mode}
                if output_json_path is not None
                else None
            ),
            "output_file": (
                {"path": str(output_file_path)}
                if output_file_path is not None
                else None
            ),
            "prompt_transport": "stdin",
            "handoff_prompt_path": str(handoff_prompt_path),
            "handoff_prompt_bytes": len(prompt_text.encode("utf-8")),
            "codex_model": dict(codex_model) if codex_model is not None else None,
            "timeout": instruction.get("timeout_seconds"),
            "started_at_unix": time.time(),
            "exit_code": None,
            "timed_out": False,
        },
    )


def write_track_finish(
    track_dir: pathlib.Path,
    instruction: client_types.Instruction,
    cwd: pathlib.Path,
    mode: str,
    returncode: int,
    *,
    timed_out: bool,
    runner_error_type: str | None = None,
    runner_error_message: str | None = None,
    foreground: bool = False,
    background: bool = True,
) -> None:
    metadata_path = track_dir / "metadata.json"
    metadata = read_metadata(metadata_path)
    metadata.update(
        {
            "instruction_id": instruction["id"],
            "cwd": str(cwd),
            "mode": mode,
            "foreground": foreground,
            "background": background,
            "finished_at_unix": time.time(),
            "exit_code": returncode,
            "timed_out": timed_out,
        }
    )
    if runner_error_type is not None:
        metadata["runner_error_type"] = runner_error_type
    if runner_error_message is not None:
        metadata["runner_error_message"] = runner_error_message
        metadata["error_message"] = runner_error_message
    write_json(metadata_path, metadata)


def write_track_token_usage(track_dir: pathlib.Path, token_usage: dict[str, int]) -> None:
    metadata_path = track_dir / "metadata.json"
    metadata = read_metadata(metadata_path)
    metadata["token_usage"] = token_usage
    write_json(metadata_path, metadata)


def write_track_launch_error(
    track_dir: pathlib.Path,
    instruction: client_types.Instruction,
    cwd: pathlib.Path,
    mode: str,
    exc: Exception,
) -> None:
    metadata_path = track_dir / "metadata.json"
    metadata = read_metadata(metadata_path)
    metadata.update(
        {
            "instruction_id": instruction["id"],
            "cwd": str(cwd),
            "mode": mode,
            "foreground": False,
            "background": True,
            "finished_at_unix": time.time(),
            "runner_error_type": "launch_failed",
            "error_message": str(exc),
            "exit_code": None,
            "timed_out": False,
        }
    )
    write_json(metadata_path, metadata)


def read_metadata(metadata_path: pathlib.Path) -> dict[str, Any]:
    if not metadata_path.exists():
        return {}
    try:
        loaded = file_ops_module.read_json(metadata_path)
    except file_ops_module.FileOperationError:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def write_json(path: pathlib.Path, data: dict[str, Any]) -> None:
    file_ops_module.write_json_atomic(path, data)
