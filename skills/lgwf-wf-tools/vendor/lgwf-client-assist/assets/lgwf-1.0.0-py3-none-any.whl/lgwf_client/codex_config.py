﻿import pathlib
import os
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module


DEFAULT_CODEX_MODEL = "gpt-5.5"
DEFAULT_CODEX_REASONING_EFFORT = "medium"
DEFAULT_CODEX_SERVICE_TIER = "default"
DEFAULT_CODEX_MODEL_ALIAS = "model-wolf"
FIXED_MODEL_ALIASES = ("model-tiger", "model-wolf", "model-rabbit")
MODEL_ALIAS_FIELDS = ("model", "model_reasoning_effort", "service_tier")
SUPPORTED_MODELS_FIELD = "supported_models"
CODEX_DEFAULTS_CONFIG_ENV = "LGWF_CODEX_DEFAULTS_CONFIG"
CONFIG_VERSION = 1
DEFAULTS_CONFIG_VERSION = 2
DEFAULT_ON_TOKEN_LIMIT = "warn"
ON_TOKEN_LIMIT_VALUES = {"warn", "fail"}
REASONING_EFFORT_VALUES = {"low", "medium", "high", "xhigh"}
SERVICE_TIER_VALUES = {"default", "priority"}


def get_codex_model(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    default_config = _default_model_config()
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    payload: dict[str, Any] = {
        "model": default_config["model"],
        "model_reasoning_effort": default_config["model_reasoning_effort"],
        "service_tier": default_config["service_tier"],
        "source": default_config["source"],
        "default_model": default_config["model"],
        "default_model_reasoning_effort": default_config["model_reasoning_effort"],
        "default_service_tier": default_config["service_tier"],
        "default_source": default_config["source"],
        "config_path": str(config_path),
    }
    if default_config.get("config_path") is not None:
        payload["default_config_path"] = default_config["config_path"]
    default_model_alias = default_config.get("default_model_alias")
    model_aliases = default_config.get("model_aliases", {})
    if default_model_alias is not None:
        payload["default_model_alias"] = default_model_alias
    payload["available_model_aliases"] = list(model_aliases)
    payload["model_aliases"] = {
        alias: dict(alias_config)
        for alias, alias_config in model_aliases.items()
    }
    supported_models = default_config.get(SUPPORTED_MODELS_FIELD)
    if supported_models is not None:
        payload[SUPPORTED_MODELS_FIELD] = list(supported_models)
    if not config_path.is_file():
        return payload

    config = _read_config(config_path)
    if "model" in config:
        payload["model"] = validate_supported_model(
            _normalize_model(config.get("model")),
            supported_models,
        )
        payload["source"] = "workspace"
    if "model_reasoning_effort" in config:
        payload["model_reasoning_effort"] = _normalize_reasoning_effort(config.get("model_reasoning_effort"))
        payload["model_reasoning_effort_source"] = "workspace"
    if "service_tier" in config:
        payload["service_tier"] = _normalize_service_tier(config.get("service_tier"))
        payload["service_tier_source"] = "workspace"
    return payload


def get_supported_codex_models() -> tuple[str, ...] | None:
    """Return the active package allowlist used by compile- and run-time validation."""

    supported_models = _default_model_config().get(SUPPORTED_MODELS_FIELD)
    return tuple(supported_models) if supported_models is not None else None


def resolve_codex_model(
    workspace_root: str | pathlib.Path,
    *,
    model_alias: Any = None,
    model_aliases: Any = None,
) -> dict[str, Any]:
    """Resolve an alias to a real Codex model configuration.

    Explicit aliases ignore generic work-dir model overrides. When no explicit
    alias is supplied, the package default alias is selected and work-dir
    fields are merged before workflow-level alias overrides.
    """

    normalized_overrides = normalize_model_aliases(model_aliases)
    default_config = _default_model_config()
    global_aliases = default_config.get("model_aliases", {})
    default_alias = default_config.get("default_model_alias")

    if model_alias is not None:
        selected_alias = normalize_model_alias(model_alias)
    else:
        selected_alias = default_alias

    if selected_alias is None:
        if normalized_overrides:
            raise ValueError(
                "Codex defaults config does not define default_model_alias; "
                "workflow model_aliases require a version 2 defaults config."
            )
        return get_codex_model(workspace_root)
    if selected_alias not in global_aliases:
        raise ValueError(f"Codex defaults config is missing global model alias: {selected_alias}.")

    resolved = dict(global_aliases[selected_alias])
    field_sources = {field: "package" for field in MODEL_ALIAS_FIELDS}
    if model_alias is None:
        workspace_config = _read_config(workspace_layout_module.codex_config_path(workspace_root))
        if "model" in workspace_config:
            resolved["model"] = _normalize_model(workspace_config.get("model"))
            field_sources["model"] = "workspace"
        if "model_reasoning_effort" in workspace_config:
            resolved["model_reasoning_effort"] = _normalize_reasoning_effort(
                workspace_config.get("model_reasoning_effort")
            )
            field_sources["model_reasoning_effort"] = "workspace"
        if "service_tier" in workspace_config:
            resolved["service_tier"] = _normalize_service_tier(workspace_config.get("service_tier"))
            field_sources["service_tier"] = "workspace"

    workflow_override = normalized_overrides.get(selected_alias, {})
    for field, value in workflow_override.items():
        resolved[field] = value
        field_sources[field] = "workflow"
    resolved["model"] = validate_supported_model(
        resolved["model"],
        default_config.get(SUPPORTED_MODELS_FIELD),
    )
    return {
        **resolved,
        "model_alias": selected_alias,
        "model_alias_source": "node" if model_alias is not None else "default",
        "field_sources": field_sources,
        SUPPORTED_MODELS_FIELD: default_config.get(SUPPORTED_MODELS_FIELD),
    }


def normalize_model_alias(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("model_alias must be a non-empty string when provided.")
    alias = value.strip()
    if alias not in FIXED_MODEL_ALIASES:
        raise ValueError(
            f"unknown model_alias: {alias}; expected one of {', '.join(FIXED_MODEL_ALIASES)}."
        )
    return alias


def normalize_model_aliases(value: Any) -> dict[str, dict[str, str]]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("model_aliases must be an object when provided.")
    normalized: dict[str, dict[str, str]] = {}
    for raw_alias, raw_override in value.items():
        alias = normalize_model_alias(raw_alias)
        if not isinstance(raw_override, dict):
            raise ValueError(f"model_aliases.{alias} must be an object.")
        if not raw_override:
            raise ValueError(f"model_aliases.{alias} must not be empty.")
        unknown_fields = sorted(set(raw_override) - set(MODEL_ALIAS_FIELDS))
        if unknown_fields:
            raise ValueError(f"unknown model_aliases.{alias} field: {unknown_fields[0]}.")
        override: dict[str, str] = {}
        if "model" in raw_override:
            override["model"] = _validate_model(raw_override["model"])
        if "model_reasoning_effort" in raw_override:
            override["model_reasoning_effort"] = _normalize_reasoning_effort(
                raw_override["model_reasoning_effort"]
            )
        if "service_tier" in raw_override:
            override["service_tier"] = _normalize_service_tier(raw_override["service_tier"])
        normalized[alias] = override
    return normalized


def set_codex_model(workspace_root: str | pathlib.Path, model: str) -> dict[str, Any]:
    default_config = _default_model_config()
    normalized_model = validate_supported_model(
        model,
        default_config.get(SUPPORTED_MODELS_FIELD),
    )
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config["model"] = normalized_model
    _write_config(config_path, config)
    payload = get_codex_model(workspace_root)
    payload["ok"] = True
    return payload


def reset_codex_model(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config.pop("model", None)
    _write_or_remove_config(config_path, config)
    payload = get_codex_model(workspace_root)
    payload["ok"] = True
    return payload


def get_codex_token_limit(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    has_token_max = "token_max" in config
    token_max = _normalize_optional_token_max(config.get("token_max")) if has_token_max else None
    on_token_limit = _normalize_on_token_limit(config.get("on_token_limit", DEFAULT_ON_TOKEN_LIMIT))
    return {
        "token_max": token_max,
        "on_token_limit": on_token_limit,
        "source": "workspace" if has_token_max or "on_token_limit" in config else "default",
        "default_on_token_limit": DEFAULT_ON_TOKEN_LIMIT,
        "config_path": str(config_path),
    }


def set_codex_token_limit(
    workspace_root: str | pathlib.Path,
    *,
    token_max: int,
    on_token_limit: str = "fail",
) -> dict[str, Any]:
    normalized_max = _normalize_token_max(token_max)
    normalized_action = _normalize_on_token_limit(on_token_limit)
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config["token_max"] = normalized_max
    config["on_token_limit"] = normalized_action
    _write_config(config_path, config)
    payload = get_codex_token_limit(workspace_root)
    payload["ok"] = True
    return payload


def reset_codex_token_limit(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config.pop("token_max", None)
    config.pop("on_token_limit", None)
    _write_or_remove_config(config_path, config)
    payload = get_codex_token_limit(workspace_root)
    payload["ok"] = True
    return payload


def _normalize_model(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return _default_model_config()["model"]
    return _validate_model(value)


def _validate_model(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("model must be a non-empty string.")
    model = value.strip()
    if any(char.isspace() for char in model):
        raise ValueError("model must not contain whitespace.")
    return model


def validate_supported_model(value: Any, supported_models: Any) -> str:
    """Validate a real model name against the package allowlist when present."""

    model = _validate_model(value)
    normalized_supported_models = _normalize_supported_models(supported_models)
    if normalized_supported_models is None:
        return model
    if model not in normalized_supported_models:
        supported = ", ".join(normalized_supported_models)
        raise ValueError(
            f"Unsupported Codex model: {model}. Supported models: {supported}."
        )
    return model


def _normalize_supported_models(value: Any) -> tuple[str, ...] | None:
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or not value:
        raise ValueError("Codex defaults config supported_models must be a non-empty array.")
    normalized: list[str] = []
    for raw_model in value:
        model = _validate_model(raw_model)
        if model in normalized:
            raise ValueError(
                f"Codex defaults config supported_models contains duplicate model: {model}."
            )
        normalized.append(model)
    return tuple(normalized)


def _normalize_reasoning_effort(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_REASONING_EFFORT
    if not isinstance(value, str):
        raise ValueError("model_reasoning_effort must be low, medium, high, or xhigh.")
    effort = value.strip().lower()
    if effort not in REASONING_EFFORT_VALUES:
        raise ValueError("model_reasoning_effort must be low, medium, high, or xhigh.")
    return effort


def _normalize_service_tier(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_SERVICE_TIER
    if not isinstance(value, str):
        raise ValueError("service_tier must be default or priority.")
    tier = value.strip().lower()
    if tier not in SERVICE_TIER_VALUES:
        raise ValueError("service_tier must be default or priority.")
    return tier


def _normalize_token_max(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("token_max must be a positive integer.")
    return value


def _normalize_optional_token_max(value: Any) -> int | None:
    if value is None:
        return None
    return _normalize_token_max(value)


def _normalize_on_token_limit(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("on_token_limit must be 'warn' or 'fail'.")
    action = value.strip().lower()
    if action not in ON_TOKEN_LIMIT_VALUES:
        raise ValueError("on_token_limit must be 'warn' or 'fail'.")
    return action


def _read_config(config_path: pathlib.Path) -> dict[str, Any]:
    if not config_path.is_file():
        return {}
    return file_ops_module.read_json_object(config_path, label="Codex config")


def _default_model_config() -> dict[str, Any]:
    config_path = _default_config_path()
    if config_path is None or not config_path.is_file():
        return {
            "model": DEFAULT_CODEX_MODEL,
            "model_reasoning_effort": DEFAULT_CODEX_REASONING_EFFORT,
            "service_tier": DEFAULT_CODEX_SERVICE_TIER,
            "source": "default",
            "config_path": None,
            "default_model_alias": None,
            "model_aliases": {},
            SUPPORTED_MODELS_FIELD: None,
        }
    config = file_ops_module.read_json_object(config_path, label="Codex defaults config")
    if _uses_model_alias_schema(config):
        default_alias, aliases, supported_models = _normalize_global_model_aliases(config)
        selected = aliases[default_alias]
        return {
            **selected,
            "source": "package",
            "config_path": str(config_path),
            "default_model_alias": default_alias,
            "model_aliases": aliases,
            SUPPORTED_MODELS_FIELD: supported_models,
        }
    return {
        "model": _normalize_default_model(config.get("model")),
        "model_reasoning_effort": _normalize_reasoning_effort(config.get("model_reasoning_effort")),
        "service_tier": _normalize_service_tier(config.get("service_tier")),
        "source": "package",
        "config_path": str(config_path),
        "default_model_alias": None,
        "model_aliases": {},
        SUPPORTED_MODELS_FIELD: None,
    }


def _uses_model_alias_schema(config: dict[str, Any]) -> bool:
    return (
        config.get("version") == DEFAULTS_CONFIG_VERSION
        or "default_model_alias" in config
        or "model_aliases" in config
    )


def _normalize_global_model_aliases(
    config: dict[str, Any],
) -> tuple[str, dict[str, dict[str, str]], tuple[str, ...]]:
    if config.get("version") != DEFAULTS_CONFIG_VERSION:
        raise ValueError(
            f"Codex defaults config with model aliases must use version {DEFAULTS_CONFIG_VERSION}."
        )
    raw_aliases = config.get("model_aliases")
    if not isinstance(raw_aliases, dict):
        raise ValueError("Codex defaults config model_aliases must be an object.")
    missing = [alias for alias in FIXED_MODEL_ALIASES if alias not in raw_aliases]
    if missing:
        raise ValueError(f"Codex defaults config is missing global model alias: {missing[0]}.")
    unknown = sorted(set(raw_aliases) - set(FIXED_MODEL_ALIASES))
    if unknown:
        raise ValueError(f"Codex defaults config contains unknown model alias: {unknown[0]}.")

    aliases: dict[str, dict[str, str]] = {}
    required_fields = set(MODEL_ALIAS_FIELDS)
    for alias in FIXED_MODEL_ALIASES:
        raw_alias = raw_aliases[alias]
        if not isinstance(raw_alias, dict):
            raise ValueError(f"Codex defaults config model_aliases.{alias} must be an object.")
        missing_fields = sorted(required_fields - set(raw_alias))
        if missing_fields:
            raise ValueError(
                f"Codex defaults config model_aliases.{alias} is missing field: {missing_fields[0]}."
            )
        unknown_fields = sorted(set(raw_alias) - required_fields)
        if unknown_fields:
            raise ValueError(
                f"Codex defaults config model_aliases.{alias} contains unknown field: {unknown_fields[0]}."
            )
        aliases[alias] = {
            "model": _validate_model(raw_alias["model"]),
            "model_reasoning_effort": _normalize_reasoning_effort(raw_alias["model_reasoning_effort"]),
            "service_tier": _normalize_service_tier(raw_alias["service_tier"]),
        }

    supported_models = _normalize_supported_models(config.get(SUPPORTED_MODELS_FIELD))
    if supported_models is None:
        supported_models = tuple(dict.fromkeys(alias["model"] for alias in aliases.values()))
    for alias, alias_config in aliases.items():
        try:
            validate_supported_model(alias_config["model"], supported_models)
        except ValueError as exc:
            raise ValueError(
                f"Codex defaults config model_aliases.{alias}.model is not supported: "
                f"{alias_config['model']}."
            ) from exc

    default_alias = normalize_model_alias(config.get("default_model_alias"))
    missing_legacy_fields = [field for field in MODEL_ALIAS_FIELDS if field not in config]
    if missing_legacy_fields:
        raise ValueError(
            f"Codex defaults config version 2 is missing legacy compatibility field: "
            f"{missing_legacy_fields[0]}."
        )
    legacy_config = {
        "model": _validate_model(config["model"]),
        "model_reasoning_effort": _normalize_reasoning_effort(config["model_reasoning_effort"]),
        "service_tier": _normalize_service_tier(config["service_tier"]),
    }
    if legacy_config != aliases[default_alias]:
        raise ValueError(
            "Codex defaults config legacy compatibility fields must match default_model_alias."
        )
    return default_alias, aliases, supported_models


def _default_config_path() -> pathlib.Path | None:
    raw_path = os.environ.get(CODEX_DEFAULTS_CONFIG_ENV)
    if not raw_path:
        return None
    return pathlib.Path(raw_path).expanduser().resolve()


def _normalize_default_model(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_MODEL
    return _validate_model(value)


def _write_config(config_path: pathlib.Path, config: dict[str, Any]) -> None:
    payload = {"version": CONFIG_VERSION, **{key: value for key, value in config.items() if key != "version"}}
    file_ops_module.write_json_atomic(config_path, payload)


def _write_or_remove_config(config_path: pathlib.Path, config: dict[str, Any]) -> None:
    meaningful = {key: value for key, value in config.items() if key != "version"}
    if meaningful:
        _write_config(config_path, meaningful)
    else:
        config_path.unlink(missing_ok=True)
