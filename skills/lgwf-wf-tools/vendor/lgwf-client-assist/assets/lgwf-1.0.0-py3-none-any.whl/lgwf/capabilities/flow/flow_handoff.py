from pathlib import Path
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.types as capability_types
import lgwf.handoff as handoff_module
import lgwf.progress as progress_module
import lgwf.runtime_context as runtime_context_module


class FlowHandoffCapability:
    name = "flow.handoff"

    def create_node(self, _node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        prompt = config.get("prompt")
        prompt_ref = config.get("prompt_ref")
        context_path = config.get("context_path")
        result_path = config.get("result_path", "handoff")
        agent_instruction = config.get("agent_instruction", "handle_handoff")
        auto_execute = config.get("auto_execute", False)
        wait_for_continue = config.get("wait_for_continue", False)
        poll_interval_seconds = config.get("poll_interval_seconds", 1)

        if (prompt is None) == (prompt_ref is None):
            raise ValueError("flow.handoff config requires exactly one of prompt or prompt_ref.")
        if prompt is not None and (not isinstance(prompt, str) or not prompt.strip()):
            raise ValueError("flow.handoff config.prompt must be a non-empty string.")
        if not isinstance(context_path, str) or not context_path:
            raise ValueError("flow.handoff config.context_path must be a non-empty string.")
        if not isinstance(result_path, str) or not result_path:
            raise ValueError("flow.handoff config.result_path must be a non-empty string.")
        if not isinstance(agent_instruction, str) or not agent_instruction:
            raise ValueError("flow.handoff config.agent_instruction must be a non-empty string.")
        if auto_execute is not False:
            raise ValueError("flow.handoff auto_execute=true is not supported.")
        if not isinstance(wait_for_continue, bool):
            raise ValueError("flow.handoff config.wait_for_continue must be a boolean.")
        if not isinstance(poll_interval_seconds, int | float) or poll_interval_seconds <= 0:
            raise ValueError("flow.handoff config.poll_interval_seconds must be a positive number.")

        def node(state: capability_types.State) -> capability_types.State:
            workspace_root = runtime_context_module.get_workspace_root()
            if workspace_root is None:
                raise RuntimeError("flow.handoff requires a runtime workspace root.")
            resolved_prompt = prompt if prompt is not None else _read_workflow_prompt(prompt_ref)
            payload = flow_conditions_module.read_path(state, context_path)
            if not isinstance(payload, dict):
                raise ValueError("flow.handoff context_path must resolve to a JSON object.")
            checkpoint_writer = progress_module.get_checkpoint_writer()
            waiting_action = checkpoint_writer.waiting_action(_node_id) if checkpoint_writer is not None else None
            if waiting_action is not None and waiting_action.get("type") == "agent_handoff":
                request_id = waiting_action["request_id"]
            else:
                payload_request_id = payload.get("request_id")
                request_id = payload_request_id if isinstance(payload_request_id, str) else handoff_module.new_request_id()
                if checkpoint_writer is not None:
                    checkpoint_writer.set_waiting_action(
                        {
                            "type": "agent_handoff",
                            "node_id": _node_id,
                            "request_id": request_id,
                            "phase": "waiting_ack",
                        }
                    )
            pending_action = handoff_module.create_or_restore_pending_action(
                workspace_root,
                _pending_action(
                    payload,
                    resolved_prompt,
                    agent_instruction,
                    wait_for_continue=wait_for_continue,
                    node_id=_node_id,
                ),
                request_id,
            )
            continue_required = pending_action["continue_required"]
            progress_module.emit(
                f"[workflow] agent handoff pending request_id={pending_action['request_id']} "
                f"workflow_id={pending_action['workflow_id']} "
                f"continue_required={str(continue_required).lower()}"
            )
            progress_module.emit(
                f"[workflow] node waiting id={_node_id} capability=flow.handoff "
                f"reason=handoff_ack request_id={request_id}"
            )
            received_record = handoff_module.wait_for_ack(
                workspace_root,
                request_id,
                poll_interval_seconds=float(poll_interval_seconds),
            )
            continued_record = None
            if continue_required:
                if checkpoint_writer is not None:
                    checkpoint_writer.set_waiting_action(
                        {
                            "type": "agent_handoff",
                            "node_id": _node_id,
                            "request_id": request_id,
                            "phase": "waiting_continue",
                        }
                    )
                progress_module.emit(
                    f"[workflow] node waiting id={_node_id} capability=flow.handoff "
                    f"reason=handoff_continue request_id={request_id}"
                )
                continued_record = handoff_module.wait_for_continuation(
                    workspace_root,
                    request_id,
                    poll_interval_seconds=float(poll_interval_seconds),
                )
            result = _handoff_result(pending_action, received_record, continued_record)
            return flow_conditions_module.write_path(dict(state), result_path, result)

        return node


CAPABILITY = FlowHandoffCapability()


def _pending_action(
    payload: dict[str, Any],
    prompt: str,
    agent_instruction: str,
    *,
    wait_for_continue: bool,
    node_id: str,
) -> dict[str, Any]:
    workflow_id = payload.get("workflow_id") or payload.get("next_workflow_id")
    next_action = payload.get("next_action", handoff_module.NEXT_ACTION_START_WORKFLOW)
    action = {
        "type": "agent_handoff",
        "next_action": next_action,
        "workflow_id": workflow_id,
        "next_workflow_id": payload.get("next_workflow_id", workflow_id),
        "workflow_lgwf": payload.get("workflow_lgwf"),
        "work_dir": payload.get("work_dir"),
        "input_json_file": payload.get("input_json_file"),
        "suggested_command": payload.get("suggested_command"),
        "source_artifacts": payload.get("source_artifacts", []),
        "requires_user_confirmation": payload.get("requires_user_confirmation", True),
        "auto_execute": False,
        "ack_required": True,
        "continue_required": wait_for_continue,
        "run_id": progress_module.get_run_id(),
        "node_id": node_id,
        "agent_instruction": _agent_instruction(payload, next_action, agent_instruction),
        "prompt": prompt,
        "payload": payload,
    }
    if isinstance(payload.get("request_id"), str):
        action["request_id"] = payload["request_id"]
    return action


def _handoff_result(
    pending_action: dict[str, Any],
    received_record: dict[str, Any],
    continued_record: dict[str, Any] | None,
) -> dict[str, Any]:
    result = {
        "request_id": pending_action["request_id"],
        "type": "agent_handoff",
        "acknowledged": True,
        "continue_required": pending_action["continue_required"],
        "continued": continued_record is not None,
        "received_at": received_record.get("received_at"),
        "pending_action": pending_action,
    }
    if continued_record is not None:
        result["continued_at"] = continued_record.get("continued_at")
    return result


def _agent_instruction(payload: dict[str, Any], next_action: Any, configured_instruction: str) -> str:
    payload_instruction = payload.get("agent_instruction")
    if isinstance(payload_instruction, str) and payload_instruction:
        return payload_instruction
    if (
        next_action == handoff_module.NEXT_ACTION_MAIN_AGENT_AUTHORING
        and configured_instruction == "handle_handoff"
    ):
        return "handle_main_agent_authoring"
    return configured_instruction


def _read_workflow_prompt(prompt_ref: Any) -> str:
    if not isinstance(prompt_ref, dict):
        raise ValueError("flow.handoff config.prompt_ref must be an object.")
    if prompt_ref.get("root") != "workflow":
        raise ValueError("flow.handoff config.prompt_ref.root must be workflow.")
    raw_path = prompt_ref.get("path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("flow.handoff config.prompt_ref.path must be a non-empty string.")
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("flow.handoff config.prompt_ref.path must be relative and must not contain '..'.")
    workflow_root = runtime_context_module.get_workflow_root()
    if workflow_root is None:
        raise RuntimeError("flow.handoff prompt_ref requires a runtime workflow root.")
    resolved = (workflow_root / path).resolve()
    if not resolved.is_relative_to(workflow_root):
        raise ValueError("flow.handoff config.prompt_ref.path must stay inside the workflow root.")
    if not resolved.is_file():
        raise ValueError(f"flow.handoff prompt_ref does not exist or is not a file: {resolved}")
    return resolved.read_text(encoding="utf-8")
