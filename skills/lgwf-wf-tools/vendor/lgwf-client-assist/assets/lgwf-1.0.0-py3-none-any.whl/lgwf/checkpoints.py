﻿import datetime
import hashlib
import json
from pathlib import Path
from typing import Any

import lgwf.file_ops as file_ops_module
import lgwf.workspace_layout as workspace_layout_module


class CheckpointError(RuntimeError):
    """Raised when LGWF checkpoint data is missing or invalid."""


def workflow_hash(dsl: dict[str, Any]) -> str:
    payload = json.dumps(dsl, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_checkpoint(workspace_root: Path, run_id: str) -> dict[str, Any]:
    path = workspace_layout_module.checkpoint_path(workspace_root.resolve(), run_id)
    if not path.is_file():
        raise CheckpointError(f"checkpoint not found: {run_id}")
    try:
        checkpoint = file_ops_module.read_json(path)
    except file_ops_module.FileOperationError as exc:
        raise CheckpointError(f"checkpoint is not valid JSON: {run_id}") from exc
    _validate_checkpoint(checkpoint)
    return checkpoint


def latest_failed_checkpoint(workspace_root: Path) -> dict[str, Any] | None:
    return latest_checkpoint_with_status(workspace_root, {"failed"})


def latest_checkpoint_with_status(workspace_root: Path, statuses: set[str]) -> dict[str, Any] | None:
    root = workspace_layout_module.checkpoints_dir(workspace_root.resolve())
    if not root.is_dir():
        return None
    candidates: list[tuple[float, dict[str, Any]]] = []
    for path in root.glob("*/checkpoint.json"):
        try:
            checkpoint = file_ops_module.read_json(path)
            _validate_checkpoint(checkpoint)
        except Exception:
            continue
        if checkpoint.get("status") in statuses:
            candidates.append((path.stat().st_mtime, checkpoint))
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: item[0], reverse=True)[0][1]


class CheckpointWriter:
    def __init__(
        self,
        workspace_root: Path,
        run_id: str,
        workflow_hash_value: str,
        resume_checkpoint: dict[str, Any] | None = None,
    ) -> None:
        self.workspace_root = workspace_root.resolve()
        self.run_id = run_id
        self.workflow_hash = workflow_hash_value
        self.current: dict[str, Any] = {
            "version": 1,
            "run_id": run_id,
            "workflow_hash": workflow_hash_value,
            "status": "running",
            "current_node": None,
            "last_completed_node": None,
            "failed_node": None,
            "state_before_current_node": None,
            "state_after_last_completed_node": None,
            "failure_summary": None,
            "waiting_action": _restored_waiting_action(resume_checkpoint),
            "updated_at": _utc_now(),
        }

    def start_node(self, node_id: str, _capability: str, state: dict[str, Any]) -> None:
        self.current.update(
            {
                "status": "running",
                "current_node": node_id,
                "failed_node": None,
                "state_before_current_node": state,
                "failure_summary": None,
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def complete_node(self, node_id: str, _capability: str, state: dict[str, Any]) -> None:
        self.current.update(
            {
                "status": "running",
                "current_node": None,
                "last_completed_node": node_id,
                "failed_node": None,
                "state_after_last_completed_node": state,
                "failure_summary": None,
                "waiting_action": None,
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def waiting_action(self, node_id: str) -> dict[str, Any] | None:
        action = self.current.get("waiting_action")
        if not isinstance(action, dict) or action.get("node_id") != node_id:
            return None
        return dict(action)

    def set_waiting_action(self, action: dict[str, Any]) -> None:
        if not isinstance(action, dict):
            raise CheckpointError("checkpoint waiting_action must be an object.")
        for field in ("type", "node_id", "request_id", "phase"):
            if not isinstance(action.get(field), str) or not action[field]:
                raise CheckpointError(f"checkpoint waiting_action {field} must be a non-empty string.")
        self.current.update({"waiting_action": dict(action), "updated_at": _utc_now()})
        self._save()

    def fail_node(self, node_id: str, capability: str, state: dict[str, Any], exc: Exception) -> None:
        if self.current.get("status") == "failed" and self.current.get("failed_node"):
            return
        self.current.update(
            {
                "status": "failed",
                "current_node": node_id,
                "failed_node": node_id,
                "state_before_current_node": state,
                "failure_summary": {
                    "node_id": node_id,
                    "capability": capability,
                    "error_type": type(exc).__name__,
                    "message": str(exc),
                },
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def complete_workflow(self, final_state: dict[str, Any]) -> None:
        self.current.update(
            {
                "status": "completed",
                "current_node": None,
                "failed_node": None,
                "state_after_last_completed_node": final_state,
                "failure_summary": None,
                "waiting_action": None,
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def fail_workflow(self, failure_summary: dict[str, Any]) -> None:
        failed_node = self.current.get("failed_node")
        current_node = self.current.get("current_node")
        if self.current.get("status") == "failed" and failed_node:
            return
        self.current.update(
            {
                "status": "failed",
                "failed_node": failed_node or current_node,
                "failure_summary": failure_summary,
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def stop_workflow(self, stop_summary: dict[str, Any]) -> None:
        current_node = self.current.get("current_node")
        self.current.update(
            {
                "status": "stopped",
                "failed_node": current_node if isinstance(current_node, str) and current_node else None,
                "failure_summary": stop_summary,
                "updated_at": _utc_now(),
            }
        )
        self._save()

    def _save(self) -> None:
        path = workspace_layout_module.checkpoint_path(self.workspace_root, self.run_id)
        file_ops_module.write_json_atomic(path, self.current, sort_keys=False)


def _validate_checkpoint(checkpoint: Any) -> None:
    if not isinstance(checkpoint, dict):
        raise CheckpointError("checkpoint root must be an object.")
    if checkpoint.get("version") != 1:
        raise CheckpointError("checkpoint version must be 1.")
    for field in ("run_id", "workflow_hash", "status", "updated_at"):
        if not isinstance(checkpoint.get(field), str) or not checkpoint[field]:
            raise CheckpointError(f"checkpoint {field} must be a non-empty string.")
    if checkpoint["status"] not in {"running", "failed", "completed", "stopped"}:
        raise CheckpointError("checkpoint status must be running, failed, completed, or stopped.")
    waiting_action = checkpoint.get("waiting_action")
    if waiting_action is not None:
        if not isinstance(waiting_action, dict):
            raise CheckpointError("checkpoint waiting_action must be an object or null.")
        for field in ("type", "node_id", "request_id", "phase"):
            if not isinstance(waiting_action.get(field), str) or not waiting_action[field]:
                raise CheckpointError(f"checkpoint waiting_action {field} must be a non-empty string.")


def _restored_waiting_action(checkpoint: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(checkpoint, dict):
        return None
    action = checkpoint.get("waiting_action")
    return dict(action) if isinstance(action, dict) else None


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()
