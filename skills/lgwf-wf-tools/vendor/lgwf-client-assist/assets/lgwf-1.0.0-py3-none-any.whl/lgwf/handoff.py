import datetime
import time
import uuid
from pathlib import Path
from typing import Any

import lgwf.file_ops as file_ops_module
import lgwf.workspace_layout as workspace_layout_module


NEXT_ACTION_START_WORKFLOW = "start_workflow"
NEXT_ACTION_MAIN_AGENT_AUTHORING = "main_agent_authoring"
ALLOWED_NEXT_ACTIONS = {
    NEXT_ACTION_START_WORKFLOW,
    NEXT_ACTION_MAIN_AGENT_AUTHORING,
}
_LIFECYCLE_IDENTITY_FIELDS = (
    "type",
    "request_id",
    "run_id",
    "node_id",
    "ack_required",
    "continue_required",
)


class HandoffError(ValueError):
    """Raised when handoff lifecycle files are invalid."""


def new_request_id() -> str:
    return f"handoff-{uuid.uuid4().hex[:12]}"


def create_pending_action(
    workspace_root: Path,
    action: dict[str, Any],
    request_id: str | None = None,
) -> dict[str, Any]:
    pending_action = dict(action)
    pending_action["request_id"] = request_id or _request_id(pending_action)
    pending_action.setdefault("ack_required", True)
    pending_action.setdefault("continue_required", False)
    _validate_pending_action(pending_action)
    pending_action.setdefault("created_at", _utc_now())
    path = workspace_layout_module.handoff_pending_path(workspace_root.resolve(), pending_action["request_id"])
    file_ops_module.write_json_atomic(path, pending_action)
    return pending_action


def create_or_restore_pending_action(
    workspace_root: Path,
    action: dict[str, Any],
    request_id: str,
) -> dict[str, Any]:
    _validate_request_id(request_id)
    expected_action = dict(action)
    expected_action["request_id"] = request_id
    expected_action.setdefault("ack_required", True)
    expected_action.setdefault("continue_required", False)
    _validate_pending_action(expected_action)
    root = workspace_root.resolve()
    pending_path = workspace_layout_module.handoff_pending_path(root, request_id)
    received_path = workspace_layout_module.handoff_received_path(root, request_id)
    continued_path = workspace_layout_module.handoff_continued_path(root, request_id)
    if pending_path.is_file():
        pending = _load_json(pending_path, "handoff pending action")
        _validate_pending_action(pending)
        _validate_lifecycle_identity(expected_action, pending, pending_path)
        return pending
    if received_path.is_file():
        received = _load_json(received_path, "handoff received record")
        _validate_received_record(received)
        pending = dict(received["pending_action"])
        _validate_lifecycle_identity(expected_action, pending, received_path)
        return pending
    if continued_path.is_file():
        continued = _load_json(continued_path, "handoff continued record")
        _validate_continued_record(continued)
        pending = dict(continued["received_record"]["pending_action"])
        _validate_lifecycle_identity(expected_action, pending, continued_path)
        return pending
    return create_pending_action(root, expected_action, request_id=request_id)


def acknowledge_pending_action(
    workspace_root: Path,
    request_id: str,
    *,
    received_by: str = "main_agent",
    comment: str | None = None,
) -> dict[str, Any]:
    _validate_request_id(request_id)
    if not isinstance(received_by, str) or not received_by:
        raise HandoffError("handoff received_by must be a non-empty string.")
    if comment is not None and not isinstance(comment, str):
        raise HandoffError("handoff comment must be a string when provided.")
    root = workspace_root.resolve()
    pending_path = workspace_layout_module.handoff_pending_path(root, request_id)
    received_path = workspace_layout_module.handoff_received_path(root, request_id)
    if not pending_path.is_file():
        if received_path.is_file():
            record = _load_json(received_path, "handoff received record")
            _validate_received_record(record)
            return _ack_result(request_id, received_path, record, already_received=True)
        raise HandoffError(f"handoff pending action not found: {request_id}")

    pending_action = _load_json(pending_path, "handoff pending action")
    _validate_pending_action(pending_action)
    if pending_action["request_id"] != request_id:
        raise HandoffError("handoff pending action request_id does not match requested id.")
    record: dict[str, Any] = {
        "type": "agent_handoff_received",
        "request_id": request_id,
        "status": "received",
        "received": True,
        "received_by": received_by,
        "received_at": _utc_now(),
        "continue_required": pending_action["continue_required"],
        "pending_action": pending_action,
    }
    if comment is not None:
        record["comment"] = comment
    file_ops_module.write_json_atomic(received_path, record)
    pending_path.unlink(missing_ok=True)
    return _ack_result(request_id, received_path, record, already_received=False)


def wait_for_ack(
    workspace_root: Path,
    request_id: str,
    *,
    poll_interval_seconds: float = 1.0,
) -> dict[str, Any]:
    _validate_poll_interval(poll_interval_seconds)
    root = workspace_root.resolve()
    received_path = workspace_layout_module.handoff_received_path(root, request_id)
    while True:
        if received_path.is_file():
            try:
                record = _load_json(received_path, "handoff received record")
            except PermissionError:
                time.sleep(poll_interval_seconds)
                continue
            _validate_received_record(record)
            return record
        time.sleep(poll_interval_seconds)


def submit_continuation(
    workspace_root: Path,
    request_id: str,
    *,
    continued_by: str = "main_agent",
    comment: str | None = None,
) -> dict[str, Any]:
    _validate_request_id(request_id)
    if not isinstance(continued_by, str) or not continued_by:
        raise HandoffError("handoff continued_by must be a non-empty string.")
    if comment is not None and not isinstance(comment, str):
        raise HandoffError("handoff comment must be a string when provided.")
    root = workspace_root.resolve()
    pending_path = workspace_layout_module.handoff_pending_path(root, request_id)
    received_path = workspace_layout_module.handoff_received_path(root, request_id)
    continued_path = workspace_layout_module.handoff_continued_path(root, request_id)
    if continued_path.is_file():
        record = _load_json(continued_path, "handoff continued record")
        _validate_continued_record(record)
        return _continue_result(request_id, continued_path, record, already_continued=True)
    if pending_path.is_file():
        raise HandoffError(f"handoff must be acknowledged before continue: {request_id}")
    if not received_path.is_file():
        raise HandoffError(f"handoff received record not found: {request_id}")

    received_record = _load_json(received_path, "handoff received record")
    _validate_received_record(received_record)
    if received_record.get("continue_required") is not True:
        raise HandoffError(f"handoff does not require continue: {request_id}")
    record: dict[str, Any] = {
        "type": "agent_handoff_continued",
        "request_id": request_id,
        "status": "continued",
        "continued": True,
        "continued_by": continued_by,
        "continued_at": _utc_now(),
        "received_record": received_record,
    }
    if comment is not None:
        record["comment"] = comment
    file_ops_module.write_json_atomic(continued_path, record)
    return _continue_result(request_id, continued_path, record, already_continued=False)


def wait_for_continuation(
    workspace_root: Path,
    request_id: str,
    *,
    poll_interval_seconds: float = 1.0,
) -> dict[str, Any]:
    _validate_poll_interval(poll_interval_seconds)
    root = workspace_root.resolve()
    continued_path = workspace_layout_module.handoff_continued_path(root, request_id)
    while True:
        if continued_path.is_file():
            try:
                record = _load_json(continued_path, "handoff continued record")
            except PermissionError:
                time.sleep(poll_interval_seconds)
                continue
            _validate_continued_record(record)
            return record
        time.sleep(poll_interval_seconds)


def list_pending_actions(workspace_root: Path) -> list[dict[str, Any]]:
    handoff_dir = workspace_layout_module.handoff_dir(workspace_root.resolve())
    if not handoff_dir.exists():
        return []
    actions: list[dict[str, Any]] = []
    paths = sorted(handoff_dir.glob("*.pending.json"), key=_safe_mtime, reverse=True)
    for path in paths:
        if not path.is_file():
            continue
        action = _load_json(path, "handoff pending action")
        _validate_pending_action(action)
        actions.append(action)
    return actions


def list_waiting_continuations(workspace_root: Path) -> list[dict[str, Any]]:
    root = workspace_root.resolve()
    handoff_dir = workspace_layout_module.handoff_dir(root)
    if not handoff_dir.exists():
        return []
    records: list[dict[str, Any]] = []
    paths = sorted(handoff_dir.glob("*.received.json"), key=_safe_mtime, reverse=True)
    for path in paths:
        request_id = path.name.removesuffix(".received.json")
        if workspace_layout_module.handoff_continued_path(root, request_id).exists():
            continue
        record = _load_json(path, "handoff received record")
        _validate_received_record(record)
        if record.get("continue_required") is True:
            records.append(record)
    return records


def _ack_result(
    request_id: str,
    received_path: Path,
    record: dict[str, Any],
    *,
    already_received: bool,
) -> dict[str, Any]:
    return {
        "ok": True,
        "request_id": request_id,
        "status": "received",
        "already_received": already_received,
        "continue_required": record.get("continue_required") is True,
        "received_path": str(received_path),
        "record": record,
    }


def _continue_result(
    request_id: str,
    continued_path: Path,
    record: dict[str, Any],
    *,
    already_continued: bool,
) -> dict[str, Any]:
    return {
        "ok": True,
        "request_id": request_id,
        "status": "continued",
        "already_continued": already_continued,
        "continued_path": str(continued_path),
        "record": record,
    }


def _request_id(action: dict[str, Any]) -> str:
    existing = action.get("request_id")
    if isinstance(existing, str) and existing:
        return existing
    return new_request_id()


def _validate_pending_action(action: dict[str, Any]) -> None:
    if not isinstance(action, dict):
        raise HandoffError("handoff pending action must be a JSON object.")
    # Pending actions written by older runtimes did not include these lifecycle
    # flags. They represent the ACK-only behavior and remain valid after upgrade.
    action.setdefault("ack_required", True)
    action.setdefault("continue_required", False)
    if action.get("type") != "agent_handoff":
        raise HandoffError("handoff pending action type must be agent_handoff.")
    _validate_request_id(action.get("request_id"))
    next_action = action.get("next_action")
    if next_action not in ALLOWED_NEXT_ACTIONS:
        allowed = ", ".join(sorted(ALLOWED_NEXT_ACTIONS))
        raise HandoffError(f"handoff next_action must be one of: {allowed}.")
    workflow_id = action.get("workflow_id")
    if next_action == NEXT_ACTION_START_WORKFLOW and (not isinstance(workflow_id, str) or not workflow_id):
        raise HandoffError("handoff workflow_id must be a non-empty string.")
    if workflow_id is not None and not isinstance(workflow_id, str):
        raise HandoffError("handoff workflow_id must be a string when provided.")
    agent_instruction = action.get("agent_instruction")
    if not isinstance(agent_instruction, str) or not agent_instruction:
        raise HandoffError("handoff agent_instruction must be a non-empty string.")
    if not isinstance(action.get("requires_user_confirmation"), bool):
        raise HandoffError("handoff requires_user_confirmation must be a boolean.")
    if action.get("auto_execute") is not False:
        raise HandoffError("handoff auto_execute must be false.")
    if action.get("ack_required") is not True:
        raise HandoffError("handoff ack_required must be true.")
    if not isinstance(action.get("continue_required"), bool):
        raise HandoffError("handoff continue_required must be a boolean.")


def _validate_received_record(record: dict[str, Any]) -> None:
    if not isinstance(record, dict) or record.get("type") != "agent_handoff_received":
        raise HandoffError("handoff received record type must be agent_handoff_received.")
    _validate_request_id(record.get("request_id"))
    if record.get("status") != "received" or record.get("received") is not True:
        raise HandoffError("handoff received record must have status=received.")
    pending_action = record.get("pending_action")
    _validate_pending_action(pending_action)
    record.setdefault("continue_required", pending_action["continue_required"])
    if pending_action["request_id"] != record["request_id"]:
        raise HandoffError("handoff received record request_id mismatch.")
    if record.get("continue_required") is not pending_action["continue_required"]:
        raise HandoffError("handoff received record continue_required mismatch.")


def _validate_continued_record(record: dict[str, Any]) -> None:
    if not isinstance(record, dict) or record.get("type") != "agent_handoff_continued":
        raise HandoffError("handoff continued record type must be agent_handoff_continued.")
    _validate_request_id(record.get("request_id"))
    if record.get("status") != "continued" or record.get("continued") is not True:
        raise HandoffError("handoff continued record must have status=continued.")
    received_record = record.get("received_record")
    _validate_received_record(received_record)
    if received_record["request_id"] != record["request_id"]:
        raise HandoffError("handoff continued record request_id mismatch.")
    if received_record.get("continue_required") is not True:
        raise HandoffError("handoff continued record requires continue_required=true.")


def _validate_lifecycle_identity(
    expected: dict[str, Any],
    existing: dict[str, Any],
    lifecycle_path: Path,
) -> None:
    mismatched_fields = [
        field
        for field in _LIFECYCLE_IDENTITY_FIELDS
        if existing.get(field) != expected.get(field)
    ]
    if not mismatched_fields:
        return
    fields = ", ".join(mismatched_fields)
    raise HandoffError(
        f"handoff lifecycle identity conflict for request_id={expected['request_id']}: "
        f"{fields} differ in {lifecycle_path}"
    )


def _validate_request_id(request_id: Any) -> None:
    if not isinstance(request_id, str) or not request_id:
        raise HandoffError("handoff request_id must be a non-empty string.")
    if "/" in request_id or "\\" in request_id or ".." in request_id:
        raise HandoffError("handoff request_id must not contain path separators or '..'.")


def _validate_poll_interval(value: float) -> None:
    if not isinstance(value, int | float) or value <= 0:
        raise HandoffError("handoff poll_interval_seconds must be a positive number.")


def _load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        data = file_ops_module.read_json(path)
    except file_ops_module.FileOperationError as exc:
        raise HandoffError(f"{label} is not valid JSON: {path}") from exc
    if not isinstance(data, dict):
        raise HandoffError(f"{label} must be a JSON object: {path}")
    return data


def _safe_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except FileNotFoundError:
        return 0.0


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()
