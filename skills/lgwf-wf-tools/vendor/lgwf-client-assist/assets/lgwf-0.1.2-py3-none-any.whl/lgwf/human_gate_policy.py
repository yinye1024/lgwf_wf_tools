from collections.abc import Callable
from pathlib import Path
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf.human_gate_control as human_gate_control_module
import lgwf.runtime_context as runtime_context_module


AUTO_APPROVE_MODE = "auto_approve"
AUTO_APPROVE_COMMENT = "auto approved by human_gate_policy"


def auto_approve_policy() -> dict[str, Any]:
    return {"mode": AUTO_APPROVE_MODE, "auto": True}


def is_auto_approve_enabled(workspace_root: Path | None = None) -> bool:
    return is_auto_approve_policy(effective_policy(workspace_root))


def is_auto_approve_policy(policy: Any) -> bool:
    return isinstance(policy, dict) and policy.get("auto") is True


def effective_policy(workspace_root: Path | None = None) -> dict[str, Any] | None:
    resolved_workspace_root = workspace_root or runtime_context_module.get_workspace_root()
    if resolved_workspace_root is not None:
        dynamic_policy = human_gate_control_module.load_policy(resolved_workspace_root)
        if dynamic_policy is not None:
            return dynamic_policy
    return runtime_context_module.get_human_gate_policy()


def current_policy_summary(*, source: str | None = None) -> dict[str, Any] | None:
    policy = effective_policy()
    if not is_auto_approve_policy(policy):
        return None
    summary = auto_approve_policy()
    if source is not None:
        summary["source"] = source
    return summary


def write_auto_response_for_request(
    *,
    workspace_root: Path,
    request: dict[str, Any],
) -> dict[str, Any] | None:
    if not is_auto_approve_enabled(workspace_root):
        return None
    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("human request_id must be a non-empty string.")
    kind = request.get("kind")
    if kind == "human_review":
        options = _request_options(request, default=["approve", "revise", "reject"])
        if "approve" not in options:
            raise RuntimeError("flow.human_review auto approve requires options to include approve.")
        return write_auto_review_response(
            workspace_root=workspace_root,
            request_id=request_id,
            route="approve",
        )
    if kind == "human_choice":
        options = _request_options(request, default=None)
        return write_auto_choice_response(
            workspace_root=workspace_root,
            request_id=request_id,
            route=auto_choice_route(options),
        )
    return write_auto_approval_response(
        workspace_root=workspace_root,
        request_id=request_id,
    )


def auto_response_provider(workspace_root: Path) -> Callable[[dict[str, Any]], dict[str, Any] | None]:
    def provide(request: dict[str, Any]) -> dict[str, Any] | None:
        return write_auto_response_for_request(workspace_root=workspace_root, request=request)

    return provide


def write_auto_approval_response(
    *,
    workspace_root: Path,
    request_id: str,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response


def write_auto_review_response(
    *,
    workspace_root: Path,
    request_id: str,
    route: str,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response


def auto_choice_route(options: list[str]) -> str:
    if "run" in options:
        return "run"
    if "approve" in options:
        return "approve"
    raise RuntimeError("flow.human_choice auto requires options to include run or approve.")


def write_auto_choice_response(
    *,
    workspace_root: Path,
    request_id: str,
    route: str,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "value": {
            "route": route,
            "choice": route,
            "auto_approved": True,
            "human_gate_policy": policy,
        },
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response


def _request_options(request: dict[str, Any], *, default: list[str] | None) -> list[str]:
    options = request.get("options")
    if options is None:
        if default is None:
            raise RuntimeError("human auto response requires request options.")
        return list(default)
    if (
        not isinstance(options, list)
        or not options
        or any(not isinstance(option, str) or not option for option in options)
    ):
        raise RuntimeError("human auto response requires request options to be a non-empty string array.")
    return list(options)
