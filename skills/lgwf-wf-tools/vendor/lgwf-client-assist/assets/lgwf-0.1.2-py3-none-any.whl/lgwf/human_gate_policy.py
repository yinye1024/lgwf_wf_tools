from pathlib import Path
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf.runtime_context as runtime_context_module


AUTO_APPROVE_MODE = "auto_approve"
AUTO_APPROVE_COMMENT = "auto approved by human_gate_policy"


def auto_approve_policy() -> dict[str, Any]:
    return {"mode": AUTO_APPROVE_MODE, "auto": True}


def is_auto_approve_enabled() -> bool:
    return is_auto_approve_policy(runtime_context_module.get_human_gate_policy())


def is_auto_approve_policy(policy: Any) -> bool:
    return isinstance(policy, dict) and policy.get("auto") is True and policy.get("mode") == AUTO_APPROVE_MODE


def current_policy_summary(*, source: str | None = None) -> dict[str, Any] | None:
    policy = runtime_context_module.get_human_gate_policy()
    if not is_auto_approve_policy(policy):
        return None
    summary = auto_approve_policy()
    if source is not None:
        summary["source"] = source
    return summary


def write_auto_approval_response(
    *,
    workspace_root: Path,
    request_id: str,
    value: Any,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "value": value,
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response


def write_auto_review_response(
    *,
    workspace_root: Path,
    request_id: str,
    route: str,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "value": {
            "route": route,
            "auto_approved": True,
            "human_gate_policy": policy,
        },
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response


def auto_choice_route(options: list[str]) -> str:
    if "run" in options:
        return "run"
    if "approve" in options:
        return "approve"
    raise RuntimeError("flow.human_choice auto requires options to include run or approve.")


def write_auto_choice_response(
    *,
    workspace_root: Path,
    request_id: str,
    route: str,
) -> dict[str, Any]:
    policy = auto_approve_policy()
    response = {
        "decision": "approve",
        "value": {
            "route": route,
            "choice": route,
            "auto_approved": True,
            "human_gate_policy": policy,
        },
        "comment": AUTO_APPROVE_COMMENT,
        "auto_approved": True,
        "human_gate_policy": policy,
    }
    human_approval_module.write_auto_response(workspace_root, request_id, response)
    return response
