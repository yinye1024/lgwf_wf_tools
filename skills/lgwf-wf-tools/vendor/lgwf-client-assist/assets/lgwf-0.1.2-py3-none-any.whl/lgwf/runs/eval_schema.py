import json
from pathlib import Path
from typing import Any

import jsonschema


EvalSchema = dict[str, Any]
EvalSpec = dict[str, Any]

SCHEMA_PATH = Path(__file__).with_name("eval_schema.json")


class EvalSchemaLoadError(ValueError):
    """Raised when the eval schema cannot be loaded."""


class EvalSpecValidationError(ValueError):
    """Raised when an eval spec is invalid."""


def load_eval_schema(path: Path = SCHEMA_PATH) -> EvalSchema:
    try:
        content = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise EvalSchemaLoadError(f"Eval schema file not found: {path}") from exc
    except OSError as exc:
        raise EvalSchemaLoadError(f"Failed to read eval schema file: {path}") from exc

    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise EvalSchemaLoadError(f"Eval schema file is not valid JSON: {path}") from exc

    if not isinstance(data, dict):
        raise EvalSchemaLoadError(f"Eval schema root must be a JSON object: {path}")
    if data.get("version") != 1:
        raise EvalSchemaLoadError("Eval schema must include version 1.")
    return data


def validate_eval_spec(spec: EvalSpec, *, schema: EvalSchema | None = None) -> None:
    if not isinstance(spec, dict):
        raise EvalSpecValidationError("Eval spec root must be a JSON object.")
    active_schema = schema or load_eval_schema()
    try:
        jsonschema.validate(spec, active_schema)
    except jsonschema.ValidationError as exc:
        path = ".".join(str(part) for part in exc.absolute_path)
        location = f" at {path}" if path else ""
        message = exc.message[:1].lower() + exc.message[1:]
        raise EvalSpecValidationError(f"Invalid eval spec{location}: {message}") from exc
