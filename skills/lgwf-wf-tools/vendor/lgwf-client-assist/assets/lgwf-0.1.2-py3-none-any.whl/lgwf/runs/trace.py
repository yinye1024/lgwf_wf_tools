﻿import contextlib
import contextvars
import datetime
from typing import Any

import lgwf.runs.metrics as metrics_module
import lgwf.file_ops as file_ops_module
import lgwf.workspace_layout as workspace_layout_module


Trace = dict[str, Any]

_CURRENT_RECORDER: contextvars.ContextVar["TraceRecorder | None"] = contextvars.ContextVar(
    "lgwf_trace_recorder",
    default=None,
)
_CURRENT_NODE_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "lgwf_trace_current_node_id",
    default=None,
)


class TraceRecorder:
    def __init__(
        self,
        run_id: str,
        workflow: dict[str, Any],
        dsl_summary: dict[str, Any],
        started_at: str,
    ) -> None:
        self.trace: Trace = {
            "version": 1,
            "run_id": run_id,
            "status": "running",
            "workflow": workflow,
            "started_at": started_at,
            "finished_at": None,
            "dsl_summary": dsl_summary,
            "events": [],
            "nodes": [],
            "routes": [],
            "client_calls": [],
            "token_usage": metrics_module.token_summary([]),
            "change_summary": {},
            "failure_summary": None,
        }
        self._seq = 0
        self._nodes_by_id: dict[str, dict[str, Any]] = {}
        self._client_calls_by_id: dict[str, dict[str, Any]] = {}

    def workflow_started(self) -> None:
        self._event("workflow.started")

    def workflow_completed(self, finished_at: str) -> None:
        self.trace["status"] = "completed"
        self.trace["finished_at"] = finished_at
        self._event("workflow.completed")

    def workflow_failed(self, failure_summary: dict[str, Any], finished_at: str) -> None:
        self.trace["status"] = "failed"
        self.trace["finished_at"] = finished_at
        self.trace["failure_summary"] = failure_summary
        self._event("workflow.failed", failure_summary=failure_summary)

    def node_started(self, node_id: str, capability: str) -> None:
        started_at = _utc_now()
        node = {
            "node_id": node_id,
            "capability": capability,
            "status": "running",
            "started_at": started_at,
            "finished_at": None,
            "duration_ms": None,
            "route_key": None,
            "client_call_ids": [],
            "approval": None,
            "failure_signals": [],
            "capability_statuses": [],
            "execution_results": [],
            "warning_count": 0,
            "artifact_count": 0,
            "ok": None,
            "exit_code": None,
        }
        self.trace["nodes"].append(node)
        self._nodes_by_id[node_id] = node
        self._event("node.started", node_id=node_id, capability=capability)

    def node_completed(
        self,
        node_id: str,
        capability: str,
        before_state: Any,
        after_state: Any,
        duration_ms: int,
    ) -> None:
        node = self._node(node_id, capability)
        node.update(
            {
                "status": "completed",
                "finished_at": _utc_now(),
                "duration_ms": duration_ms,
            }
        )
        summary = _node_observations(node_id, capability, before_state, after_state, duration_ms)
        node_summary = summary.get("nodes", [{}])[0] if summary.get("nodes") else {}
        node["ok"] = node_summary.get("ok")
        node["exit_code"] = node_summary.get("exit_code")
        node["execution_results"] = node_summary.get("execution_results", [])
        node["warning_count"] = node_summary.get("warning_count", 0)
        node["artifact_count"] = node_summary.get("artifact_count", 0)
        approvals = summary.get("approvals")
        node["approval"] = approvals[-1] if isinstance(approvals, list) and approvals else None
        node["failure_signals"] = summary.get("failure_signals", [])
        node["capability_statuses"] = summary.get("capability_statuses", [])
        self._refresh_token_usage()
        self._event("node.completed", node_id=node_id, capability=capability, duration_ms=duration_ms)

    def node_failed(self, node_id: str, capability: str, exc: Exception, duration_ms: int) -> None:
        node = self._node(node_id, capability)
        node.update(
            {
                "status": "failed",
                "finished_at": _utc_now(),
                "duration_ms": duration_ms,
            }
        )
        failure = {
            "node_id": node_id,
            "capability": capability,
            "error_type": type(exc).__name__,
            "message": str(exc),
        }
        self.trace["failure_summary"] = failure
        self._event("node.failed", node_id=node_id, capability=capability, failure_summary=failure)

    def route_decided(self, source_node: str, route_key: str, target_node: str) -> None:
        route = {
            "source_node": source_node,
            "route_key": route_key,
            "target_node": target_node,
            "at": _utc_now(),
        }
        self.trace["routes"].append(route)
        node = self._nodes_by_id.get(source_node)
        if node is not None:
            node["route_key"] = route_key
        self._event("route.decided", **route)

    def client_started(self, instruction: dict[str, Any], node_id: str | None) -> None:
        call = {
            "instruction_id": instruction.get("id"),
            "type": instruction.get("type"),
            "node_id": node_id,
            "status": "running",
            "started_at": _utc_now(),
            "finished_at": None,
            "duration_ms": None,
            "instruction": _instruction_summary(instruction),
            "result": None,
        }
        self.trace["client_calls"].append(call)
        instruction_id = call.get("instruction_id")
        if isinstance(instruction_id, str):
            self._client_calls_by_id[instruction_id] = call
        if node_id:
            node = self._nodes_by_id.get(node_id)
            if node is not None and isinstance(instruction_id, str):
                node["client_call_ids"].append(instruction_id)
        self._event("client.started", instruction_id=instruction_id, node_id=node_id, instruction_type=instruction.get("type"))

    def client_completed(self, instruction: dict[str, Any], result: dict[str, Any], duration_ms: int) -> None:
        call = self._client_call(instruction)
        call.update(
            {
                "status": "completed" if result.get("ok") is True else "failed",
                "finished_at": _utc_now(),
                "duration_ms": duration_ms,
                "result": _result_summary(result),
            }
        )
        self._refresh_token_usage()
        event_type = "client.completed" if result.get("ok") is True else "client.failed"
        self._event(
            event_type,
            instruction_id=instruction.get("id"),
            node_id=call.get("node_id"),
            duration_ms=duration_ms,
        )

    def client_failed(self, instruction: dict[str, Any], exc: Exception, duration_ms: int) -> None:
        call = self._client_call(instruction)
        call.update(
            {
                "status": "failed",
                "finished_at": _utc_now(),
                "duration_ms": duration_ms,
                "result": {
                    "error_type": type(exc).__name__,
                    "message": str(exc),
                },
            }
        )
        self._event(
            "client.failed",
            instruction_id=instruction.get("id"),
            node_id=call.get("node_id"),
            duration_ms=duration_ms,
        )

    def set_change_summary(self, change_summary: dict[str, Any]) -> None:
        self.trace["change_summary"] = change_summary

    def snapshot(self) -> Trace:
        return dict(self.trace)

    def _event(self, event_type: str, **fields: Any) -> None:
        self._seq += 1
        event = {
            "seq": self._seq,
            "type": event_type,
            "at": _utc_now(),
        }
        event.update(fields)
        self.trace["events"].append(event)

    def _node(self, node_id: str, capability: str) -> dict[str, Any]:
        node = self._nodes_by_id.get(node_id)
        if node is None:
            self.node_started(node_id, capability)
            node = self._nodes_by_id[node_id]
        return node

    def _client_call(self, instruction: dict[str, Any]) -> dict[str, Any]:
        instruction_id = instruction.get("id")
        call = self._client_calls_by_id.get(instruction_id) if isinstance(instruction_id, str) else None
        if call is None:
            self.client_started(instruction, current_node_id())
            call = self._client_calls_by_id.get(instruction_id) if isinstance(instruction_id, str) else None
        if call is None:
            raise RuntimeError("trace client call could not be initialized.")
        return call

    def _refresh_token_usage(self) -> None:
        token_metrics = []
        for call in self.trace["client_calls"]:
            result = call.get("result")
            if not isinstance(result, dict):
                continue
            token_usage = result.get("token_usage")
            if not isinstance(token_usage, dict):
                continue
            token_metrics.append(
                {
                    "type": "token_usage",
                    "node_id": call.get("node_id"),
                    "capability": self._node_capability(call.get("node_id")),
                    "state_path": None,
                    "instruction_id": call.get("instruction_id"),
                    "ok": result.get("ok"),
                    "exit_code": result.get("exit_code"),
                    "token_usage": token_usage,
                }
            )
        self.trace["token_usage"] = metrics_module.token_summary(token_metrics)

    def _node_capability(self, node_id: Any) -> str | None:
        node = self._nodes_by_id.get(node_id) if isinstance(node_id, str) else None
        if node is None:
            return None
        capability = node.get("capability")
        return capability if isinstance(capability, str) else None


@contextlib.contextmanager
def use_trace_recorder(recorder: TraceRecorder | None):
    token = _CURRENT_RECORDER.set(recorder)
    try:
        yield
    finally:
        _CURRENT_RECORDER.reset(token)


@contextlib.contextmanager
def use_current_node(node_id: str | None):
    token = _CURRENT_NODE_ID.set(node_id)
    try:
        yield
    finally:
        _CURRENT_NODE_ID.reset(token)


def current_recorder() -> TraceRecorder | None:
    return _CURRENT_RECORDER.get()


def current_node_id() -> str | None:
    return _CURRENT_NODE_ID.get()


def save_trace(workspace_root, trace: Trace) -> None:
    run_id = trace.get("run_id")
    if not isinstance(run_id, str) or not run_id:
        raise ValueError("trace.run_id must be a non-empty string.")
    path = workspace_layout_module.run_trace_path(workspace_root, run_id)
    file_ops_module.write_json_atomic(path, trace, sort_keys=False)


def load_trace(path) -> Trace:
    data = file_ops_module.read_json(path)
    if not isinstance(data, dict):
        raise ValueError("trace root must be an object.")
    return data


def token_summary(trace: Trace | None) -> dict[str, Any]:
    if not isinstance(trace, dict):
        return metrics_module.token_summary([])
    value = trace.get("token_usage")
    return value if isinstance(value, dict) else metrics_module.token_summary([])


def run_metrics_summary(trace: Trace | None) -> dict[str, Any]:
    if not isinstance(trace, dict):
        return metrics_module.run_summary([])
    nodes = []
    for node in trace.get("nodes", []) or []:
        if not isinstance(node, dict):
            continue
        item = {
            "type": "node",
            "node_id": node.get("node_id"),
            "capability": node.get("capability"),
            "duration_ms": node.get("duration_ms"),
            "ok": node.get("ok"),
            "exit_code": node.get("exit_code"),
            "result_paths": [],
            "artifact_count": node.get("artifact_count", 0),
            "warning_count": node.get("warning_count", 0),
            "execution_results": node.get("execution_results", []),
        }
        if isinstance(node.get("approval"), dict):
            item["approval"] = node["approval"]
        if isinstance(node.get("failure_signals"), list):
            item["failure_signals"] = node["failure_signals"]
        if isinstance(node.get("capability_statuses"), list):
            item["capability_statuses"] = node["capability_statuses"]
        nodes.append(item)
    return metrics_module.run_summary(nodes)


def _node_observations(
    node_id: str,
    capability: str,
    before_state: Any,
    after_state: Any,
    duration_ms: int,
) -> dict[str, Any]:
    event = {
        "type": "node",
        "node_id": node_id,
        "capability": capability,
        "duration_ms": duration_ms,
        **metrics_module.node_result_summary(after_state),
    }
    approval = metrics_module._approval_summary(after_state)
    if approval:
        event["approval"] = approval
    execution = metrics_module._new_execution_summaries(before_state, after_state)
    if execution:
        event["execution_results"] = execution
    failure_signals = metrics_module._new_failure_signals(before_state, after_state)
    if failure_signals:
        event["failure_signals"] = failure_signals
    capability_statuses = metrics_module._new_capability_statuses(before_state, after_state)
    if capability_statuses:
        event["capability_statuses"] = capability_statuses
    return metrics_module.run_summary([event])


def _instruction_summary(instruction: dict[str, Any]) -> dict[str, Any]:
    payload = instruction.get("payload")
    return {
        "id": instruction.get("id"),
        "type": instruction.get("type"),
        "cwd": instruction.get("cwd"),
        "timeout_seconds": instruction.get("timeout_seconds"),
        "payload_keys": sorted(payload) if isinstance(payload, dict) else [],
    }


def _result_summary(result: dict[str, Any]) -> dict[str, Any]:
    stdout = result.get("stdout")
    stderr = result.get("stderr")
    metadata = result.get("metadata") if isinstance(result.get("metadata"), dict) else {}
    track_files = metadata.get("track_files") if isinstance(metadata.get("track_files"), dict) else {}
    summary = {
        "instruction_id": result.get("instruction_id"),
        "ok": result.get("ok"),
        "exit_code": result.get("exit_code"),
        "stdout_size": len(stdout) if isinstance(stdout, str) else 0,
        "stderr_size": len(stderr) if isinstance(stderr, str) else 0,
        "stdout_preview": _preview_lines(stdout) if isinstance(stdout, str) else [],
        "stderr_preview": _preview_lines(stderr) if isinstance(stderr, str) else [],
        "stdout_path": metadata.get("stdout_path") or track_files.get("stdout"),
        "stderr_path": metadata.get("stderr_path") or track_files.get("stderr"),
        "artifacts": result.get("artifacts") if isinstance(result.get("artifacts"), list) else [],
        "changed_files": result.get("changed_files") if isinstance(result.get("changed_files"), list) else [],
        "timeout": metadata.get("timeout"),
        "model": metadata.get("model"),
        "prompt_path": metadata.get("prompt_path") or metadata.get("main_prompt_path"),
        "context_paths": metadata.get("context_paths"),
    }
    token_usage = metadata.get("token_usage")
    if isinstance(token_usage, dict):
        summary["token_usage"] = metrics_module._normalize_usage(token_usage)
    return summary


def _preview_lines(text: str, max_lines: int = 3) -> list[str]:
    return [line.strip() for line in text.splitlines()[:max_lines] if line.strip()]


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()
