﻿import pathlib
from typing import Any

import lgwf.runs.eval_schema as eval_schema_module
import lgwf.runs.trace as trace_module
import lgwf.file_ops as file_ops_module


EvalCase = dict[str, Any]

CASE_FILE = "case.json"
SPEC_FILE = "spec.json"
GOLDEN_TRACE_FILE = "golden_trace.json"
CASE_KINDS = {"runtime_contract", "project_regression"}


class EvalCaseError(ValueError):
    """Raised when an eval case directory is invalid."""


def load_eval_case(case_dir: str | pathlib.Path) -> EvalCase:
    root = pathlib.Path(case_dir)
    case = _read_required_object(root / CASE_FILE, "eval case metadata")
    spec = _read_required_object(root / SPEC_FILE, "eval case spec")
    golden_trace_path = root / GOLDEN_TRACE_FILE
    if not golden_trace_path.is_file():
        raise EvalCaseError(f"eval case missing required file: {golden_trace_path}")
    golden_trace = trace_module.load_trace(golden_trace_path)

    _validate_case_metadata(case, root.name)
    try:
        eval_schema_module.validate_eval_spec(spec)
    except eval_schema_module.EvalSpecValidationError as exc:
        raise EvalCaseError(f"eval case spec is invalid: {root}") from exc
    return {
        "case_dir": str(root),
        "case": case,
        "spec": spec,
        "golden_trace": golden_trace,
    }


def load_eval_cases(cases_dir: str | pathlib.Path) -> list[EvalCase]:
    root = pathlib.Path(cases_dir)
    if not root.is_dir():
        raise EvalCaseError(f"eval cases dir not found: {root}")
    case_dirs = sorted(path for path in root.iterdir() if path.is_dir())
    if not case_dirs:
        raise EvalCaseError(f"eval cases dir contains no case directories: {root}")
    return [load_eval_case(path) for path in case_dirs]


def _read_required_object(path: pathlib.Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise EvalCaseError(f"eval case missing required file: {path}")
    try:
        data = file_ops_module.read_json_object(path, label=label)
    except file_ops_module.FileOperationError as exc:
        raise EvalCaseError(str(exc)) from exc
    return data


def _validate_case_metadata(case: dict[str, Any], expected_case_id: str) -> None:
    version = case.get("version")
    if version != 1:
        raise EvalCaseError("eval case metadata field 'version' must be 1.")
    case_id = case.get("case_id")
    if case_id != expected_case_id:
        raise EvalCaseError(f"eval case metadata case_id must match directory name: {expected_case_id}")
    description = case.get("description")
    if not isinstance(description, str) or not description:
        raise EvalCaseError("eval case metadata field 'description' must be a non-empty string.")
    tags = case.get("tags")
    if not isinstance(tags, list) or any(not isinstance(item, str) for item in tags):
        raise EvalCaseError("eval case metadata field 'tags' must be a list of strings.")
    kind = case.get("kind")
    if kind not in CASE_KINDS:
        raise EvalCaseError("eval case metadata field 'kind' must be runtime_contract or project_regression.")
