from __future__ import annotations

import contextlib
import contextvars
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import lgwf.capabilities.route_keys as route_key_module
import lgwf.checkpoints as checkpoints_module
import lgwf.control_flow as control_flow_module


_RESUME_TARGET: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "lgwf_resume_target",
    default=None,
)
REACT_SLOTS = ("reason", "act", "observe", "decide")


@contextlib.contextmanager
def use_resume_target(node_id: str | None):
    token = _RESUME_TARGET.set(node_id)
    try:
        yield
    finally:
        _RESUME_TARGET.reset(token)


def get_resume_target() -> str | None:
    return _RESUME_TARGET.get()


@dataclass(frozen=True)
class ResumePlan:
    can_resume: bool
    strategy: str
    resume_from: str | None
    state_source: str | None
    input_state: dict[str, Any] | None
    work_dir: str
    warnings: list[str]
    node_resume: dict[str, Any]
    reason: str | None = None


def build_resume_plan(
    dsl: dict[str, Any],
    checkpoint: dict[str, Any],
    *,
    work_dir: Path,
    allow_workflow_changed: bool,
    orphaned_running: bool,
) -> ResumePlan:
    warnings: list[str] = []
    hash_warning = _workflow_hash_warning(dsl, checkpoint)
    if hash_warning is not None:
        if not allow_workflow_changed and not orphaned_running:
            return _blocked_plan(work_dir, f"workflow hash mismatch; {hash_warning}")
        warnings.append(hash_warning)

    status = checkpoint.get("status")
    if orphaned_running:
        if status != "running":
            return _blocked_plan(work_dir, "orphaned running resume requires a running checkpoint.")
    elif status not in {"failed", "stopped"}:
        return _blocked_plan(work_dir, "resume checkpoint status must be failed or stopped.")

    current_node = _string_value(checkpoint.get("current_node"))
    failed_node = _string_value(checkpoint.get("failed_node"))
    target_node = current_node or failed_node
    if target_node is not None:
        state = checkpoint.get("state_before_current_node")
        if not isinstance(state, dict):
            return _blocked_plan(work_dir, "resume checkpoint missing state_before_current_node.")
        resume_from = entry_point_for_target(dsl, target_node) or target_node
        if not _is_current_layer_node(dsl, resume_from):
            return _blocked_plan(work_dir, f"resume target is not a current workflow node: {target_node}")
        return ResumePlan(
            can_resume=True,
            strategy="current_node",
            resume_from=resume_from,
            state_source="state_before_current_node",
            input_state=state,
            work_dir=str(work_dir),
            warnings=warnings,
            node_resume=_node_resume_plan(dsl, resume_from, target_node),
        )

    last_completed_node = _string_value(checkpoint.get("last_completed_node"))
    if last_completed_node is None:
        return _blocked_plan(work_dir, "resume checkpoint missing current_node and last_completed_node.")
    state_after = checkpoint.get("state_after_last_completed_node")
    if not isinstance(state_after, dict):
        return _blocked_plan(work_dir, "resume checkpoint missing state_after_last_completed_node.")
    successor = next_node_after_completed(dsl, last_completed_node, state_after)
    if not successor.can_resume:
        return ResumePlan(
            can_resume=False,
            strategy="after_last_completed",
            resume_from=None,
            state_source="state_after_last_completed_node",
            input_state=None,
            work_dir=str(work_dir),
            warnings=warnings,
            node_resume={"mode": "none"},
            reason=successor.reason,
        )
    return ResumePlan(
        can_resume=True,
        strategy="after_last_completed",
        resume_from=successor.node_id,
        state_source="state_after_last_completed_node",
        input_state=state_after,
        work_dir=str(work_dir),
        warnings=warnings,
        node_resume=_node_resume_plan(dsl, successor.node_id, successor.node_id),
    )


def entry_point_for_target(dsl: dict[str, Any], target_node: str | None) -> str | None:
    if not target_node:
        return None
    nodes = dsl.get("nodes")
    if not isinstance(nodes, list):
        return None
    node_by_id = {node.get("id"): node for node in nodes if isinstance(node, dict)}
    if target_node in node_by_id:
        return target_node
    for node_id, node in node_by_id.items():
        if not isinstance(node_id, str):
            continue
        if _node_contains_resume_target(node, target_node):
            return node_id
    return None


@dataclass(frozen=True)
class SuccessorPlan:
    can_resume: bool
    node_id: str | None = None
    reason: str | None = None


def next_node_after_completed(dsl: dict[str, Any], node_id: str, state: dict[str, Any]) -> SuccessorPlan:
    nodes = dsl.get("nodes")
    if not isinstance(nodes, list):
        return SuccessorPlan(False, reason="DSL nodes must be a list.")
    node_ids = {node.get("id") for node in nodes if isinstance(node, dict)}
    if node_id not in node_ids:
        return SuccessorPlan(False, reason=f"last_completed_node is not a current workflow node: {node_id}")

    route_target = _route_target_after_completed(dsl, node_id, state)
    if route_target is not None:
        return route_target
    outgoing = [
        edge[1]
        for edge in dsl.get("edges", [])
        if isinstance(edge, list)
        and len(edge) == 2
        and edge[0] == node_id
        and isinstance(edge[1], str)
    ]
    if len(outgoing) == 1:
        return SuccessorPlan(True, node_id=outgoing[0])
    if len(outgoing) > 1:
        return SuccessorPlan(False, reason=f"ambiguous successors after last_completed_node={node_id}.")
    return SuccessorPlan(False, reason=f"no resumable successor after last_completed_node={node_id}.")


def _node_contains_resume_target(node: dict[str, Any], target_node: str) -> bool:
    capability = node.get("capability")
    node_id = node.get("id")
    config = node.get("config")
    if capability == "subgraph.workflow" and isinstance(config, dict):
        workflow = config.get("workflow")
        return isinstance(workflow, dict) and entry_point_for_target(workflow, target_node) is not None
    if capability == "subgraph.react" and isinstance(node_id, str) and isinstance(config, dict):
        return _react_contains_resume_target(node_id, config, target_node)
    return False


def _react_contains_resume_target(node_id: str, config: dict[str, Any], target_node: str) -> bool:
    for slot_name in REACT_SLOTS:
        slot_node_id = f"{node_id}__{slot_name}"
        if target_node == slot_node_id:
            return True
        slot = config.get(slot_name)
        if not isinstance(slot, dict) or slot.get("capability") != "subgraph.workflow":
            continue
        slot_config = slot.get("config")
        if not isinstance(slot_config, dict):
            continue
        workflow = slot_config.get("workflow")
        if isinstance(workflow, dict) and entry_point_for_target(workflow, target_node) is not None:
            return True
    return False


def _workflow_hash_warning(dsl: dict[str, Any], checkpoint: dict[str, Any]) -> str | None:
    current_hash = checkpoints_module.workflow_hash(dsl)
    if checkpoint.get("workflow_hash") == current_hash:
        return None
    return "workflow hash changed"


def _blocked_plan(work_dir: Path, reason: str) -> ResumePlan:
    return ResumePlan(
        can_resume=False,
        strategy="blocked",
        resume_from=None,
        state_source=None,
        input_state=None,
        work_dir=str(work_dir),
        warnings=[],
        node_resume={"mode": "none"},
        reason=reason,
    )


def _string_value(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _is_current_layer_node(dsl: dict[str, Any], node_id: str) -> bool:
    nodes = dsl.get("nodes")
    if not isinstance(nodes, list):
        return False
    return any(isinstance(node, dict) and node.get("id") == node_id for node in nodes)


def _node_resume_plan(dsl: dict[str, Any], resume_from: str, target_node: str) -> dict[str, Any]:
    node = _node_by_id(dsl, resume_from)
    capability = node.get("capability") if isinstance(node, dict) else None
    if capability == "flow.run_workflow":
        return {
            "mode": "delegate",
            "reason": "RUN_WORKFLOW owns child checkpoint",
            "target_node": target_node,
        }
    if target_node != resume_from:
        return {
            "mode": "delegate",
            "reason": f"{capability} owns nested resume target",
            "target_node": target_node,
        }
    return {"mode": "rerun", "target_node": target_node}


def _node_by_id(dsl: dict[str, Any], node_id: str) -> dict[str, Any] | None:
    nodes = dsl.get("nodes")
    if not isinstance(nodes, list):
        return None
    for node in nodes:
        if isinstance(node, dict) and node.get("id") == node_id:
            return node
    return None


def _route_target_after_completed(dsl: dict[str, Any], node_id: str, state: dict[str, Any]) -> SuccessorPlan | None:
    for route in dsl.get("routes", []):
        if not isinstance(route, dict) or route.get("from") != node_id:
            continue
        branches = route.get("branches")
        if not isinstance(branches, dict):
            return SuccessorPlan(False, reason=f"route from {node_id} has invalid branches.")
        route_key = route_key_module.route_key_for(node_id)
        branch_key = state.get(route_key)
        if not isinstance(branch_key, str):
            return SuccessorPlan(False, reason=f"route key missing for last_completed_node={node_id}.")
        target = branches.get(branch_key)
        if not isinstance(target, str) or control_flow_module.is_fail_all_target(target):
            return SuccessorPlan(False, reason=f"route branch is not resumable after last_completed_node={node_id}.")
        return SuccessorPlan(True, node_id=target)
    return None
