﻿import datetime
import uuid
from pathlib import Path
from typing import Any

import lgwf.file_ops as file_ops_module
import lgwf.workspace_layout as workspace_layout_module


class HandoffError(ValueError):
    """Raised when handoff pending action files are invalid."""


def create_pending_action(
    workspace_root: Path,
    action: dict[str, Any],
    request_id: str | None = None,
) -> dict[str, Any]:
    pending_action = dict(action)
    pending_action["request_id"] = request_id or _request_id(pending_action)
    _validate_pending_action(pending_action)
    pending_action.setdefault("created_at", _utc_now())
    path = workspace_layout_module.handoff_pending_path(workspace_root.resolve(), pending_action["request_id"])
    file_ops_module.write_json_atomic(path, pending_action)
    return pending_action


def list_pending_actions(workspace_root: Path) -> list[dict[str, Any]]:
    handoff_dir = workspace_layout_module.handoff_dir(workspace_root.resolve())
    if not handoff_dir.exists():
        return []
    actions: list[dict[str, Any]] = []
    paths = sorted(handoff_dir.glob("*.pending.json"), key=_safe_mtime, reverse=True)
    for path in paths:
        if not path.is_file():
            continue
        action = _load_json(path)
        _validate_pending_action(action)
        actions.append(action)
    return actions


def _request_id(action: dict[str, Any]) -> str:
    existing = action.get("request_id")
    if isinstance(existing, str) and existing:
        return existing
    return f"handoff-{uuid.uuid4().hex[:12]}"


def _validate_pending_action(action: dict[str, Any]) -> None:
    if not isinstance(action, dict):
        raise HandoffError("handoff pending action must be a JSON object.")
    if action.get("type") != "agent_handoff":
        raise HandoffError("handoff pending action type must be agent_handoff.")
    request_id = action.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise HandoffError("handoff request_id must be a non-empty string.")
    if "/" in request_id or "\\" in request_id or ".." in request_id:
        raise HandoffError("handoff request_id must not contain path separators or '..'.")
    if action.get("next_action") != "start_workflow":
        raise HandoffError("handoff next_action must be start_workflow.")
    workflow_id = action.get("workflow_id")
    if not isinstance(workflow_id, str) or not workflow_id:
        raise HandoffError("handoff workflow_id must be a non-empty string.")
    agent_instruction = action.get("agent_instruction")
    if not isinstance(agent_instruction, str) or not agent_instruction:
        raise HandoffError("handoff agent_instruction must be a non-empty string.")
    if not isinstance(action.get("requires_user_confirmation"), bool):
        raise HandoffError("handoff requires_user_confirmation must be a boolean.")
    if action.get("auto_execute") is not False:
        raise HandoffError("handoff auto_execute must be false.")


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = file_ops_module.read_json(path)
    except file_ops_module.FileOperationError as exc:
        raise HandoffError(f"handoff pending action is not valid JSON: {path}") from exc
    if not isinstance(data, dict):
        raise HandoffError(f"handoff pending action must be a JSON object: {path}")
    return data


def _safe_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except FileNotFoundError:
        return 0.0


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()
