from typing import Any

import lgwf.capabilities.route_keys as route_key_module
import lgwf.capabilities.types as capability_types
import lgwf.progress as progress_module


FAIL_ALL_TARGET = "FAIL_ALL"
FAIL_ALL_CAPABILITY = "control.fail_all"
INTERNAL_FAIL_ALL_PREFIX = "__lgwf_fail_all__"


class FailAllWorkflowError(RuntimeError):
    """Raised when a workflow route targets FAIL_ALL."""


def is_fail_all_target(target: str) -> bool:
    return target == FAIL_ALL_TARGET


def is_reserved_node_id(node_id: str) -> bool:
    return node_id == FAIL_ALL_TARGET or node_id.startswith(INTERNAL_FAIL_ALL_PREFIX)


def internal_fail_all_node_id(source_node_id: str) -> str:
    return f"{INTERNAL_FAIL_ALL_PREFIX}{source_node_id}"


def create_fail_all_node(source_node_id: str) -> capability_types.NodeCallable:
    def node(state: capability_types.State) -> capability_types.State:
        route_key = route_key_module.route_key_for(source_node_id)
        route_value = state.get(route_key)
        reason = _failure_reason(state)
        message = f"FAIL_ALL triggered by node '{source_node_id}'"
        if isinstance(route_value, str) and route_value:
            message = f"{message} route='{route_value}'"
        if reason:
            message = f"{message}: {reason}"
        failure = {
            "node_id": source_node_id,
            "capability": FAIL_ALL_CAPABILITY,
            "error_type": "FailAllWorkflowError",
            "message": message,
            "failed_by": FAIL_ALL_TARGET,
        }
        if isinstance(route_value, str) and route_value:
            failure["route"] = route_value
        progress_module.emit(f"[workflow] FAIL_ALL node={source_node_id} reason={reason or '<none>'}")
        exc = FailAllWorkflowError(message)
        setattr(exc, "__lgwf_failure__", failure)
        raise exc

    return node


def _failure_reason(value: Any) -> str | None:
    direct = _direct_reason(value)
    if direct:
        return direct
    if isinstance(value, dict):
        for item in value.values():
            reason = _failure_reason(item)
            if reason:
                return reason
    if isinstance(value, list):
        for item in value:
            reason = _failure_reason(item)
            if reason:
                return reason
    return None


def _direct_reason(value: Any) -> str | None:
    if not isinstance(value, dict):
        return None
    decision = value.get("decision") or value.get("approval")
    if decision != "reject":
        return None
    comment = value.get("comment")
    if isinstance(comment, str) and comment.strip():
        return comment.strip()
    reason = value.get("reason")
    if isinstance(reason, str) and reason.strip():
        return reason.strip()
    return "reject"
