﻿from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path

import lgwf.workspace_layout as workspace_layout_module


EXCLUDED_DIR_NAMES = {".git", ".lgwf", "__pycache__"}


@dataclass(frozen=True)
class IsolationAllocation:
    root: Path
    workspace: Path
    work_dir: Path


def prepare_isolation(
    *,
    parent_work_dir: Path,
    source_workspace: Path,
    namespace: str,
    key: str,
) -> IsolationAllocation:
    root = workspace_layout_module.isolation_run_dir(parent_work_dir, namespace, key)
    if root.exists():
        shutil.rmtree(root)
    workspace = root / "workspace"
    work_dir = root / "work_dir"
    _copy_workspace(source_workspace.resolve(), workspace)
    work_dir.mkdir(parents=True, exist_ok=True)
    return IsolationAllocation(root=root, workspace=workspace, work_dir=work_dir)


def existing_isolation(
    *,
    parent_work_dir: Path,
    namespace: str,
    key: str,
) -> IsolationAllocation:
    root = workspace_layout_module.isolation_run_dir(parent_work_dir, namespace, key)
    return IsolationAllocation(root=root, workspace=root / "workspace", work_dir=root / "work_dir")


def refresh_workspace(*, source_workspace: Path, destination_workspace: Path) -> None:
    if destination_workspace.exists():
        if not destination_workspace.is_dir() or destination_workspace.is_symlink():
            raise ValueError(f"destination workspace is not a directory: {destination_workspace}")
        shutil.rmtree(destination_workspace)
    _copy_workspace(source_workspace.resolve(), destination_workspace)


def _copy_workspace(source_root: Path, destination_root: Path) -> None:
    if not source_root.is_dir():
        raise ValueError(f"source workspace does not exist: {source_root}")
    for current_root, dir_names, file_names in os.walk(source_root):
        current_path = Path(current_root)
        relative_root = current_path.relative_to(source_root)
        dir_names[:] = [
            name
            for name in dir_names
            if name not in EXCLUDED_DIR_NAMES and not (current_path / name).is_symlink()
        ]
        target_root = destination_root / relative_root
        target_root.mkdir(parents=True, exist_ok=True)
        for file_name in file_names:
            if file_name.endswith(".pyc"):
                continue
            source_file = current_path / file_name
            if source_file.is_symlink():
                continue
            shutil.copy2(source_file, target_root / file_name)
