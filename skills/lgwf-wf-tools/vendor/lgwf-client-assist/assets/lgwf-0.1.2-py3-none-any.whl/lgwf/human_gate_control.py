import datetime
from pathlib import Path
from typing import Any

import lgwf.file_ops as file_ops_module
import lgwf.workspace_layout as workspace_layout_module


AUTO_APPROVE_MODE = "auto_approve"
MANUAL_MODE = "manual"


def policy_path(workspace_root: str | Path) -> Path:
    return workspace_layout_module.human_gate_policy_path(Path(workspace_root).resolve())


def load_policy(workspace_root: str | Path) -> dict[str, Any] | None:
    path = policy_path(workspace_root)
    if not path.is_file():
        return None
    return _validate_policy(file_ops_module.read_json_object(path, label="human gate policy"))


def write_policy(
    workspace_root: str | Path,
    *,
    enabled: bool,
    updated_by: str = "cli",
) -> dict[str, Any]:
    policy = {
        "mode": AUTO_APPROVE_MODE if enabled else MANUAL_MODE,
        "auto": enabled,
        "updated_by": updated_by,
        "updated_at": datetime.datetime.now(datetime.UTC).isoformat(),
    }
    file_ops_module.write_json_atomic(policy_path(workspace_root), policy)
    return policy


def clear_policy(workspace_root: str | Path) -> bool:
    path = policy_path(workspace_root)
    if not path.exists():
        return False
    path.unlink()
    return True


def _validate_policy(policy: dict[str, Any]) -> dict[str, Any]:
    auto = policy.get("auto")
    if not isinstance(auto, bool):
        raise file_ops_module.FileOperationError("human gate policy auto must be a boolean.")
    mode = policy.get("mode")
    if not isinstance(mode, str) or not mode:
        raise file_ops_module.FileOperationError("human gate policy mode must be a non-empty string.")
    expected_mode = AUTO_APPROVE_MODE if auto else MANUAL_MODE
    if mode != expected_mode:
        raise file_ops_module.FileOperationError(f"human gate policy auto={str(auto).lower()} requires mode={expected_mode}.")
    return dict(policy)
