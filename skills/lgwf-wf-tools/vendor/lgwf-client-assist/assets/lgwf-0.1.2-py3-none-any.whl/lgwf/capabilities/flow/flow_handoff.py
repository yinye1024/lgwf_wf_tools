from pathlib import Path
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.types as capability_types
import lgwf.handoff as handoff_module
import lgwf.progress as progress_module
import lgwf.runtime_context as runtime_context_module


class FlowHandoffCapability:
    name = "flow.handoff"

    def create_node(self, _node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        prompt = config.get("prompt")
        prompt_ref = config.get("prompt_ref")
        context_path = config.get("context_path")
        result_path = config.get("result_path", "handoff")
        agent_instruction = config.get("agent_instruction", "handle_handoff")
        auto_execute = config.get("auto_execute", False)

        if (prompt is None) == (prompt_ref is None):
            raise ValueError("flow.handoff config requires exactly one of prompt or prompt_ref.")
        if prompt is not None and (not isinstance(prompt, str) or not prompt.strip()):
            raise ValueError("flow.handoff config.prompt must be a non-empty string.")
        if not isinstance(context_path, str) or not context_path:
            raise ValueError("flow.handoff config.context_path must be a non-empty string.")
        if not isinstance(result_path, str) or not result_path:
            raise ValueError("flow.handoff config.result_path must be a non-empty string.")
        if not isinstance(agent_instruction, str) or not agent_instruction:
            raise ValueError("flow.handoff config.agent_instruction must be a non-empty string.")
        if auto_execute is not False:
            raise ValueError("flow.handoff auto_execute=true is not supported.")

        def node(state: capability_types.State) -> capability_types.State:
            workspace_root = runtime_context_module.get_workspace_root()
            if workspace_root is None:
                raise RuntimeError("flow.handoff requires a runtime workspace root.")
            resolved_prompt = prompt if prompt is not None else _read_workflow_prompt(prompt_ref)
            payload = flow_conditions_module.read_path(state, context_path)
            if not isinstance(payload, dict):
                raise ValueError("flow.handoff context_path must resolve to a JSON object.")
            pending_action = handoff_module.create_pending_action(
                workspace_root,
                _pending_action(payload, resolved_prompt, agent_instruction),
            )
            progress_module.emit(
                f"[workflow] agent handoff pending request_id={pending_action['request_id']} "
                f"workflow_id={pending_action['workflow_id']}"
            )
            result = {
                "request_id": pending_action["request_id"],
                "type": "agent_handoff",
                "pending_action": pending_action,
            }
            return flow_conditions_module.write_path(dict(state), result_path, result)

        return node


CAPABILITY = FlowHandoffCapability()


def _pending_action(payload: dict[str, Any], prompt: str, agent_instruction: str) -> dict[str, Any]:
    workflow_id = payload.get("workflow_id") or payload.get("next_workflow_id")
    next_action = payload.get("next_action", handoff_module.NEXT_ACTION_START_WORKFLOW)
    action = {
        "type": "agent_handoff",
        "next_action": next_action,
        "workflow_id": workflow_id,
        "next_workflow_id": payload.get("next_workflow_id", workflow_id),
        "workflow_lgwf": payload.get("workflow_lgwf"),
        "work_dir": payload.get("work_dir"),
        "input_json_file": payload.get("input_json_file"),
        "suggested_command": payload.get("suggested_command"),
        "source_artifacts": payload.get("source_artifacts", []),
        "requires_user_confirmation": payload.get("requires_user_confirmation", True),
        "auto_execute": False,
        "agent_instruction": _agent_instruction(payload, next_action, agent_instruction),
        "prompt": prompt,
        "payload": payload,
    }
    if isinstance(payload.get("request_id"), str):
        action["request_id"] = payload["request_id"]
    return action


def _agent_instruction(payload: dict[str, Any], next_action: Any, configured_instruction: str) -> str:
    payload_instruction = payload.get("agent_instruction")
    if isinstance(payload_instruction, str) and payload_instruction:
        return payload_instruction
    if (
        next_action == handoff_module.NEXT_ACTION_MAIN_AGENT_AUTHORING
        and configured_instruction == "handle_handoff"
    ):
        return "handle_main_agent_authoring"
    return configured_instruction


def _read_workflow_prompt(prompt_ref: Any) -> str:
    if not isinstance(prompt_ref, dict):
        raise ValueError("flow.handoff config.prompt_ref must be an object.")
    if prompt_ref.get("root") != "workflow":
        raise ValueError("flow.handoff config.prompt_ref.root must be workflow.")
    raw_path = prompt_ref.get("path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("flow.handoff config.prompt_ref.path must be a non-empty string.")
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("flow.handoff config.prompt_ref.path must be relative and must not contain '..'.")
    workflow_root = runtime_context_module.get_workflow_root()
    if workflow_root is None:
        raise RuntimeError("flow.handoff prompt_ref requires a runtime workflow root.")
    resolved = (workflow_root / path).resolve()
    if not resolved.is_relative_to(workflow_root):
        raise ValueError("flow.handoff config.prompt_ref.path must stay inside the workflow root.")
    if not resolved.is_file():
        raise ValueError(f"flow.handoff prompt_ref does not exist or is not a file: {resolved}")
    return resolved.read_text(encoding="utf-8")
