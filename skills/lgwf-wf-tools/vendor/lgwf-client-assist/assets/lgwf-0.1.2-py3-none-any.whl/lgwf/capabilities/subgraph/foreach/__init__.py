"""subgraph.foreach capability."""

from lgwf.capabilities.subgraph.foreach.capability import CAPABILITY


def register_into(registry_module) -> None:
    registry_module.register(CAPABILITY)
