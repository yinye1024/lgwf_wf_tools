import json
from pathlib import Path
from typing import Any

import lgwf.capabilities.policy.registry as policy_registry_module
import lgwf.capabilities.registry as capability_registry_module


Catalog = dict[str, Any]
CatalogEntry = dict[str, Any]

CATALOG_PATH = Path(__file__).with_name("catalog.json")


class CatalogLoadError(ValueError):
    """Raised when the capability catalog cannot be loaded."""


class CatalogValidationError(ValueError):
    """Raised when the capability catalog is invalid."""


def load_catalog(path: Path = CATALOG_PATH) -> Catalog:
    try:
        content = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise CatalogLoadError(f"Capability catalog file not found: {path}") from exc
    except OSError as exc:
        raise CatalogLoadError(f"Failed to read capability catalog file: {path}") from exc

    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise CatalogLoadError(f"Capability catalog file is not valid JSON: {path}") from exc

    if not isinstance(data, dict):
        raise CatalogLoadError(f"Capability catalog root must be a JSON object: {path}")

    validate_catalog(data)
    return data


def validate_catalog(catalog: Catalog) -> None:
    version = catalog.get("version")
    if not isinstance(version, int) or version < 1:
        raise CatalogValidationError("Capability catalog must include a positive integer version.")

    entries = catalog.get("capabilities")
    if not isinstance(entries, list) or not entries:
        raise CatalogValidationError("Capability catalog must include a non-empty capabilities list.")

    seen_names: set[str] = set()
    for entry in entries:
        _validate_entry(entry, seen_names)

    _validate_registry_coverage(seen_names)


def catalog_entries(catalog: Catalog) -> list[CatalogEntry]:
    entries = catalog["capabilities"]
    return list(entries)


def entry_by_name(catalog: Catalog) -> dict[str, CatalogEntry]:
    return {
        entry["name"]: entry
        for entry in catalog_entries(catalog)
    }


def _validate_entry(entry: Any, seen_names: set[str]) -> None:
    if not isinstance(entry, dict):
        raise CatalogValidationError("Capability catalog entries must be objects.")

    name = entry.get("name")
    if not isinstance(name, str) or not name:
        raise CatalogValidationError("Capability catalog entry must include a non-empty name.")
    if name in seen_names:
        raise CatalogValidationError(f"Duplicate capability catalog entry: {name}")
    seen_names.add(name)

    kind = entry.get("kind")
    if kind not in {"exec", "flow", "policy", "subgraph"}:
        raise CatalogValidationError(f"Capability catalog entry '{name}' has invalid kind.")

    _require_string(entry, "description", name)
    _require_object(entry, "config_schema", name)
    _require_string_list(entry, "reads", name)
    _require_string_list(entry, "writes", name)
    _require_string_list(entry, "side_effects", name)
    _require_bool(entry, "destructive", name)
    _require_string_list(entry, "permissions", name, allow_empty=False)
    _require_object(entry, "input_schema", name)
    _require_object(entry, "output_schema", name)
    _require_string_list(entry, "error_codes", name)
    _require_idempotency(entry, name)
    _require_retry_semantics(entry, name)
    _require_timeout_expectation(entry, name)
    _require_artifact_contract(entry, name)
    _require_error_taxonomy(entry, name)
    _require_string_list(entry, "when_to_use", name, allow_empty=False)
    _require_string_list(entry, "when_not_to_use", name, allow_empty=False)

    examples = entry.get("examples")
    if not isinstance(examples, list) or not examples:
        raise CatalogValidationError(f"Capability catalog entry '{name}' examples must be a non-empty list.")

    if kind == "policy":
        if not policy_registry_module.has_policy(name):
            raise CatalogValidationError(f"Catalog policy is not registered: {name}")
    elif not capability_registry_module.has_capability(name):
        raise CatalogValidationError(f"Catalog capability is not registered: {name}")


def _validate_registry_coverage(catalog_names: set[str]) -> None:
    missing_capabilities = sorted(set(capability_registry_module.REGISTRY) - catalog_names)
    if missing_capabilities:
        joined = ", ".join(missing_capabilities)
        raise CatalogValidationError(f"Registered capabilities missing from catalog: {joined}")

    missing_policies = sorted(set(policy_registry_module.REGISTRY) - catalog_names)
    if missing_policies:
        joined = ", ".join(missing_policies)
        raise CatalogValidationError(f"Registered policies missing from catalog: {joined}")


def _require_string(entry: CatalogEntry, field: str, name: str) -> None:
    value = entry.get(field)
    if not isinstance(value, str) or not value:
        raise CatalogValidationError(f"Capability catalog entry '{name}' field '{field}' must be a non-empty string.")


def _require_object(entry: CatalogEntry, field: str, name: str) -> None:
    value = entry.get(field)
    if not isinstance(value, dict):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field '{field}' must be an object.")


def _require_bool(entry: CatalogEntry, field: str, name: str) -> None:
    value = entry.get(field)
    if not isinstance(value, bool):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field '{field}' must be a boolean.")


def _require_string_list(entry: CatalogEntry, field: str, name: str, *, allow_empty: bool = True) -> None:
    value = entry.get(field)
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field '{field}' must be a list of strings.")
    if not allow_empty and not value:
        raise CatalogValidationError(f"Capability catalog entry '{name}' field '{field}' must not be empty.")


def _require_idempotency(entry: CatalogEntry, name: str) -> None:
    value = entry.get("idempotency")
    if value not in {"idempotent", "conditionally_idempotent", "non_idempotent"}:
        raise CatalogValidationError(
            f"Capability catalog entry '{name}' field 'idempotency' must be idempotent, conditionally_idempotent, or non_idempotent."
        )


def _require_retry_semantics(entry: CatalogEntry, name: str) -> None:
    value = entry.get("retry_semantics")
    if not isinstance(value, dict):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'retry_semantics' must be an object.")
    safe = value.get("safe")
    strategy = value.get("strategy")
    if not isinstance(safe, bool):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'retry_semantics.safe' must be a boolean.")
    if not isinstance(strategy, str) or not strategy:
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'retry_semantics.strategy' must be a non-empty string.")


def _require_timeout_expectation(entry: CatalogEntry, name: str) -> None:
    value = entry.get("timeout_expectation")
    if not isinstance(value, dict):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'timeout_expectation' must be an object.")
    default_seconds = value.get("default_seconds")
    if not isinstance(default_seconds, int) or default_seconds < 0:
        raise CatalogValidationError(
            f"Capability catalog entry '{name}' field 'timeout_expectation.default_seconds' must be a non-negative integer."
        )


def _require_artifact_contract(entry: CatalogEntry, name: str) -> None:
    value = entry.get("artifact_contract")
    if not isinstance(value, dict):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'artifact_contract' must be an object.")
    for field in ("produces", "consumes"):
        items = value.get(field)
        if not isinstance(items, list) or any(not isinstance(item, str) for item in items):
            raise CatalogValidationError(
                f"Capability catalog entry '{name}' field 'artifact_contract.{field}' must be a list of strings."
            )


def _require_error_taxonomy(entry: CatalogEntry, name: str) -> None:
    taxonomy = entry.get("error_taxonomy")
    codes = entry.get("error_codes")
    if not isinstance(taxonomy, list):
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy' must be a list.")
    if codes and not taxonomy:
        raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy' must be a non-empty list.")
    taxonomy_codes: set[str] = set()
    for item in taxonomy:
        if not isinstance(item, dict):
            raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy' entries must be objects.")
        code = item.get("code")
        category = item.get("category")
        retryable = item.get("retryable")
        description = item.get("description")
        if not isinstance(code, str) or not code:
            raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy.code' must be a non-empty string.")
        if not isinstance(category, str) or not category:
            raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy.category' must be a non-empty string.")
        if not isinstance(retryable, bool):
            raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy.retryable' must be a boolean.")
        if not isinstance(description, str) or not description:
            raise CatalogValidationError(f"Capability catalog entry '{name}' field 'error_taxonomy.description' must be a non-empty string.")
        taxonomy_codes.add(code)
    if taxonomy_codes != set(codes):
        raise CatalogValidationError(
            f"Capability catalog entry '{name}' field 'error_taxonomy' must cover exactly error_codes."
        )

