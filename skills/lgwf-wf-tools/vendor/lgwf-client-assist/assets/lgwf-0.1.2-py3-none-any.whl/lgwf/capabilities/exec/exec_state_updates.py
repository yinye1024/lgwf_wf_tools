import json
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.types as capability_types


def apply_stdout_updates(
    capability_name: str,
    node_id: str,
    state: capability_types.State,
    stdout: Any,
    declared_paths: list[str] | None = None,
) -> capability_types.State:
    if not isinstance(stdout, str) or not stdout.strip():
        if declared_paths:
            raise ValueError(
                f"{capability_name} {node_id} declared stdout state update path was not written: "
                f"{declared_paths[0]}"
            )
        return state
    try:
        updates = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{capability_name} stdout state updates must be a JSON object.") from exc
    if not isinstance(updates, dict):
        raise ValueError(f"{capability_name} stdout state updates must be a JSON object.")

    update_paths = set()
    for path in updates:
        if not isinstance(path, str) or not path:
            raise ValueError(f"{capability_name} stdout state update keys must be non-empty string paths.")
        update_paths.add(path)

    if declared_paths is not None:
        declared = set(declared_paths)
        undeclared = sorted(update_paths - declared)
        if undeclared:
            raise ValueError(
                f"{capability_name} {node_id} stdout state update path is not declared: {undeclared[0]}"
            )
        missing = sorted(declared - update_paths)
        if missing:
            raise ValueError(
                f"{capability_name} {node_id} declared stdout state update path was not written: {missing[0]}"
            )

    next_state = state
    for path, value in updates.items():
        next_state = flow_conditions_module.write_path(next_state, path, value)
    return next_state
