import pathlib
from typing import Any

import lgwf.capabilities.types as capability_types
import lgwf.runtime_context as runtime_context_module


def validate_reads(
    capability_name: str,
    node_id: str,
    contract: Any,
    state: capability_types.State,
) -> None:
    parsed = _contract_or_none(contract)
    if parsed is None:
        return
    for path in parsed["reads_state"]:
        if not _state_has_path(state, path):
            raise ValueError(f"{capability_name} {node_id} CONTRACT READ state {path} missing")
    for resource in parsed["reads_resources"]:
        _validate_resource(capability_name, node_id, "READ", resource)


def validate_writes(
    capability_name: str,
    node_id: str,
    contract: Any,
    state: capability_types.State,
) -> None:
    parsed = _contract_or_none(contract)
    if parsed is None:
        return
    for path in parsed["writes_state"]:
        if not _state_has_path(state, path):
            raise ValueError(f"{capability_name} {node_id} CONTRACT WRITE state {path} missing")
    for resource in parsed["writes_resources"]:
        _validate_resource(capability_name, node_id, "WRITE", resource)


def _contract_or_none(contract: Any) -> dict[str, list[Any]] | None:
    if contract is None:
        return None
    if not isinstance(contract, dict):
        raise ValueError("exec.run_python config.contract must be an object when provided.")
    parsed: dict[str, list[Any]] = {}
    for field in ("reads_state", "writes_state", "reads_resources", "writes_resources"):
        value = contract.get(field, [])
        if not isinstance(value, list):
            raise ValueError(f"exec.run_python config.contract.{field} must be an array.")
        parsed[field] = value
    for field in ("reads_state", "writes_state"):
        if any(not isinstance(item, str) or not item for item in parsed[field]):
            raise ValueError(f"exec.run_python config.contract.{field} must be a string array.")
    for field in ("reads_resources", "writes_resources"):
        for index, item in enumerate(parsed[field]):
            if not isinstance(item, dict):
                raise ValueError(f"exec.run_python config.contract.{field}[{index}] must be an object.")
    return parsed


def _state_has_path(state: capability_types.State, path: str) -> bool:
    current: Any = state
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return False
        current = current[part]
    return True


def _validate_resource(
    capability_name: str,
    node_id: str,
    direction: str,
    resource: dict[str, Any],
) -> None:
    root_name = resource.get("root", "workspace")
    resource_type = resource.get("type")
    raw_path = resource.get("path")
    if root_name not in {"workspace", "workflow"}:
        raise ValueError(f"{capability_name} {node_id} CONTRACT {direction} resource root must be workspace or workflow.")
    if resource_type not in {"file", "dir"}:
        raise ValueError(f"{capability_name} {node_id} CONTRACT {direction} {root_name} resource type must be file or dir.")
    path = _resolve_resource_path(root_name, raw_path)
    label = f"{capability_name} {node_id} CONTRACT {direction} {root_name} {resource_type} {raw_path}"
    if resource_type == "file" and not path.is_file():
        raise ValueError(f"{label} missing")
    if resource_type == "dir" and not path.is_dir():
        raise ValueError(f"{label} missing")


def _resolve_resource_path(root_name: str, raw_path: Any) -> pathlib.Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("exec.run_python CONTRACT resource path must be a non-empty string.")
    path = pathlib.Path(raw_path)
    if path.is_absolute():
        raise ValueError(f"exec.run_python CONTRACT resource path must be relative: {raw_path}")
    if ".." in path.parts:
        raise ValueError(f"exec.run_python CONTRACT resource path must not contain '..': {raw_path}")
    root = _resource_root(root_name)
    resolved = (root / path).resolve()
    if not resolved.is_relative_to(root):
        raise ValueError(f"exec.run_python CONTRACT resource path must stay inside {root_name} root: {raw_path}")
    return resolved


def _resource_root(root_name: str) -> pathlib.Path:
    if root_name == "workspace":
        return (runtime_context_module.get_workspace_root() or pathlib.Path.cwd()).resolve()
    workflow_root = runtime_context_module.get_workflow_root()
    if workflow_root is None:
        raise ValueError("exec.run_python CONTRACT workflow root is not available.")
    return workflow_root.resolve()
