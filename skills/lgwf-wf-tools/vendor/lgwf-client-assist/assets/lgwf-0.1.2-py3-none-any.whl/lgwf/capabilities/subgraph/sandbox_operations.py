﻿import fnmatch
import hashlib
import os
import pathlib
import shutil
import stat
from typing import Any

def sandbox_prepare(options: dict[str, Any], *, workspace_root: pathlib.Path) -> dict[str, Any]:
    spec = _sandbox_spec(options, workspace_root)
    sandbox_root = spec["sandbox_root"]
    if sandbox_root.exists():
        _reject_link_or_reparse(sandbox_root, "options.sandbox_path")
        shutil.rmtree(sandbox_root)

    copied: dict[str, int] = {}
    for root_name, root_spec in spec["roots"].items():
        baseline_root = sandbox_root / "baseline" / root_name
        candidate_root = sandbox_root / "candidate" / root_name
        baseline_count = _copy_filtered_tree(
            root_spec["source_root"],
            baseline_root,
            root_spec["include"],
            root_spec["exclude"],
        )
        candidate_count = _copy_filtered_tree(
            root_spec["source_root"],
            candidate_root,
            root_spec["include"],
            root_spec["exclude"],
        )
        copied[root_name] = min(baseline_count, candidate_count)

    result = {
        "sandbox_root": str(sandbox_root),
        "baseline_root": str(sandbox_root / "baseline"),
        "candidate_root": str(sandbox_root / "candidate"),
        "copied": copied,
    }
    _write_json(sandbox_root / "prepare.json", result)
    return result


def sandbox_diff(options: dict[str, Any], *, workspace_root: pathlib.Path) -> dict[str, Any]:
    spec = _sandbox_spec(options, workspace_root)
    sandbox_root = spec["sandbox_root"]
    changes: list[dict[str, Any]] = []
    for root_name, root_spec in spec["roots"].items():
        baseline_root = sandbox_root / "baseline" / root_name
        candidate_root = sandbox_root / "candidate" / root_name
        paths = sorted(
            set(_file_fingerprints(baseline_root, root_spec["include"], root_spec["exclude"]))
            | set(_file_fingerprints(candidate_root, root_spec["include"], root_spec["exclude"]))
        )
        baseline = _file_fingerprints(baseline_root, root_spec["include"], root_spec["exclude"])
        candidate = _file_fingerprints(candidate_root, root_spec["include"], root_spec["exclude"])
        for rel_path in paths:
            before = baseline.get(rel_path)
            after = candidate.get(rel_path)
            if before == after:
                continue
            if before is None:
                status = "added"
            elif after is None:
                status = "deleted"
            else:
                status = "modified"
            changes.append({"root": root_name, "path": rel_path, "status": status})

    result = {"sandbox_root": str(sandbox_root), "changes": changes}
    _write_json(sandbox_root / "diff.json", result)
    return result


def sandbox_promote(options: dict[str, Any], *, workspace_root: pathlib.Path) -> dict[str, Any]:
    spec = _sandbox_spec(options, workspace_root)
    sandbox_root = spec["sandbox_root"]
    promoted: list[dict[str, str]] = []
    deleted: list[dict[str, str]] = []
    conflicts: list[dict[str, str]] = []

    for root_name, root_spec in spec["roots"].items():
        conflicts.extend(_sandbox_promote_conflicts(sandbox_root, root_name, root_spec))
    if conflicts:
        conflict_paths = ", ".join(f"{item['root']}:{item['path']}" for item in conflicts[:5])
        if len(conflicts) > 5:
            conflict_paths = f"{conflict_paths}, ..."
        raise ValueError(f"Sandbox promote conflict: real root changed since baseline: {conflict_paths}")

    for root_name, root_spec in spec["roots"].items():
        baseline_root = sandbox_root / "baseline" / root_name
        candidate_root = sandbox_root / "candidate" / root_name
        destination_root = root_spec["source_root"]
        baseline = _file_fingerprints(
            baseline_root,
            root_spec["promote_include"],
            root_spec["exclude"],
        )
        candidate = _file_fingerprints(
            candidate_root,
            root_spec["promote_include"],
            root_spec["exclude"],
        )
        for source_path in _iter_filtered_files(
            candidate_root,
            root_spec["promote_include"],
            root_spec["exclude"],
        ):
            rel_path = source_path.relative_to(candidate_root).as_posix()
            destination = destination_root / rel_path
            _reject_existing_link_components(destination, "promote destination")
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, destination)
            promoted.append(
                {
                    "root": root_name,
                    "path": rel_path,
                    "destination": str(destination),
                }
            )
        for rel_path in sorted(set(baseline) - set(candidate)):
            destination = destination_root / rel_path
            _reject_existing_link_components(destination, "promote delete destination")
            if destination.exists():
                destination.unlink()
                _remove_empty_parents(destination.parent, destination_root)
                deleted.append(
                    {
                        "root": root_name,
                        "path": rel_path,
                        "destination": str(destination),
                    }
                )

    result = {
        "sandbox_root": str(sandbox_root),
        "promoted": len(promoted),
        "deleted": len(deleted),
        "files": promoted,
        "deleted_files": deleted,
    }
    _write_json(sandbox_root / "promote.json", result)
    return result


def sandbox_archive(options: dict[str, Any], *, workspace_root: pathlib.Path) -> dict[str, Any]:
    spec = _sandbox_spec(options, workspace_root)
    sandbox_root = spec["sandbox_root"]
    validation = options.get("validation", {})
    decision = options.get("decision", {})
    if not isinstance(validation, dict):
        raise ValueError("options.validation must be an object when provided.")
    if not isinstance(decision, dict):
        raise ValueError("options.decision must be an object when provided.")
    _write_json(sandbox_root / "validation.json", validation)
    _write_json(sandbox_root / "decision.json", decision)
    return {
        "sandbox_root": str(sandbox_root),
        "validation_path": str(sandbox_root / "validation.json"),
        "decision_path": str(sandbox_root / "decision.json"),
    }


def resolve_workspace_path(root: pathlib.Path, raw_path: object, label: str) -> pathlib.Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError(f"{label} must be a non-empty string.")
    path = pathlib.Path(raw_path)
    if path.is_absolute():
        raise ValueError(f"{label} must be relative.")
    if ".." in path.parts:
        raise ValueError(f"{label} must not contain '..'.")
    resolved_root = root.resolve()
    candidate = pathlib.Path(os.path.abspath(resolved_root / path))
    _reject_existing_link_components(candidate, label)
    resolved = candidate.resolve()
    if not _is_relative_to(resolved, resolved_root):
        raise ValueError(f"{label} must stay inside workspace root.")
    return resolved


def _sandbox_spec(options: dict[str, Any], workspace_root: pathlib.Path) -> dict[str, Any]:
    if not isinstance(options, dict):
        raise ValueError("options must be an object.")
    sandbox_root = resolve_workspace_path(workspace_root, options.get("sandbox_path"), "options.sandbox_path")
    work_dir = _sandbox_root_spec(options.get("work_dir"), "options.work_dir")
    roots: dict[str, dict[str, Any]] = {
        "work_dir": {
            **work_dir,
            "source_root": _sandbox_source_root(options.get("_source_root"), workspace_root),
        }
    }

    target_dir = options.get("target_dir")
    if target_dir is not None:
        if not isinstance(target_dir, dict):
            raise ValueError("options.target_dir must be an object when provided.")
        target_path = _sandbox_source_root(
            target_dir.get("_source_root"),
            workspace_root,
            fallback_path=target_dir.get("path"),
            fallback_label="options.target_dir.path",
        )
        roots["target_dir"] = {
            **_sandbox_root_spec(target_dir, "options.target_dir"),
            "source_root": target_path,
        }

    for root_name, root_spec in roots.items():
        source_root = root_spec["source_root"]
        if not source_root.is_dir():
            raise ValueError(f"{root_name} source root does not exist or is not a directory: {source_root}")
        _reject_link_or_reparse(source_root, f"{root_name} source root")

    return {"sandbox_root": sandbox_root, "roots": roots}


def _sandbox_source_root(
    value: object,
    workspace_root: pathlib.Path,
    *,
    fallback_path: object | None = None,
    fallback_label: str | None = None,
) -> pathlib.Path:
    if isinstance(value, pathlib.Path):
        return value.resolve()
    if value is not None:
        raise ValueError("sandbox internal source root must be a pathlib.Path.")
    if fallback_path is not None and fallback_label is not None:
        return resolve_workspace_path(workspace_root, fallback_path, fallback_label)
    return workspace_root.resolve()


def _sandbox_root_spec(raw_spec: object, label: str) -> dict[str, list[str]]:
    if not isinstance(raw_spec, dict):
        raise ValueError(f"{label} must be an object.")
    include = _pattern_list(raw_spec.get("include"), f"{label}.include", required=True)
    exclude = _pattern_list(raw_spec.get("exclude", []), f"{label}.exclude", required=False)
    promote_include = _pattern_list(
        raw_spec.get("promote_include", include),
        f"{label}.promote_include",
        required=True,
    )
    return {
        "include": include,
        "exclude": _default_excludes() + exclude,
        "promote_include": promote_include,
    }


def _pattern_list(value: object, label: str, *, required: bool) -> list[str]:
    if (value is None or value == []) and not required:
        return []
    if not isinstance(value, list) or not value or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(f"{label} must be a non-empty list of strings.")
    for pattern in value:
        path = pathlib.PurePosixPath(pattern.replace("\\", "/"))
        if path.is_absolute():
            raise ValueError(f"{label} patterns must be relative.")
        if ".." in path.parts:
            raise ValueError(f"{label} patterns must not contain '..'.")
    return [item.replace("\\", "/") for item in value]


def _default_excludes() -> list[str]:
    return [".lgwf/**", "__pycache__/**", "*.pyc", "*.log"]


def _copy_filtered_tree(
    source_root: pathlib.Path,
    destination_root: pathlib.Path,
    include: list[str],
    exclude: list[str],
) -> int:
    count = 0
    destination_root.mkdir(parents=True, exist_ok=True)
    for source_path in _iter_filtered_files(source_root, include, exclude):
        rel_path = source_path.relative_to(source_root)
        destination = destination_root / rel_path
        _reject_existing_link_components(destination, "sandbox destination")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, destination)
        count += 1
    return count


def _iter_filtered_files(
    root: pathlib.Path,
    include: list[str],
    exclude: list[str],
) -> list[pathlib.Path]:
    if not root.exists():
        return []
    files: list[pathlib.Path] = []

    def visit(directory: pathlib.Path) -> None:
        with os.scandir(directory) as iterator:
            for entry in iterator:
                path = pathlib.Path(entry.path)
                rel_path = path.relative_to(root).as_posix()
                if _matches_any(rel_path, exclude):
                    continue
                _reject_link_or_reparse(path, "sandbox source entry")
                if entry.is_dir(follow_symlinks=False):
                    visit(path)
                elif entry.is_file(follow_symlinks=False) and _matches_any(rel_path, include):
                    files.append(path)

    visit(root)
    return sorted(files)


def _file_fingerprints(root: pathlib.Path, include: list[str], exclude: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for path in _iter_filtered_files(root, include, exclude):
        rel_path = path.relative_to(root).as_posix()
        result[rel_path] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def _sandbox_promote_conflicts(
    sandbox_root: pathlib.Path,
    root_name: str,
    root_spec: dict[str, Any],
) -> list[dict[str, str]]:
    baseline_root = sandbox_root / "baseline" / root_name
    candidate_root = sandbox_root / "candidate" / root_name
    destination_root = root_spec["source_root"]
    baseline = _file_fingerprints(
        baseline_root,
        root_spec["promote_include"],
        root_spec["exclude"],
    )
    candidate = _file_fingerprints(
        candidate_root,
        root_spec["promote_include"],
        root_spec["exclude"],
    )
    destination = _file_fingerprints(
        destination_root,
        root_spec["promote_include"],
        root_spec["exclude"],
    )
    conflicts = []
    for rel_path in sorted(set(baseline) | set(candidate)):
        if destination.get(rel_path) != baseline.get(rel_path):
            conflicts.append(
                {
                    "root": root_name,
                    "path": rel_path,
                    "status": "changed_since_baseline",
                }
            )
    return conflicts


def _remove_empty_parents(path: pathlib.Path, stop_root: pathlib.Path) -> None:
    stop = stop_root.resolve()
    current = path
    while current.resolve() != stop and _is_relative_to(current.resolve(), stop):
        try:
            current.rmdir()
        except OSError:
            return
        current = current.parent


def _matches_any(path: str, patterns: list[str]) -> bool:
    parts = path.split("/")
    if ".lgwf" in parts and any(pattern == ".lgwf/**" for pattern in patterns):
        return True
    if "__pycache__" in parts and any(pattern == "__pycache__/**" for pattern in patterns):
        return True
    return any(pattern == "**" or fnmatch.fnmatch(path, pattern) for pattern in patterns)


def _write_json(path: pathlib.Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json_dumps(data), encoding="utf-8")


def json_dumps(data: dict[str, Any]) -> str:
    import json

    return json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def is_link_or_reparse_point(path: pathlib.Path) -> bool:
    if path.is_symlink():
        return True
    file_attributes = getattr(os.lstat(path), "st_file_attributes", 0)
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return bool(file_attributes & reparse_flag)


def _reject_link_or_reparse(path: pathlib.Path, label: str) -> None:
    if is_link_or_reparse_point(path):
        raise ValueError(f"{label} is a symbolic link or reparse point: {path}")


def _reject_existing_link_components(path: pathlib.Path, label: str) -> None:
    current = path
    existing: list[pathlib.Path] = []
    while True:
        if current.exists() or current.is_symlink():
            existing.append(current)
        if current.parent == current:
            break
        current = current.parent
    for candidate in reversed(existing):
        _reject_link_or_reparse(candidate, label)


def _is_relative_to(path: pathlib.Path, root: pathlib.Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False
