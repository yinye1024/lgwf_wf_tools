﻿from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.types as capability_types
import lgwf.progress as progress_module
import lgwf.runtime_context as runtime_context_module
import lgwf.file_ops as file_ops_module


class FlowHandoffFilesCapability:
    name = "flow.handoff_files"

    def create_node(self, node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        source_path = config.get("source_path")
        result_path = config.get("result_path")
        items = config.get("items")
        if not isinstance(source_path, str) or not source_path:
            raise ValueError("flow.handoff_files config.source_path must be a non-empty string.")
        if not isinstance(result_path, str) or not result_path:
            raise ValueError("flow.handoff_files config.result_path must be a non-empty string.")
        validated_items = _validate_items(items)

        def node(state: capability_types.State) -> capability_types.State:
            workspace_root = runtime_context_module.get_workspace_root()
            if workspace_root is None:
                raise RuntimeError("flow.handoff_files requires a runtime workspace root.")
            source_result = flow_conditions_module.read_path(state, source_path)
            if not isinstance(source_result, dict):
                raise ValueError("flow.handoff_files source_path must resolve to a JSON object.")
            child_work_dir = source_result.get("work_dir")
            if not isinstance(child_work_dir, str) or not child_work_dir:
                raise ValueError("flow.handoff_files source object must include a non-empty work_dir.")
            source_root = Path(child_work_dir).resolve()
            if not source_root.is_dir():
                raise ValueError(f"flow.handoff_files source work_dir does not exist: {source_root}")

            handoff_relative_root = Path(".lgwf") / "handoff" / node_id
            handoff_root = file_ops_module.resolve_under_root(workspace_root, handoff_relative_root)
            output: dict[str, Any] = {"handoff_files": {}}
            copied: list[dict[str, str]] = []
            for item in validated_items:
                source = _resolve_source(source_root, item["source"])
                target_relative = handoff_relative_root / item["target"]
                target = file_ops_module.resolve_under_root(workspace_root, target_relative)
                if item["kind"] == "file":
                    if not source.is_file():
                        raise ValueError(f"flow.handoff_files COPY_FILE source is not a file: {source}")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)
                else:
                    if not source.is_dir():
                        raise ValueError(f"flow.handoff_files COPY_DIR source is not a directory: {source}")
                    if target.exists():
                        if not target.is_dir():
                            raise ValueError(f"flow.handoff_files COPY_DIR target exists and is not a directory: {target}")
                        shutil.rmtree(target)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(source, target, ignore=_ignore_runtime_state)
                relative_output = target_relative.as_posix()
                output_key = item.get("field") or _default_field(item)
                output[output_key] = str(target)
                output["handoff_files"][output_key] = str(target)
                copied.append(
                    {
                        "kind": item["kind"],
                        "source": str(source),
                        "target": relative_output,
                    }
                )
            progress_module.emit(
                f"[workflow] handoff files copied id={node_id} count={len(copied)} target={handoff_root}"
            )
            return flow_conditions_module.write_path(dict(state), result_path, output)

        return node


CAPABILITY = FlowHandoffFilesCapability()


def _validate_items(items: Any) -> list[dict[str, str]]:
    if not isinstance(items, list) or not items:
        raise ValueError("flow.handoff_files config.items must be a non-empty list.")
    validated: list[dict[str, str]] = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("flow.handoff_files config.items entries must be objects.")
        kind = item.get("kind")
        source = item.get("source")
        target = item.get("target")
        field = item.get("field")
        if kind not in {"file", "dir"}:
            raise ValueError("flow.handoff_files item.kind must be file or dir.")
        if not isinstance(source, str) or not source:
            raise ValueError("flow.handoff_files item.source must be a non-empty string.")
        if not isinstance(target, str) or not target:
            raise ValueError("flow.handoff_files item.target must be a non-empty string.")
        if field is not None and (not isinstance(field, str) or not field):
            raise ValueError("flow.handoff_files item.field must be a non-empty string when provided.")
        _validate_safe_relative(source, "source")
        _validate_safe_relative(target, "target")
        if Path(source).parts and Path(source).parts[0] == ".lgwf":
            raise ValueError("flow.handoff_files must not copy .lgwf runtime state.")
        if ".lgwf" in Path(source).parts:
            raise ValueError("flow.handoff_files must not copy .lgwf runtime state.")
        normalized = {"kind": kind, "source": source, "target": target}
        if field is not None:
            normalized["field"] = field
        validated.append(normalized)
    return validated


def _resolve_source(root: Path, relative_path: str) -> Path:
    resolved = file_ops_module.resolve_under_root(root, relative_path, allow_missing=False)
    if ".lgwf" in resolved.relative_to(root).parts:
        raise ValueError("flow.handoff_files must not copy .lgwf runtime state.")
    return resolved


def _validate_safe_relative(raw_path: str, label: str) -> None:
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"flow.handoff_files item.{label} must be relative and must not contain '..'.")


def _default_field(item: dict[str, str]) -> str:
    target = Path(item["target"])
    name = target.name
    if item["kind"] == "file":
        stem = Path(name).stem or name
        return f"{stem}_path"
    return f"{name}_dir"


def _ignore_runtime_state(_directory: str, names: list[str]) -> set[str]:
    return {name for name in names if name in {".lgwf", "__pycache__"} or name.endswith(".pyc")}
