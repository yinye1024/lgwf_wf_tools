from typing import Any

import lgwf.capabilities.types as capability_types


class FlowNoopCapability:
    name = "flow.noop"

    def create_node(self, _node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        if config:
            raise ValueError("flow.noop does not accept config.")

        def node(state: capability_types.State) -> capability_types.State:
            return dict(state)

        return node


CAPABILITY = FlowNoopCapability()
