﻿from pathlib import Path
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.route_keys as route_key_module
import lgwf.capabilities.types as capability_types
import lgwf.human_approval as human_approval_module
import lgwf.human_gate_policy as human_gate_policy_module
import lgwf.progress as progress_module
import lgwf.runtime_context as runtime_context_module
import lgwf.file_ops as file_ops_module


DEFAULT_OPTIONS = ["approve", "revise", "reject"]
REVIEW_DISPLAY_TEMPLATE = {
    "kind": "review_json_v1",
    "options": DEFAULT_OPTIONS,
    "context_field": "review_context_json",
    "revise_value": "complete_updated_context_json_object",
}


class FlowHumanReviewCapability:
    name = "flow.human_review"

    def create_node(self, _node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        prompt = config.get("prompt")
        prompt_ref = config.get("prompt_ref")
        context_path = config.get("context_path")
        result_path = config.get("result_path", "human_review")
        persist_value_path = config.get("persist_value_path")
        options = config.get("options", DEFAULT_OPTIONS)
        option_labels = config.get("option_labels")
        timeout_seconds = config.get("timeout_seconds")
        poll_interval_seconds = config.get("poll_interval_seconds", 1)

        if (prompt is None) == (prompt_ref is None):
            raise ValueError("flow.human_review config requires exactly one of prompt or prompt_ref.")
        if prompt is not None and (not isinstance(prompt, str) or not prompt.strip()):
            raise ValueError("flow.human_review config.prompt must be a non-empty string.")
        if not isinstance(context_path, str) or not context_path:
            raise ValueError("flow.human_review config.context_path must be a non-empty string.")
        if not isinstance(result_path, str) or not result_path:
            raise ValueError("flow.human_review config.result_path must be a non-empty string.")
        if persist_value_path is not None and (
            not isinstance(persist_value_path, str) or not persist_value_path
        ):
            raise ValueError("flow.human_review config.persist_value_path must be a non-empty string when provided.")
        options = _validate_options(options)
        option_labels = _validate_option_labels(option_labels, options)
        if timeout_seconds is not None and (
            not isinstance(timeout_seconds, int | float) or timeout_seconds <= 0
        ):
            raise ValueError("flow.human_review config.timeout_seconds must be a positive number or null.")
        if not isinstance(poll_interval_seconds, int | float) or poll_interval_seconds <= 0:
            raise ValueError("flow.human_review config.poll_interval_seconds must be a positive number.")

        def node(state: capability_types.State) -> capability_types.State:
            workspace_root = runtime_context_module.get_workspace_root()
            if workspace_root is None:
                raise RuntimeError("flow.human_review requires a runtime workspace root.")
            resolved_prompt = prompt if prompt is not None else _read_workflow_prompt(prompt_ref)
            context = flow_conditions_module.read_path(state, context_path)
            if not isinstance(context, dict):
                raise ValueError("flow.human_review context must be a JSON object.")
            request = human_approval_module.create_request(
                workspace_root=workspace_root,
                prompt=resolved_prompt,
                context=context,
                metadata={
                    "kind": "human_review",
                    "options": options,
                    "review_context_json": context,
                    "display_template": _review_display_template(),
                    "revise_requires_full_json": True,
                    **({"option_labels": option_labels} if option_labels else {}),
                },
            )
            progress_module.emit(
                f"[workflow] human review pending request_id={request['request_id']}"
            )
            if human_gate_policy_module.is_auto_approve_enabled():
                if "approve" not in options:
                    raise RuntimeError("flow.human_review auto approve requires options to include approve.")
                response = human_gate_policy_module.write_auto_review_response(
                    workspace_root=workspace_root,
                    request_id=request["request_id"],
                    route="approve",
                )
            else:
                response = human_approval_module.wait_for_response(
                    workspace_root=workspace_root,
                    request_id=request["request_id"],
                    timeout_seconds=None if timeout_seconds is None else float(timeout_seconds),
                    poll_interval_seconds=float(poll_interval_seconds),
                )
            route = _route_for_response(response, options)
            result = _review_result(request["request_id"], route, response)
            next_state = dict(state)
            if route == "revise" and _has_updated_context(response):
                next_state = flow_conditions_module.write_path(
                    next_state,
                    context_path,
                    response["value"]["updated_context"],
                )
            if persist_value_path is not None:
                target = file_ops_module.resolve_under_root(workspace_root, persist_value_path)
                file_ops_module.write_json_atomic(target, _persisted_review_value(route, response))
            next_state = flow_conditions_module.write_path(next_state, result_path, result)
            next_state[route_key_module.route_key_for(_node_id)] = route
            return next_state

        return node


CAPABILITY = FlowHumanReviewCapability()


def _validate_options(options: Any) -> list[str]:
    if not isinstance(options, list) or not options:
        raise ValueError("flow.human_review config.options must be a non-empty string array.")
    if not all(isinstance(option, str) and option for option in options):
        raise ValueError("flow.human_review config.options must contain non-empty strings only.")
    if options != DEFAULT_OPTIONS:
        raise ValueError("flow.human_review config.options are fixed to approve/revise/reject.")
    return list(options)


def _validate_option_labels(option_labels: Any, options: list[str]) -> dict[str, str]:
    if option_labels is None:
        return {}
    if not isinstance(option_labels, dict):
        raise ValueError("flow.human_review config.option_labels must be an object when provided.")
    allowed = set(options)
    result: dict[str, str] = {}
    for key, value in option_labels.items():
        if key not in allowed:
            raise ValueError("flow.human_review config.option_labels keys must be declared in options.")
        if not isinstance(value, str) or not value.strip():
            raise ValueError("flow.human_review config.option_labels values must be non-empty strings.")
        result[key] = value
    return result


def _review_display_template() -> dict[str, Any]:
    return {
        **REVIEW_DISPLAY_TEMPLATE,
        "options": list(DEFAULT_OPTIONS),
    }


def _review_result(request_id: str, route: str, response: dict[str, Any]) -> dict[str, Any]:
    result = {
        "request_id": request_id,
        "route": route,
        "decision": response["decision"],
        "comment": response.get("comment", ""),
    }
    if "value" in response:
        result["value"] = response["value"]
    return result


def _persisted_review_value(route: str, response: dict[str, Any]) -> dict[str, Any]:
    persisted = {
        "decision": route,
        "approval": route,
        "comment": response.get("comment", ""),
    }
    value = response.get("value")
    if isinstance(value, dict):
        persisted.update(value)
    else:
        persisted["value"] = value
    persisted["decision"] = route
    persisted["approval"] = route
    return persisted


def _has_updated_context(response: dict[str, Any]) -> bool:
    value = response.get("value")
    return isinstance(value, dict) and "updated_context" in value


def _route_for_response(response: dict[str, Any], options: list[str]) -> str:
    value = response.get("value")
    route: str | None = None
    if isinstance(value, dict):
        for key in ("route", "route_key", "decision", "approval"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate:
                route = candidate
                break
    if route is None:
        route = str(response["decision"])
    if route not in options:
        allowed = ", ".join(options)
        raise ValueError(f"flow.human_review response route must be one of: {allowed}.")
    return route


def _read_workflow_prompt(prompt_ref: Any) -> str:
    if not isinstance(prompt_ref, dict):
        raise ValueError("flow.human_review config.prompt_ref must be an object.")
    if prompt_ref.get("root") != "workflow":
        raise ValueError("flow.human_review config.prompt_ref.root must be workflow.")
    raw_path = prompt_ref.get("path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("flow.human_review config.prompt_ref.path must be a non-empty string.")
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("flow.human_review config.prompt_ref.path must be relative and must not contain '..'.")
    workflow_root = runtime_context_module.get_workflow_root()
    if workflow_root is None:
        raise RuntimeError("flow.human_review prompt_ref requires a runtime workflow root.")
    resolved = (workflow_root / path).resolve()
    if not resolved.is_relative_to(workflow_root):
        raise ValueError("flow.human_review config.prompt_ref.path must stay inside the workflow root.")
    if not resolved.is_file():
        raise ValueError(f"flow.human_review prompt_ref does not exist or is not a file: {resolved}")
    return resolved.read_text(encoding="utf-8")
