from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

import lgwf.capabilities.flow.flow_conditions as flow_conditions_module
import lgwf.capabilities.subgraph.node as subgraph_node_module
import lgwf.capabilities.types as capability_types
import lgwf.progress as progress_module
import lgwf.resume as resume_module


class ForeachItemFailed(RuntimeError):
    pass


class SubgraphForeachCapability:
    name = "subgraph.foreach"

    def create_node(self, node_id: str, config: dict[str, Any]) -> capability_types.NodeCallable:
        foreach_config = self._validate_config(node_id, config)
        body_node = None
        if foreach_config["body"]["capability"] != "flow.run_workflow":
            body_node = self._compile_body(node_id, foreach_config["body"])

        def node(state: capability_types.State) -> capability_types.State:
            return self._run_foreach(node_id, foreach_config, body_node, state)

        return node

    def _validate_config(self, node_id: str, config: dict[str, Any]) -> dict[str, Any]:
        required_paths = {
            "items_path": config.get("items_path"),
            "current_path": config.get("current_path"),
            "index_path": config.get("index_path"),
            "output_path": config.get("output_path"),
            "results_path": config.get("results_path"),
            "status_path": config.get("status_path", f"foreach.{node_id}.status"),
            "report_path": config.get("report_path", f"foreach.{node_id}.report"),
        }
        for label, value in required_paths.items():
            if not isinstance(value, str) or not value:
                raise ValueError(f"Subgraph '{node_id}' {label} must be a non-empty string.")
        fail_strategy = config.get("fail_strategy", "fail_fast")
        if fail_strategy not in {"fail_fast", "collect"}:
            raise ValueError(f"Subgraph '{node_id}' fail_strategy must be fail_fast or collect.")

        body = config.get("body")
        if not isinstance(body, dict):
            raise ValueError(f"Subgraph '{node_id}' requires body node.")
        capability = body.get("capability")
        if not isinstance(capability, str) or not capability:
            raise ValueError(f"Subgraph '{node_id}' body must include a non-empty capability.")
        subgraph_node_module.ensure_capability(node_id, "body", capability)
        body_config = body.get("config", {})
        if body_config is not None and not isinstance(body_config, dict):
            raise ValueError(f"Subgraph '{node_id}' body config must be an object when provided.")

        return {
            **required_paths,
            "fail_strategy": fail_strategy,
            "body": dict(body),
        }

    def _compile_body(self, node_id: str, body: dict[str, Any]) -> capability_types.NodeCallable:
        import lgwf.capabilities.registry as registry_module

        body_id = body.get("id")
        if not isinstance(body_id, str) or not body_id:
            body_id = f"{node_id}__body"
        capability = body["capability"]
        return progress_module.wrap_node(
            body_id,
            capability,
            registry_module.create_node(capability, body_id, body.get("config", {})),
        )

    def _run_foreach(
        self,
        node_id: str,
        config: dict[str, Any],
        body_node: capability_types.NodeCallable | None,
        state: capability_types.State,
    ) -> capability_types.State:
        items = self._read_items(state, config["items_path"])
        items_hash = self._items_hash(items)
        current_state = dict(state)
        start_index, results, summaries = self._resume_progress(node_id, config, current_state, len(items), items_hash)

        current_state = flow_conditions_module.write_path(
            current_state,
            config["status_path"],
            self._status(node_id, "running", None, start_index, len(items)),
        )
        if results:
            current_state = flow_conditions_module.write_path(current_state, config["results_path"], list(results))
        current_state = flow_conditions_module.write_path(
            current_state,
            config["report_path"],
            self._report(node_id, "running", start_index, len(items), items_hash, summaries),
        )

        for index in range(start_index, len(items)):
            item = items[index]
            current_state = flow_conditions_module.write_path(current_state, config["current_path"], item)
            current_state = flow_conditions_module.write_path(current_state, config["index_path"], index)
            current_state = flow_conditions_module.write_path(
                current_state,
                config["status_path"],
                self._status(node_id, "running", index, index, len(items)),
            )
            checkpoint_writer = progress_module.get_checkpoint_writer()
            if checkpoint_writer is not None:
                checkpoint_writer.start_node(node_id, self.name, current_state)
            try:
                item_state = self._run_body(node_id, config, body_node, current_state, index)
                if not self._path_exists(item_state, config["output_path"]):
                    output = self._read_run_workflow_output(item_state, config)
                    if output is None:
                        raise ValueError(
                            f"Subgraph '{node_id}' item {index} output_path is missing: {config['output_path']}"
                        )
                else:
                    output = flow_conditions_module.read_path(item_state, config["output_path"])
                item_state = self._cleanup_private_paths(item_state, config)
                result_entry = {
                    "status": "completed",
                    "index": index,
                    "item": item,
                    "output": output,
                }
                current_state = item_state
            except Exception as exc:
                if config["fail_strategy"] != "collect":
                    error = self._foreach_item_failed(node_id, index, item, exc)
                    checkpoint_writer = progress_module.get_checkpoint_writer()
                    if checkpoint_writer is not None:
                        checkpoint_writer.fail_node(node_id, self.name, current_state, error)
                    raise error from exc
                result_entry = {
                    "status": "failed",
                    "index": index,
                    "item": item,
                    "error_type": type(exc).__name__,
                    "message": str(exc),
                    "inner_failure": getattr(exc, "__lgwf_failure__", None),
                }
            results.append(result_entry)
            summaries.append({key: result_entry[key] for key in ("index", "status")})
            current_state = flow_conditions_module.write_path(current_state, config["results_path"], list(results))
            current_state = flow_conditions_module.write_path(
                current_state,
                config["report_path"],
                self._report(node_id, "running", index + 1, len(items), items_hash, summaries),
            )

        current_state = flow_conditions_module.write_path(
            current_state,
            config["status_path"],
            self._status(node_id, "finished", None, len(items), len(items)),
        )
        current_state = flow_conditions_module.write_path(
            current_state,
            config["report_path"],
            self._report(node_id, "finished", len(items), len(items), items_hash, summaries),
        )
        return current_state

    def _run_body(
        self,
        node_id: str,
        config: dict[str, Any],
        body_node: capability_types.NodeCallable | None,
        current_state: capability_types.State,
        index: int,
    ) -> capability_types.State:
        body = config["body"]
        if body["capability"] != "flow.run_workflow":
            if body_node is None:
                raise RuntimeError(f"Subgraph '{node_id}' body node is not compiled.")
            with progress_module.use_checkpoint_writer(None):
                return body_node(current_state)

        materialized_body = self._materialize_run_workflow_body(node_id, body, index)
        body_config = materialized_body.get("config", {})
        input_path = body_config.get("input_path")
        if not isinstance(input_path, str) or not input_path:
            raise ValueError(f"Subgraph '{node_id}' RUN_WORKFLOW body requires config.input_path.")
        child_input = copy.deepcopy(current_state)
        run_state = flow_conditions_module.write_path(dict(current_state), input_path, child_input)
        run_body_node = self._compile_body(node_id, materialized_body)
        resume_target = resume_module.get_resume_target()
        body_resume_target = materialized_body["id"] if resume_target == node_id else resume_target
        with resume_module.use_resume_target(body_resume_target):
            with progress_module.use_checkpoint_writer(None):
                return run_body_node(run_state)

    def _materialize_run_workflow_body(self, node_id: str, body: dict[str, Any], index: int) -> dict[str, Any]:
        materialized = copy.deepcopy(body)
        config = materialized.get("config")
        if not isinstance(config, dict):
            config = {}
            materialized["config"] = config
        work_dir = config.get("work_dir")
        if isinstance(work_dir, str):
            config["work_dir"] = work_dir.replace("{index}", str(index))
        body_id = materialized.get("id")
        if not isinstance(body_id, str) or not body_id:
            body_id = f"{node_id}__body"
        materialized["id"] = f"{body_id}__item_{index}"
        return materialized

    def _read_run_workflow_output(self, state: capability_types.State, config: dict[str, Any]) -> Any:
        body_config = config["body"].get("config", {})
        if not isinstance(body_config, dict):
            return None
        result_path = body_config.get("result_path")
        if not isinstance(result_path, str) or not result_path:
            return None
        child_result = flow_conditions_module.read_path(state, result_path)
        final_state = child_result.get("final_state") if isinstance(child_result, dict) else None
        if not isinstance(final_state, dict):
            return None
        if not self._path_exists(final_state, config["output_path"]):
            return None
        return flow_conditions_module.read_path(final_state, config["output_path"])

    def _cleanup_private_paths(self, state: capability_types.State, config: dict[str, Any]) -> capability_types.State:
        if config["body"]["capability"] != "flow.run_workflow":
            return state
        body_config = config["body"].get("config", {})
        if not isinstance(body_config, dict):
            return state
        next_state = state
        for path in (body_config.get("input_path"), body_config.get("result_path")):
            if isinstance(path, str) and path:
                next_state = flow_conditions_module.write_path(next_state, path, None)
        return next_state

    def _resume_progress(
        self,
        node_id: str,
        config: dict[str, Any],
        state: capability_types.State,
        item_count: int,
        items_hash: str,
    ) -> tuple[int, list[Any], list[dict[str, Any]]]:
        report = flow_conditions_module.read_path(state, config["report_path"])
        if not isinstance(report, dict):
            return 0, [], []
        completed_count = report.get("completed_count")
        if not isinstance(completed_count, int) or completed_count <= 0:
            return 0, [], []
        if completed_count > item_count:
            raise ValueError(f"FOREACH {node_id} checkpoint completed_count exceeds item count.")
        checkpoint_hash = report.get("items_hash")
        if checkpoint_hash != items_hash:
            raise ValueError(f"FOREACH {node_id} items changed since checkpoint.")

        raw_results = flow_conditions_module.read_path(state, config["results_path"])
        if not isinstance(raw_results, list) or len(raw_results) < completed_count:
            raise ValueError(f"FOREACH {node_id} checkpoint results are incomplete.")
        results = copy.deepcopy(raw_results[:completed_count])

        raw_summaries = report.get("iteration_summaries")
        if isinstance(raw_summaries, list) and len(raw_summaries) >= completed_count:
            summaries = [dict(item) for item in raw_summaries[:completed_count] if isinstance(item, dict)]
        else:
            summaries = []
        while len(summaries) < completed_count:
            entry = results[len(summaries)]
            if isinstance(entry, dict):
                summaries.append(
                    {
                        "index": entry.get("index", len(summaries)),
                        "status": entry.get("status", "completed"),
                    }
                )
            else:
                summaries.append({"index": len(summaries), "status": "completed"})
        return completed_count, results, summaries

    def _read_items(self, state: capability_types.State, path: str) -> list[Any]:
        value = flow_conditions_module.read_path(state, path)
        if not isinstance(value, list):
            raise ValueError(f"subgraph.foreach items_path must resolve to a list: {path}")
        return list(value)

    def _items_hash(self, items: list[Any]) -> str:
        payload = json.dumps(items, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _status(
        self,
        node_id: str,
        status: str,
        current_index: int | None,
        completed_count: int,
        total: int,
    ) -> dict[str, Any]:
        return {
            "foreach_id": node_id,
            "status": status,
            "current_index": current_index,
            "completed_count": completed_count,
            "total": total,
        }

    def _report(
        self,
        node_id: str,
        status: str,
        completed_count: int,
        total: int,
        items_hash: str,
        summaries: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return {
            "foreach_id": node_id,
            "status": status,
            "completed_count": completed_count,
            "total": total,
            "failed_count": sum(1 for item in summaries if item.get("status") == "failed"),
            "items_hash": items_hash,
            "iteration_summaries": [dict(item) for item in summaries],
        }

    def _foreach_item_failed(self, node_id: str, index: int, item: Any, exc: Exception) -> ForeachItemFailed:
        error = ForeachItemFailed(f"FOREACH {node_id} item {index} failed: {exc}")
        setattr(
            error,
            "__lgwf_failure__",
            {
                "node_id": node_id,
                "capability": self.name,
                "error_type": "ForeachItemFailed",
                "message": str(error),
                "failed_by": "FAIL_ALL",
                "item_index": index,
                "item": item,
                "inner_failure": getattr(exc, "__lgwf_failure__", None),
            },
        )
        return error

    def _path_exists(self, state: capability_types.State, path: str) -> bool:
        current: Any = state
        for part in path.split("."):
            if not isinstance(current, dict) or part not in current:
                return False
            current = current[part]
        return True


CAPABILITY = SubgraphForeachCapability()
