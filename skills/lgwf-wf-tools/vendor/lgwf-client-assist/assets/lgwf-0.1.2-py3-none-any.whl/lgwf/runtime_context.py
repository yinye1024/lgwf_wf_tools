from contextlib import contextmanager
import contextvars
from pathlib import Path
from typing import Iterator


_WORKSPACE_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar("lgwf_workspace_root", default=None)
_WORKFLOW_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar("lgwf_workflow_root", default=None)
_WORK_DIR_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar("lgwf_work_dir_root", default=None)
_AGENT_LOOP_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar("lgwf_agent_loop_root", default=None)
_SANDBOX_TARGET_ROOTS: contextvars.ContextVar[tuple[Path, Path] | None] = contextvars.ContextVar(
    "lgwf_sandbox_target_roots",
    default=None,
)
_WORKFLOW_GROUP_SESSION_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar(
    "lgwf_workflow_group_session_root",
    default=None,
)
_CODEX_KEY_SESSION_ROOT: contextvars.ContextVar[Path | None] = contextvars.ContextVar(
    "lgwf_codex_key_session_root",
    default=None,
)
_HUMAN_GATE_POLICY: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "lgwf_human_gate_policy",
    default=None,
)


@contextmanager
def use_workspace_root(workspace_root: Path | None) -> Iterator[None]:
    token = _WORKSPACE_ROOT.set(workspace_root.resolve() if workspace_root is not None else None)
    try:
        yield
    finally:
        _WORKSPACE_ROOT.reset(token)


def get_workspace_root() -> Path | None:
    return _WORKSPACE_ROOT.get()


@contextmanager
def use_work_dir_root(work_dir_root: Path | None) -> Iterator[None]:
    token = _WORK_DIR_ROOT.set(work_dir_root.resolve() if work_dir_root is not None else None)
    try:
        yield
    finally:
        _WORK_DIR_ROOT.reset(token)


def get_work_dir_root() -> Path | None:
    return _WORK_DIR_ROOT.get()


@contextmanager
def use_agent_loop_root(agent_loop_root: Path | None) -> Iterator[None]:
    token = _AGENT_LOOP_ROOT.set(agent_loop_root.resolve() if agent_loop_root is not None else None)
    try:
        yield
    finally:
        _AGENT_LOOP_ROOT.reset(token)


def get_agent_loop_root() -> Path | None:
    return _AGENT_LOOP_ROOT.get()


@contextmanager
def use_sandbox_target_roots(source_root: Path | None, candidate_root: Path | None) -> Iterator[None]:
    roots = None
    if source_root is not None and candidate_root is not None:
        roots = (source_root.resolve(), candidate_root.resolve())
    token = _SANDBOX_TARGET_ROOTS.set(roots)
    try:
        yield
    finally:
        _SANDBOX_TARGET_ROOTS.reset(token)


def get_sandbox_target_roots() -> tuple[Path, Path] | None:
    return _SANDBOX_TARGET_ROOTS.get()


@contextmanager
def use_workflow_group_session_root(workflow_group_session_root: Path | None) -> Iterator[None]:
    token = _WORKFLOW_GROUP_SESSION_ROOT.set(
        workflow_group_session_root.resolve() if workflow_group_session_root is not None else None
    )
    try:
        yield
    finally:
        _WORKFLOW_GROUP_SESSION_ROOT.reset(token)


def get_workflow_group_session_root() -> Path | None:
    return _WORKFLOW_GROUP_SESSION_ROOT.get()


@contextmanager
def use_codex_key_session_root(codex_key_session_root: Path | None) -> Iterator[None]:
    token = _CODEX_KEY_SESSION_ROOT.set(
        codex_key_session_root.resolve() if codex_key_session_root is not None else None
    )
    try:
        yield
    finally:
        _CODEX_KEY_SESSION_ROOT.reset(token)


def get_codex_key_session_root() -> Path | None:
    return _CODEX_KEY_SESSION_ROOT.get()


@contextmanager
def use_workflow_root(workflow_root: Path | None) -> Iterator[None]:
    token = _WORKFLOW_ROOT.set(workflow_root.resolve() if workflow_root is not None else None)
    try:
        yield
    finally:
        _WORKFLOW_ROOT.reset(token)


def get_workflow_root() -> Path | None:
    return _WORKFLOW_ROOT.get()


@contextmanager
def use_human_gate_policy(policy: dict | None) -> Iterator[None]:
    token = _HUMAN_GATE_POLICY.set(dict(policy) if isinstance(policy, dict) else None)
    try:
        yield
    finally:
        _HUMAN_GATE_POLICY.reset(token)


def get_human_gate_policy() -> dict | None:
    return _HUMAN_GATE_POLICY.get()
