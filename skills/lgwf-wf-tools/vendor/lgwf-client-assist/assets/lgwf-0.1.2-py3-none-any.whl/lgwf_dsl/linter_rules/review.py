import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def lint_review_contracts(linter, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
    reviews = {
        statement.id: statement
        for statement in ast.statements
        if isinstance(statement, ast_module.ReviewDecl)
    }
    if not reviews:
        return []

    diagnostics: list[diagnostics_module.Diagnostic] = []
    route_map = _route_map(linter, ast)
    edges = _edge_map(linter, ast)
    control_state = _human_control_state_paths(linter, ast)
    for review_id, review in reviews.items():
        if review.result_path is None:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} omits explicit RESULT state path.",
                    review.location,
                    severity="warning",
                    code="LGWF_REVIEW_RESULT_RECOMMENDED",
                    suggestion=f"Add RESULT state.{review_id}_result or another explicit review result path for traceability.",
                )
            )

        prompt_empty = _review_prompt_empty_diagnostic(linter, review)
        if prompt_empty is not None:
            diagnostics.append(prompt_empty)

        context_path = review.context_path.path
        if _review_context_looks_control_plane(linter, context_path, control_state):
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} CONTEXT state.{context_path} looks like human control-plane data.",
                    review.location,
                    severity="warning",
                    code="LGWF_REVIEW_CONTEXT_CONTROL_PLANE",
                    suggestion="Use the business proposal JSON object as REVIEW CONTEXT, not approval/review result state.",
                )
            )
        elif _review_context_name_suspicious(linter, context_path):
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} CONTEXT state.{context_path} has suspicious control-plane naming.",
                    review.location,
                    severity="warning",
                    code="LGWF_REVIEW_CONTEXT_NAME_SUSPICIOUS",
                    suggestion="Prefer names such as proposal, requirements, design, or plan for REVIEW context JSON.",
                )
            )

        plain_successors = edges.get(review_id, [])
        risky_successors = [node for node in plain_successors if _looks_like_apply_or_finalize_node(linter, node)]
        if risky_successors:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} has plain FLOW/EDGE to apply/finalize node(s): {', '.join(risky_successors)}.",
                    review.location,
                    severity="error",
                    code="LGWF_REVIEW_APPROVE_ONLY_APPLY",
                    suggestion='Route REVIEW explicitly and only send WHEN "approve" to apply/finalize.',
                )
            )

        branches = route_map.get(review_id)
        if branches is None:
            continue
        missing = sorted({"approve", "revise", "reject"} - set(branches))
        if missing:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} missing route branches: {', '.join(missing)}.",
                    review.location,
                    severity="error",
                    code="LGWF_REVIEW_ROUTE_MISSING_FIXED_BRANCH",
                    suggestion=(
                        "Route REVIEW with approve/revise/reject. Usually revise returns to the "
                        "REVIEW node and reject routes to FAIL_ALL."
                    ),
                )
            )
        reject_target = branches.get("reject")
        if reject_target is not None and reject_target != "FAIL_ALL":
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"REVIEW {review_id} reject route targets {reject_target}; reject should usually target FAIL_ALL.",
                    review.location,
                    severity="warning",
                    code="LGWF_REVIEW_REJECT_SHOULD_FAIL_ALL",
                    suggestion='Use WHEN "reject" THEN FAIL_ALL unless the workflow has an explicit cleanup/summarize branch.',
                )
            )
        revise_target = branches.get("revise")
        if revise_target is not None and revise_target != review_id:
            returns_to_review = _can_reach(linter, revise_target, review_id, edges)
            reachable_apply = sorted(
                node
                for node in _reachable_nodes(linter, revise_target, edges)
                if _looks_like_apply_or_finalize_node(linter, node)
            )
            if not returns_to_review or reachable_apply:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"REVIEW {review_id} revise route must return to the same REVIEW before "
                            f"apply/finalize. Target {revise_target} reaches: "
                            f"{', '.join(reachable_apply) or '<none>'}."
                        ),
                        review.location,
                        severity="error",
                        code="LGWF_REVIEW_REVISE_SHOULD_RETURN_TO_REVIEW",
                        suggestion=(
                            'Make WHEN "revise" target the same REVIEW node, or target a revision '
                            "node whose next edge returns to the REVIEW node."
                        ),
                    )
                )
    return diagnostics

def _route_map(linter, ast: ast_module.WorkflowAst) -> dict[str, dict[str, str]]:
    routes: dict[str, dict[str, str]] = {}
    for statement in ast.statements:
        if isinstance(statement, ast_module.RouteDecl):
            routes[statement.from_node] = dict(statement.branches)
    return routes

def _edge_map(linter, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
    edges: dict[str, list[str]] = {}
    for statement in ast.statements:
        if isinstance(statement, ast_module.FlowDecl):
            for left, right in zip(statement.nodes, statement.nodes[1:]):
                edges.setdefault(left, []).append(right)
        elif isinstance(statement, ast_module.EdgeDecl):
            edges.setdefault(statement.from_node, []).append(statement.to_node)
    return edges

def _can_reach(
    linter,
    start: str,
    target: str,
    edges: dict[str, list[str]],
    *,
    max_depth: int = 8,
) -> bool:
    frontier = [(start, 0)]
    visited: set[str] = set()
    while frontier:
        node, depth = frontier.pop(0)
        if node == target:
            return True
        if node in visited or depth >= max_depth:
            continue
        visited.add(node)
        for next_node in edges.get(node, []):
            frontier.append((next_node, depth + 1))
    return False

def _reachable_nodes(
    linter,
    start: str,
    edges: dict[str, list[str]],
    *,
    max_depth: int = 8,
) -> set[str]:
    result: set[str] = set()
    frontier = [(start, 0)]
    while frontier:
        node, depth = frontier.pop(0)
        if node in result or depth > max_depth:
            continue
        result.add(node)
        for next_node in edges.get(node, []):
            frontier.append((next_node, depth + 1))
    return result

def _looks_like_apply_or_finalize_node(linter, node_id: str) -> bool:
    normalized = node_id.lower()
    tokens = ("apply", "finalize", "confirmed", "persist", "save_confirmed")
    return any(token in normalized for token in tokens)

def _review_context_looks_control_plane(linter, path: str, control_state: set[str]) -> bool:
    if path in control_state:
        return True
    lowered = path.lower()
    return any(
        token in lowered
        for token in ("review_result", "approval_result", "human_approval", "human_review")
    )

def _review_context_name_suspicious(linter, path: str) -> bool:
    lowered = path.lower()
    return any(
        token in lowered
        for token in ("result", "decision", "approval", "review_response", "choice")
    )

def _review_prompt_empty_diagnostic(
    linter,
    review: ast_module.ReviewDecl,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, review.prompt_ref_path)
    if resolved is None or not resolved.is_file():
        return None
    try:
        content = resolved.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return None
    if content.strip():
        return None
    return diagnostics_module.Diagnostic(
        f"REVIEW {review.id} prompt file is empty: {review.prompt_ref_path}",
        review.location,
        severity="warning",
        code="LGWF_REVIEW_PROMPT_EMPTY",
        suggestion=(
            "Write a concrete review prompt that tells the main agent how to present "
            "the JSON object and ask for approve/revise/reject."
        ),
    )

def lint_human_control_plane_data_use(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    control_state = _human_control_state_paths(linter, ast)
    control_files = _human_control_persist_paths(linter, ast)
    if not control_state and not control_files:
        return []

    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        if _is_human_decision_statement(linter, statement):
            continue
        reads_control_state = [
            path
            for _, path in linter._statement_state_reads(statement)
            if path in control_state
        ]
        business_writes = [
            path
            for _, path in linter._statement_state_writes(statement)
            if _looks_like_business_artifact_state(linter, path)
        ]
        if reads_control_state and business_writes:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"{getattr(statement, 'id', '<anonymous>')} reads human decision control state "
                        f"{', '.join(sorted(set(reads_control_state)))} and writes business artifact state "
                        f"{', '.join(sorted(set(business_writes)))}."
                    ),
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_HUMAN_CONTROL_PLANE_AS_DATA",
                    suggestion=(
                        "Keep APPROVAL/REVIEW/CHOICE RESULT and decision records as route/control data only. "
                        "Have downstream nodes read a fixed proposal or normalized business artifact instead."
                    ),
                )
            )

        for python in linter._python_decls(statement):
            diagnostics.extend(_lint_python_human_persist_reads(linter, python, defaults, control_files))
    return diagnostics

def lint_review_control_plane_data_use(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    review_state = {
        statement.result_path.path
        for statement in ast.statements
        if isinstance(statement, ast_module.ReviewDecl) and statement.result_path is not None
    }
    review_files = {
        linter._normalize_path(statement.persist_path)
        for statement in ast.statements
        if isinstance(statement, ast_module.ReviewDecl) and statement.persist_path
    }
    if not review_state and not review_files:
        return []

    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        if isinstance(statement, ast_module.ReviewDecl):
            continue
        reads_review_state = [
            path
            for _, path in linter._statement_state_reads(statement)
            if path in review_state
        ]
        business_writes = [
            path
            for _, path in linter._statement_state_writes(statement)
            if _looks_like_business_artifact_state(linter, path)
        ]
        if reads_review_state and business_writes:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"{getattr(statement, 'id', '<anonymous>')} reads REVIEW result state "
                        f"{', '.join(sorted(set(reads_review_state)))} and writes business artifact state "
                        f"{', '.join(sorted(set(business_writes)))}."
                    ),
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_REVIEW_RESULT_AS_BUSINESS_DATA",
                    suggestion=(
                        "Read the REVIEW CONTEXT proposal JSON, not REVIEW RESULT/PERSIST control-plane "
                        "records, when applying confirmed business artifacts."
                    ),
                )
            )
        for python in linter._python_decls(statement):
            for diagnostic in _lint_python_human_persist_reads(linter, python, defaults, review_files):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        diagnostic.message,
                        diagnostic.location,
                        severity="error",
                        code="LGWF_REVIEW_RESULT_AS_BUSINESS_DATA",
                        suggestion=(
                            "Read the fixed proposal artifact, not REVIEW PERSIST decision JSON, "
                            "when applying confirmed business artifacts."
                        ),
                    )
                )
    return diagnostics

def _human_control_state_paths(linter, ast: ast_module.WorkflowAst) -> set[str]:
    paths: set[str] = set()
    for statement in ast.statements:
        if isinstance(statement, ast_module.ApprovalDecl) and statement.result_path is not None:
            paths.add(statement.result_path.path)
        elif isinstance(statement, ast_module.ReviewDecl) and statement.result_path is not None:
            paths.add(statement.result_path.path)
        elif isinstance(statement, ast_module.ChoiceDecl) and statement.result_path is not None:
            paths.add(statement.result_path.path)
    return paths

def _human_control_persist_paths(linter, ast: ast_module.WorkflowAst) -> set[str]:
    paths: set[str] = set()
    for statement in ast.statements:
        if isinstance(statement, (ast_module.ReviewDecl, ast_module.ChoiceDecl)) and statement.persist_path:
            paths.add(linter._normalize_path(statement.persist_path))
    return paths

def _is_human_decision_statement(linter, statement: ast_module.StatementDecl) -> bool:
    return isinstance(statement, (ast_module.ApprovalDecl, ast_module.ReviewDecl, ast_module.ChoiceDecl))

def _looks_like_business_artifact_state(linter, path: str) -> bool:
    normalized = linter._normalize_path(path).lower()
    keywords = (
        "confirmed",
        "proposal",
        "business_flow",
        "requirements",
        "step_design",
        "final",
    )
    return any(keyword in normalized for keyword in keywords)

def _lint_python_human_persist_reads(
    linter,
    python: ast_module.PythonDecl,
    defaults: ast_module.DefaultsDecl,
    control_files: set[str],
) -> list[diagnostics_module.Diagnostic]:
    if not control_files:
        return []
    script_path = linter._resolve_python_script_path(python.script_path, defaults)
    if script_path is None or not script_path.is_file():
        return []
    try:
        content = script_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return []
    normalized = content.replace("\\", "/")
    matched = [
        path
        for path in sorted(control_files)
        if path in normalized or pathlib.PurePosixPath(path).name in normalized
    ]
    if not matched:
        return []
    if "proposal" in normalized or "normaliz" in normalized or "normalize" in normalized:
        return []
    if python.result_path is None or not _looks_like_business_artifact_state(linter, python.result_path.path):
        return []
    return [
        diagnostics_module.Diagnostic(
            f"PY {python.id} reads human decision persist file(s) as business data: {', '.join(matched)}.",
            python.location,
            severity="error",
            code="LGWF_HUMAN_CONTROL_PLANE_AS_DATA",
            suggestion=(
                "Use REVIEW/CHOICE persist files only for route decision audit. "
                "Read a fixed proposal or normalized business artifact before writing confirmed/final state."
            ),
        )
    ]
