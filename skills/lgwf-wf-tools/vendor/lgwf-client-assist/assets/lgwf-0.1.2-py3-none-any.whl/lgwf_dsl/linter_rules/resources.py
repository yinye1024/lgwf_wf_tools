from collections.abc import Iterable
import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module
import lgwf_dsl.linter_rules.data_flow as data_flow_rules_module
import lgwf_dsl.linter_rules.run_workflow as run_workflow_rules_module
import lgwf_dsl.parser as parser_module
import lgwf_dsl.validator as validator_module


def lint_authoring_resources(
    linter,
    ast: ast_module.WorkflowAst,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    if ast.source_name is None and linter.package_root is None:
        return []

    defaults = linter._defaults(ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        diagnostics.extend(_lint_statement_resources(linter, statement, defaults, context_sets))
    return diagnostics

def _lint_statement_resources(
    linter,
    statement: ast_module.StatementDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    if isinstance(statement, ast_module.PythonDecl):
        missing = _missing_task_resource(linter, statement.script_path, "SCRIPT", defaults, statement.location)
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.CodexDecl):
        diagnostics = [_missing_task_resource(linter, statement.prompt_path, "PROMPT", defaults, statement.location)]
        diagnostics.extend(_lint_context_resources(linter, statement.contexts, context_sets))
        return [diagnostic for diagnostic in diagnostics if diagnostic is not None]
    if isinstance(statement, ast_module.ApprovalDecl) and statement.prompt_ref_path is not None:
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT_REF",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ReviewDecl):
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ChoiceDecl):
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT_REF",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ReactDecl):
        diagnostics: list[diagnostics_module.Diagnostic] = []
        if statement.spec_path is not None:
            missing = _missing_task_resource(linter, 
                statement.spec_path,
                "SPEC",
                defaults,
                statement.location,
            )
            if missing is not None:
                diagnostics.append(missing)
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_resources(linter, slot.task, defaults, context_sets))
        return diagnostics
    if isinstance(statement, ast_module.AgentLoopDecl):
        diagnostics = []
        diagnostics.extend(_lint_context_resources(linter, statement.contexts, context_sets))
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_resources(linter, slot.task, defaults, context_sets))
        return diagnostics
    if isinstance(statement, ast_module.WorkflowRefDecl):
        missing = _missing_workflow_ref(linter, statement.workflow_path, statement.location)
        if missing is not None:
            return [missing]
        child_ast = _load_child_workflow(linter, statement)
        if child_ast is None:
            return []
        diagnostics = _lint_step_workflow_contract_writes(linter, statement, child_ast)
        diagnostics.extend(_lint_child_workflow_with_boundary_inputs(linter, statement, child_ast))
        return diagnostics
    if isinstance(statement, ast_module.RunWorkflowDecl):
        diagnostics = []
        invalid_work_dir = run_workflow_rules_module.invalid_run_workflow_work_dir(linter, statement)
        if invalid_work_dir is not None:
            diagnostics.append(invalid_work_dir)
        missing = _missing_external_workflow(linter, statement.workflow_path, statement.location)
        if missing is not None:
            diagnostics.append(missing)
        return diagnostics
    if isinstance(statement, ast_module.ForeachDecl):
        return _lint_foreach_resources(linter, statement)
    if isinstance(statement, ast_module.ParallelDecl):
        diagnostics = []
        for step in statement.steps:
            diagnostics.extend(_lint_statement_resources(linter, step.task, defaults, context_sets))
        return diagnostics
    return []

def _lint_context_resources(
    linter,
    contexts: Iterable[ast_module.ContextRef],
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for context in contexts:
        resources: list[ast_module.ResourceRef] = []
        if context.resource is not None:
            resources.append(context.resource)
        elif context.context_set is not None and context.context_set in context_sets:
            resources.extend(linter._context_set_resources(context.context_set, context_sets))
        for resource in resources:
            if resource.root != "workflow":
                continue
            missing = _missing_workflow_resource(linter, resource.path, f"CONTEXT workflow {resource.type}", resource.location)
            if missing is not None:
                diagnostics.append(missing)
    return diagnostics

def _missing_task_resource(
    linter,
    raw_path: str,
    label: str,
    defaults: ast_module.DefaultsDecl,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    root = defaults.ref_root.get("root", "workflow")
    if root != "workflow":
        return None
    ref_root_path = defaults.ref_root.get("path", ".")
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved_base = linter._resolve_relative(base_dir, ref_root_path)
    if resolved_base is None:
        return linter._resource_diagnostic(ref_root_path, "ref_root", location, "ref_root path must be relative and stay inside the workflow package.")
    resolved = linter._resolve_relative(resolved_base, raw_path)
    if resolved is None or not resolved.is_file():
        return linter._resource_diagnostic(raw_path, label, location, f"Create the {label} file or update its path to an existing workflow package file.")
    return None

def _missing_workflow_resource(
    linter,
    raw_path: str,
    label: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, raw_path)
    if resolved is None:
        return linter._resource_diagnostic(raw_path, label, location, "Use a relative path inside the workflow package.")
    if not resolved.exists():
        return linter._resource_diagnostic(raw_path, label, location, f"Create the referenced {label} resource or update the path.")
    return None

def _missing_workflow_ref(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, raw_path)
    if resolved is None or pathlib.PurePath(raw_path).suffix.lower() != ".lgwf" or not resolved.is_file():
        return linter._resource_diagnostic(raw_path, "STEP WORKFLOW", location, "Point STEP WORKFLOW at an existing relative .lgwf file inside the workflow package.")
    return None

def _missing_external_workflow(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    if _invalid_external_workflow_path(raw_path):
        return linter._resource_diagnostic(
            raw_path,
            "RUN_WORKFLOW WORKFLOW",
            location,
            "Use a relative path to an existing child workflow.lgwf file.",
        )
    if not _external_workflow_exists(linter, raw_path):
        return linter._resource_diagnostic(
            raw_path,
            "RUN_WORKFLOW WORKFLOW",
            location,
            "Create the child workflow.lgwf file or update RUN_WORKFLOW WORKFLOW.",
        )
    return None


def _lint_foreach_resources(
    linter,
    statement: ast_module.ForeachDecl,
) -> list[diagnostics_module.Diagnostic]:
    body = statement.body
    if isinstance(body, ast_module.ForeachWorkflowBodyDecl):
        missing = _missing_foreach_workflow_ref(linter, body.workflow_path, body.location)
        if missing is not None:
            return [missing]
        child_ast = _load_child_workflow_path(linter, body.workflow_path)
        if child_ast is None:
            return []
        diagnostics = _lint_foreach_workflow_contract_writes(linter, statement, body, child_ast)
        boundary_ref = ast_module.WorkflowRefDecl(
            id=statement.id,
            workflow_path=body.workflow_path,
            contract=body.contract,
            location=body.location,
        )
        diagnostics.extend(_lint_child_workflow_with_boundary_inputs(linter, boundary_ref, child_ast))
        return diagnostics
    if isinstance(body, ast_module.ForeachRunWorkflowBodyDecl):
        missing = _missing_foreach_external_workflow(linter, body.workflow_path, body.location)
        return [missing] if missing is not None else []
    return []


def _missing_foreach_workflow_ref(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, raw_path)
    if resolved is None or pathlib.PurePath(raw_path).suffix.lower() != ".lgwf" or not resolved.is_file():
        return linter._resource_diagnostic(
            raw_path,
            "FOREACH WORKFLOW",
            location,
            "Point FOREACH WORKFLOW at an existing relative .lgwf file inside the workflow package.",
        )
    return None


def _missing_foreach_external_workflow(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    if _invalid_external_workflow_path(raw_path):
        return linter._resource_diagnostic(
            raw_path,
            "FOREACH RUN_WORKFLOW",
            location,
            "Use a relative path to an existing child workflow.lgwf file.",
        )
    if not _external_workflow_exists(linter, raw_path):
        return linter._resource_diagnostic(
            raw_path,
            "FOREACH RUN_WORKFLOW",
            location,
            "Create the child workflow.lgwf file or update FOREACH RUN_WORKFLOW.",
        )
    return None


def _invalid_external_workflow_path(raw_path: str) -> bool:
    path = pathlib.Path(raw_path)
    return path.is_absolute() or ".." in path.parts or path.suffix.lower() != ".lgwf"


def _external_workflow_exists(linter, raw_path: str) -> bool:
    base_dir = linter._source_dir()
    if base_dir is not None:
        resolved = linter._resolve_relative(base_dir, raw_path)
        if resolved is not None and resolved.is_file():
            return True
    return pathlib.Path(raw_path).resolve().is_file()


def _load_child_workflow(linter, ref: ast_module.WorkflowRefDecl) -> ast_module.WorkflowAst | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    child_path = linter._resolve_relative(base_dir, ref.workflow_path)
    if child_path is None or not child_path.is_file():
        return None
    source = child_path.read_text(encoding="utf-8")
    child_ast = parser_module.Parser.from_text(source, source_name=str(child_path)).parse_workflow()
    validator_module.WorkflowValidator().validate(child_ast)
    return child_ast


def _load_child_workflow_path(linter, workflow_path: str) -> ast_module.WorkflowAst | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    child_path = linter._resolve_relative(base_dir, workflow_path)
    if child_path is None or not child_path.is_file():
        return None
    source = child_path.read_text(encoding="utf-8")
    child_ast = parser_module.Parser.from_text(source, source_name=str(child_path)).parse_workflow()
    validator_module.WorkflowValidator().validate(child_ast)
    return child_ast


def _lint_step_workflow_contract_writes(
    linter,
    ref: ast_module.WorkflowRefDecl,
    child_ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    if ref.contract is None:
        return []

    child_state_writes, child_file_writes = _child_workflow_write_sets(linter, child_ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for item in ref.contract.writes_state:
        if item.path in child_state_writes:
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"STEP {ref.id} CONTRACT writes state.{item.path} but child workflow does not obviously write it.",
                item.location or ref.location,
                severity="error",
                code="LGWF_STEP_WORKFLOW_CONTRACT_WRITE_UNPRODUCED",
                suggestion=(
                    "Add a child RESULT/UPDATES_STATE/CONTRACT WRITE for this state path, "
                    "or remove it from the STEP WORKFLOW boundary contract."
                ),
            )
        )
    for resource in ref.contract.writes_resources:
        if resource.root != "workspace" or resource.type != "file":
            continue
        path = linter._normalize_path(resource.path)
        if path in child_file_writes:
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"STEP {ref.id} CONTRACT writes workspace file {path} but child workflow does not obviously write it.",
                resource.location or ref.location,
                severity="error",
                code="LGWF_STEP_WORKFLOW_CONTRACT_WRITE_UNPRODUCED",
                suggestion=(
                    "Add a child OUTPUT_JSON/OUTPUT_FILE/PERSIST/CONTRACT WRITE or statically visible Python write "
                    "for this file path, or remove it from the STEP WORKFLOW boundary contract."
                ),
            )
        )
    return diagnostics


def _lint_foreach_workflow_contract_writes(
    linter,
    statement: ast_module.ForeachDecl,
    body: ast_module.ForeachWorkflowBodyDecl,
    child_ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    if body.contract is None:
        return []

    child_state_writes, child_file_writes = _child_workflow_write_sets(linter, child_ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for item in body.contract.writes_state:
        if item.path in child_state_writes:
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"FOREACH {statement.id} WORKFLOW body CONTRACT writes state.{item.path} but child workflow does not obviously write it.",
                item.location or body.location,
                severity="error",
                code="LGWF_FOREACH_WORKFLOW_CONTRACT_WRITE_UNPRODUCED",
                suggestion=(
                    "Add a child RESULT/UPDATES_STATE/CONTRACT WRITE for this state path, "
                    "or remove it from the FOREACH WORKFLOW body contract."
                ),
            )
        )
    for resource in body.contract.writes_resources:
        if resource.root != "workspace" or resource.type != "file":
            continue
        path = linter._normalize_path(resource.path)
        if path in child_file_writes:
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"FOREACH {statement.id} WORKFLOW body CONTRACT writes workspace file {path} but child workflow does not obviously write it.",
                resource.location or body.location,
                severity="error",
                code="LGWF_FOREACH_WORKFLOW_CONTRACT_WRITE_UNPRODUCED",
                suggestion=(
                    "Add a child OUTPUT_JSON/OUTPUT_FILE/PERSIST/CONTRACT WRITE or statically visible Python write "
                    "for this file path, or remove it from the FOREACH WORKFLOW body contract."
                ),
            )
        )
    return diagnostics


def _lint_child_workflow_with_boundary_inputs(
    linter,
    ref: ast_module.WorkflowRefDecl,
    child_ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    previous_state_paths = getattr(linter, "_boundary_input_state_paths", set())
    previous_file_paths = getattr(linter, "_boundary_input_workspace_file_paths", set())
    previous_output_state_paths = getattr(linter, "_boundary_output_state_paths", set())
    previous_output_file_paths = getattr(linter, "_boundary_output_workspace_file_paths", set())
    state_paths = set(previous_state_paths)
    file_paths = set(previous_file_paths)
    output_state_paths = set(previous_output_state_paths)
    output_file_paths = set(previous_output_file_paths)
    if ref.contract is not None:
        state_paths.update(item.path for item in ref.contract.reads_state)
        file_paths.update(
            linter._normalize_path(resource.path)
            for resource in ref.contract.reads_resources
            if resource.root == "workspace" and resource.type == "file"
        )
        output_state_paths.update(item.path for item in ref.contract.writes_state)
        output_file_paths.update(
            linter._normalize_path(resource.path)
            for resource in ref.contract.writes_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    linter._boundary_input_state_paths = state_paths
    linter._boundary_input_workspace_file_paths = file_paths
    linter._boundary_output_state_paths = output_state_paths
    linter._boundary_output_workspace_file_paths = output_file_paths
    try:
        return linter.lint(child_ast)
    finally:
        linter._boundary_input_state_paths = previous_state_paths
        linter._boundary_input_workspace_file_paths = previous_file_paths
        linter._boundary_output_state_paths = previous_output_state_paths
        linter._boundary_output_workspace_file_paths = previous_output_file_paths


def _child_workflow_write_sets(
    linter,
    child_ast: ast_module.WorkflowAst,
) -> tuple[set[str], set[str]]:
    previous_source_dir = getattr(linter, "_current_source_dir", None)
    linter._current_source_dir = linter._source_dir_for_ast(child_ast)
    try:
        defaults = linter._defaults(child_ast)
        state_writes = {
            path
            for statement in child_ast.statements
            for _, path in linter._statement_state_writes(statement)
        }
        file_writes = {
            path
            for statement in child_ast.statements
            for _, path in data_flow_rules_module._statement_workspace_file_writes(linter, statement, defaults)
        }
        return state_writes, file_writes
    finally:
        linter._current_source_dir = previous_source_dir
