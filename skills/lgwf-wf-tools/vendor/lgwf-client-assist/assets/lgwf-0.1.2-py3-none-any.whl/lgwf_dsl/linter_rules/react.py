from collections.abc import Iterable
from pathlib import PurePosixPath

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def lint_parallel_contexts(
    linter,
    parallel: ast_module.ParallelDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for step in parallel.steps:
        codex_tasks = _codex_tasks(linter, step.task)
        if codex_tasks and not any(_has_explicit_codex_scope(linter, task) for task in codex_tasks):
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"PARALLEL {parallel.id} step {step.id} has no CODEX context_refs or targets; parallel steps should organize context through files, explicit refs, or analysis targets.",
                    step.location or parallel.location,
                    severity="error",
                )
            )
        if isinstance(step.task, ast_module.ReactDecl):
            diagnostics.extend(lint_react_observe_scope(linter, step.task, context_sets))
            diagnostics.extend(lint_react_observe_feedback_loop(linter, step.task, context_sets))
            diagnostics.extend(lint_react_reason_consumes_feedback(linter, step.task, context_sets))
    return diagnostics

def _codex_tasks(
    linter,
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.ReactDecl,
) -> list[ast_module.CodexDecl]:
    if isinstance(task, ast_module.CodexDecl):
        return [task]
    if isinstance(task, ast_module.ReactDecl):
        return [
            slot.task
            for slot in task.slots.values()
            if isinstance(slot.task, ast_module.CodexDecl)
        ]
    return []

def _has_explicit_codex_scope(linter, task: ast_module.CodexDecl) -> bool:
    return bool(
        task.contexts
        or task.target_dirs
        or task.target_files
        or task.target_dirs_path is not None
        or task.target_files_path is not None
        or task.edit_dirs
        or task.edit_dirs_path is not None
    )

def lint_react_observe_scope(
    linter,
    react: ast_module.ReactDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    observe_slot = react.slots.get("observe")
    if observe_slot is None or not isinstance(observe_slot.task, ast_module.CodexDecl):
        return []

    observed_paths = {
        linter._normalize_path(resource.path)
        for resource in _react_slot_contexts(linter, react, observe_slot.task, context_sets)
        if resource.type == "file"
    }

    required_paths: set[str] = set()
    for slot_name in ("reason", "act"):
        slot = react.slots.get(slot_name)
        if slot is None or not isinstance(slot.task, ast_module.CodexDecl):
            continue
        for resource in _react_slot_contexts(linter, react, slot.task, context_sets):
            path = linter._normalize_path(resource.path)
            if _is_factual_data_file(linter, resource.type, path):
                required_paths.add(path)

    missing_paths = sorted(required_paths - observed_paths)
    if not missing_paths:
        return []

    missing_text = ", ".join(missing_paths)
    return [
        diagnostics_module.Diagnostic(
            f"REACT {react.id} observe context_refs missing input file used by reason/act: {missing_text}",
            observe_slot.location or react.location,
            severity="error",
        )
    ]

def lint_react_observe_feedback_loop(
    linter,
    react: ast_module.ReactDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    observe_slot = react.slots.get("observe")
    reason_slot = react.slots.get("reason")
    if (
        observe_slot is None
        or reason_slot is None
        or not isinstance(observe_slot.task, ast_module.CodexDecl)
        or not isinstance(reason_slot.task, ast_module.CodexDecl)
        or observe_slot.task.output_json_path is None
    ):
        return []

    observe_output_path = linter._normalize_path(observe_slot.task.output_json_path)
    reason_context_paths = {
        linter._normalize_path(resource.path)
        for resource in _react_slot_contexts(linter, react, reason_slot.task, context_sets)
        if resource.root == "workspace" and resource.type == "file"
    }
    if observe_output_path in reason_context_paths:
        return []

    return [
        diagnostics_module.Diagnostic(
            f"REACT {react.id} reason context_refs missing observe OUTPUT_JSON feedback file: {observe_output_path}",
            reason_slot.location or react.location,
            severity="error",
            code="LGWF_REACT_FEEDBACK_LOOP_MISSING",
            suggestion=(
                f'Add CONTEXT workspace file "{observe_output_path}" to the REACT reason slot. '
                "If the file is absent on the first iteration, initialize an empty/default artifact before the REACT block."
            ),
        )
    ]

def lint_react_reason_consumes_feedback(
    linter,
    react: ast_module.ReactDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    if react.max_steps <= 1:
        return []

    reason_slot = react.slots.get("reason")
    if reason_slot is None:
        return []

    reason_state_reads = _contract_state_reads(reason_slot.task)
    reason_workspace_file_reads = _contract_workspace_file_reads(linter, reason_slot.task)
    if isinstance(reason_slot.task, ast_module.CodexDecl):
        reason_workspace_file_reads.update(
            linter._normalize_path(resource.path)
            for resource in _react_slot_contexts(linter, react, reason_slot.task, context_sets)
            if resource.root == "workspace" and resource.type == "file"
        )

    diagnostics: list[diagnostics_module.Diagnostic] = []
    for slot_name, code in (
        ("observe", "LGWF_REACT_REASON_MISSING_OBSERVE_FEEDBACK"),
        ("decide", "LGWF_REACT_REASON_MISSING_DECIDE_FEEDBACK"),
    ):
        slot = react.slots.get(slot_name)
        if slot is None:
            continue
        state_writes = _feedback_state_writes(slot.task)
        missing_state = sorted(state_writes - reason_state_reads)
        missing_file_writes: set[str] = set()
        if not state_writes or missing_state:
            missing_file_writes = _feedback_workspace_file_writes(linter, slot.task, slot_name)
        missing_files = sorted(missing_file_writes - reason_workspace_file_reads)
        if not missing_state and not missing_files:
            continue
        missing_parts = [*(f"state.{path}" for path in missing_state), *missing_files]
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"REACT {react.id} reason does not read {slot_name} feedback: {', '.join(missing_parts)}",
                reason_slot.location or react.location,
                severity="error",
                code=code,
                suggestion=(
                    "Add matching CONTRACT READ entries to the REACT reason slot. "
                    "If the first iteration needs a default value, initialize the feedback before the REACT block."
                ),
            )
        )
    return diagnostics

def lint_repeated_react_inline_contexts(
    linter,
    react: ast_module.ReactDecl,
) -> list[diagnostics_module.Diagnostic]:
    refs: dict[tuple[str, str, str], list[str]] = {}
    for slot_name, slot in react.slots.items():
        if not isinstance(slot.task, ast_module.CodexDecl):
            continue
        for context in slot.task.contexts:
            if context.resource is None:
                continue
            resource = context.resource
            key = (resource.root, resource.type, linter._normalize_path(resource.path))
            refs.setdefault(key, []).append(slot_name)
    repeated = [
        (key, sorted(set(slot_names)))
        for key, slot_names in refs.items()
        if len(set(slot_names)) >= 2
    ]
    if not repeated:
        return []
    details = ", ".join(
        f"{root} {resource_type} {path} in {','.join(slot_names)}"
        for (root, resource_type, path), slot_names in repeated
    )
    return [
        diagnostics_module.Diagnostic(
            f"REACT {react.id} repeats inline CONTEXT refs: {details}",
            react.location,
            severity="error",
            code="LGWF_CONTEXT_REPEAT",
            suggestion=(
                "Extract repeated refs into a CONTEXT_SET and reference it once at REACT level, "
                "or keep the repeat only if each slot intentionally needs a separate explicit audit trail."
            ),
        )
    ]

def _contract_state_reads(
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
) -> set[str]:
    contract = getattr(task, "contract", None)
    if contract is None:
        return set()
    return {item.path for item in contract.reads_state}

def _contract_workspace_file_reads(
    linter,
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
) -> set[str]:
    contract = getattr(task, "contract", None)
    if contract is None:
        return set()
    return {
        linter._normalize_path(resource.path)
        for resource in contract.reads_resources
        if resource.root == "workspace" and resource.type == "file"
    }

def _feedback_state_writes(
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
) -> set[str]:
    contract = getattr(task, "contract", None)
    if contract is None:
        return set()
    return {
        item.path
        for item in contract.writes_state
        if not _is_react_control_state(item.path)
    }

def _feedback_workspace_file_writes(
    linter,
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
    slot_name: str,
) -> set[str]:
    contract = getattr(task, "contract", None)
    if contract is None:
        return set()
    writes = {
        linter._normalize_path(resource.path)
        for resource in contract.writes_resources
        if resource.root == "workspace" and resource.type == "file"
    }
    if slot_name == "observe" and isinstance(task, ast_module.CodexDecl) and task.output_json_path is not None:
        writes.discard(linter._normalize_path(task.output_json_path))
    return writes

def _is_react_control_state(path: str) -> bool:
    return path == "next" or path.startswith("__route__")

def _expand_contexts(
    linter,
    contexts: Iterable[ast_module.ContextRef],
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[ast_module.ResourceRef]:
    resources: list[ast_module.ResourceRef] = []
    for context in contexts:
        if context.resource is not None:
            resources.append(context.resource)
        elif context.context_set is not None and context.context_set in context_sets:
            resources.extend(linter._context_set_resources(context.context_set, context_sets))
    return resources

def _react_slot_contexts(
    linter,
    react: ast_module.ReactDecl,
    task: ast_module.CodexDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[ast_module.ResourceRef]:
    return [
        *_expand_contexts(linter, react.contexts, context_sets),
        *_expand_contexts(linter, task.contexts, context_sets),
    ]

def _is_factual_data_file(linter, resource_type: str, path: str) -> bool:
    parsed = PurePosixPath(path)
    return resource_type == "file" and parsed.parts[:1] == ("data",) and parsed.suffix in {".json", ".md"}
