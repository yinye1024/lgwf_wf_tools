import pathlib
from pathlib import PurePosixPath
import re

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


_PROMPT_FILE_REF_PATTERN = re.compile(
    r"(?<![\w./-])(?:\.lgwf|data|reports)/[A-Za-z0-9._~!$&'()*+,;=:@/%-]+\.[A-Za-z0-9][A-Za-z0-9._-]*"
)
_PROMPT_INPUT_CONTEXT_WORDS = (
    "read",
    "load",
    "use",
    "refer",
    "reference",
    "input",
    "source",
    "consume",
    "读取",
    "加载",
    "使用",
    "参考",
    "输入",
    "来源",
    "基于",
    "根据",
)
_PROMPT_OUTPUT_CONTEXT_WORDS = (
    "write",
    "create",
    "save",
    "output",
    "generate",
    "produce",
    "emit",
    "persist",
    "写入",
    "创建",
    "保存",
    "输出",
    "生成",
    "产出",
    "落盘",
)


def lint_python_contracts(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for python in linter._python_decls(statement):
            contract = python.contract
            reads = linter._python_script_file_reads(python, defaults)
            business_reads = sorted(path for path in reads["paths"] if linter._is_business_artifact_read_path(path))
            has_unknown_business_read = bool(reads["unknown"]) and contract is None
            if business_reads or has_unknown_business_read:
                if contract is None:
                    paths = ", ".join(business_reads) if business_reads else "unknown dynamic path"
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            f"PY {python.id} reads business artifact file(s) without CONTRACT: {paths}.",
                            python.location,
                            severity="error",
                            code="LGWF_PY_FILE_READ_CONTRACT_MISSING",
                            suggestion="Declare CONTRACT READ workspace file entries for every business artifact read by this Python script.",
                        )
                    )
                else:
                    declared_reads = linter._contract_read_resource_paths(contract)
                    missing_reads = [path for path in business_reads if path not in declared_reads]
                    if missing_reads:
                        declared_text = ", ".join(sorted(declared_reads)) if declared_reads else "<none>"
                        diagnostics.append(
                            diagnostics_module.Diagnostic(
                                (
                                    f"PY {python.id} reads file(s) not declared in CONTRACT: "
                                    f"{', '.join(missing_reads)}. Declared reads: {declared_text}."
                                ),
                                python.location,
                                severity="error",
                                code="LGWF_PY_FILE_READ_CONTRACT_MISMATCH",
                                suggestion="Add matching CONTRACT READ workspace file entries, or update the script to read only declared artifacts.",
                            )
                        )

            writes = linter._python_script_file_writes(python, defaults)
            business_writes = sorted(path for path in writes["paths"] if linter._is_business_artifact_path(path))
            has_unknown_business_write = bool(writes["unknown"]) and contract is None
            if not business_writes and not has_unknown_business_write:
                continue

            if contract is None:
                paths = ", ".join(business_writes) if business_writes else "unknown dynamic path"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PY {python.id} writes business artifact file(s) without CONTRACT: {paths}.",
                        python.location,
                        severity="error",
                        code="LGWF_PY_FILE_WRITE_CONTRACT_MISSING",
                        suggestion="Declare CONTRACT WRITE workspace file entries for every business artifact written by this Python script.",
                    )
                )
                continue

            declared = linter._contract_write_resource_paths(contract)
            missing = [path for path in business_writes if path not in declared]
            if missing:
                declared_text = ", ".join(sorted(declared)) if declared else "<none>"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"PY {python.id} writes file(s) not declared in CONTRACT: "
                            f"{', '.join(missing)}. Declared writes: {declared_text}."
                        ),
                        python.location,
                        severity="error",
                        code="LGWF_PY_FILE_WRITE_CONTRACT_MISMATCH",
                        suggestion="Add matching CONTRACT WRITE workspace file entries, or update the script to write only declared artifacts.",
                    )
                )
    return diagnostics

def lint_codex_prompt_contracts(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for codex in linter._codex_decls(statement):
            prompt_refs = _codex_prompt_file_refs(linter, codex, defaults)
            if not prompt_refs:
                continue
            if codex.contract is None:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"CODEX {codex.id} prompt references business artifact file(s) "
                            f"without CONTRACT READ: {', '.join(prompt_refs)}."
                        ),
                        codex.location,
                        severity="error",
                        code="LGWF_CODEX_PROMPT_FILE_READ_CONTRACT_MISSING",
                        suggestion=(
                            "Declare CONTRACT READ workspace file entries for every business artifact "
                            "referenced by this Codex prompt."
                        ),
                    )
                )
                continue

            declared_reads = linter._contract_read_workspace_file_paths(codex.contract)
            missing = [path for path in prompt_refs if path not in declared_reads]
            if missing:
                declared_text = ", ".join(sorted(declared_reads)) if declared_reads else "<none>"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"CODEX {codex.id} prompt references file(s) not declared in CONTRACT READ: "
                            f"{', '.join(missing)}. Declared reads: {declared_text}."
                        ),
                        codex.location,
                        severity="error",
                        code="LGWF_CODEX_PROMPT_FILE_READ_CONTRACT_MISMATCH",
                        suggestion=(
                            "Add matching CONTRACT READ workspace file entries, or remove the prompt references "
                            "to undeclared business artifacts."
                        ),
                    )
                )
    return diagnostics

def lint_context_contract_reads(
    linter,
    ast: ast_module.WorkflowAst,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for codex in linter._codex_decls(statement):
            required_reads = _codex_workspace_context_reads(linter, codex, context_sets)
            if not required_reads:
                continue
            declared_reads = _contract_workspace_resource_reads(linter, codex.contract)
            missing = [
                resource
                for resource in required_reads
                if _resource_key(linter, resource) not in declared_reads
            ]
            if not missing:
                continue
            missing_text = ", ".join(_resource_text(linter, resource) for resource in missing)
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"CODEX {codex.id} CONTEXT workspace refs are missing matching CONTRACT READ: {missing_text}.",
                    codex.location,
                    severity="error",
                    code="LGWF_CONTRACT_CONTEXT_READ_MISSING",
                    suggestion=(
                        "Declare matching CONTRACT READ workspace file/dir entries for every workflow artifact "
                        "passed through CODEX CONTEXT."
                    ),
                )
            )
    return diagnostics

def lint_run_workflow_boundary_contracts(
    linter,
    ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        if not isinstance(statement, ast_module.RunWorkflowDecl):
            continue
        contract = statement.contract
        state_reads = {item.path for item in contract.reads_state} if contract is not None else set()
        resource_reads = _contract_workspace_resource_reads(linter, contract)
        resource_writes = _contract_workspace_resource_writes(linter, contract)

        missing: list[str] = []
        if statement.input_path.path not in state_reads:
            missing.append(f"READ state.{statement.input_path.path}")
        workflow_key = ("workspace", "file", linter._normalize_path(statement.workflow_path))
        if workflow_key not in resource_reads:
            missing.append(f'READ workspace file "{linter._normalize_path(statement.workflow_path)}"')
        work_dir_key = ("workspace", "dir", linter._normalize_path(statement.work_dir))
        if work_dir_key not in resource_writes:
            missing.append(f'WRITE workspace dir "{linter._normalize_path(statement.work_dir)}"')
        if not missing:
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"RUN_WORKFLOW {statement.id} boundary CONTRACT is incomplete: {', '.join(missing)}.",
                statement.location,
                severity="error",
                code="LGWF_CONTRACT_RUN_WORKFLOW_BOUNDARY_MISSING",
                suggestion=(
                    "Declare the parent-visible child workflow boundary only: READ the input state, "
                    "READ the child workflow entry file, and WRITE the child work_dir."
                ),
            )
        )
    return diagnostics

def _codex_prompt_file_refs(
    linter,
    codex: ast_module.CodexDecl,
    defaults: ast_module.DefaultsDecl,
) -> list[str]:
    prompt_path = _resolve_codex_prompt_path(linter, codex.prompt_path, defaults)
    if prompt_path is None or not prompt_path.is_file():
        return []
    text = prompt_path.read_text(encoding="utf-8")
    refs: set[str] = set()
    output_paths = _codex_output_paths(linter, codex)

    for match in re.finditer(r"\[[^\]]*\]\(([^)\s]+)(?:\s+[^)]*)?\)", text):
        _add_prompt_file_ref(linter, refs, text, match.group(1), match.start(1), match.end(1), output_paths)
    for match in re.finditer(r"`([^`\n]+)`", text):
        _add_prompt_file_ref(linter, refs, text, match.group(1), match.start(1), match.end(1), output_paths)
    for match in _PROMPT_FILE_REF_PATTERN.finditer(text):
        _add_prompt_file_ref(linter, refs, text, match.group(0), match.start(0), match.end(0), output_paths)

    return sorted(refs)

def _codex_output_paths(linter, codex: ast_module.CodexDecl) -> set[str]:
    return {
        linter._normalize_path(path)
        for path in (codex.output_json_path, codex.output_file_path)
        if path is not None
    }

def _add_prompt_file_ref(
    linter,
    refs: set[str],
    text: str,
    raw_path: str,
    start: int,
    end: int,
    output_paths: set[str],
) -> None:
    ref = _normalize_prompt_file_ref(linter, raw_path)
    if ref is None or ref in output_paths:
        return
    if _prompt_ref_is_output_context(text, start, end):
        return
    refs.add(ref)

def _normalize_prompt_file_ref(linter, raw_path: str) -> str | None:
    value = raw_path.strip().strip("<>").strip()
    if not value or "://" in value or value.startswith("#"):
        return None
    value = value.split()[0]
    value = value.split("#", 1)[0].split("?", 1)[0]
    value = value.strip("\"'")
    value = value.rstrip(".,;:)]}\"'")
    value = value.replace("\\", "/")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.suffix:
        return None
    normalized = path.as_posix()
    if not linter._is_business_artifact_read_path(normalized):
        return None
    return normalized

def _prompt_ref_is_output_context(text: str, start: int, end: int) -> bool:
    window_start = max(0, start - 80)
    window_end = min(len(text), end + 80)
    before = text[window_start:start].lower()
    after = text[end:window_end].lower()

    input_distance = _nearest_context_word_distance(before, after, _PROMPT_INPUT_CONTEXT_WORDS)
    output_distance = _nearest_context_word_distance(before, after, _PROMPT_OUTPUT_CONTEXT_WORDS)
    return output_distance is not None and (input_distance is None or output_distance < input_distance)

def _nearest_context_word_distance(before: str, after: str, words: tuple[str, ...]) -> int | None:
    distances: list[int] = []
    for word in words:
        before_index = before.rfind(word)
        if before_index >= 0:
            distances.append(len(before) - before_index - len(word))
        after_index = after.find(word)
        if after_index >= 0:
            distances.append(after_index)
    return min(distances) if distances else None

def _resolve_codex_prompt_path(
    linter,
    raw_path: str,
    defaults: ast_module.DefaultsDecl,
) -> pathlib.Path | None:
    root = defaults.ref_root.get("root", "workflow")
    if root != "workflow":
        return None
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    ref_root_path = defaults.ref_root.get("path", ".")
    resolved_base = linter._resolve_relative(base_dir, ref_root_path)
    if resolved_base is None:
        return None
    return linter._resolve_relative(resolved_base, raw_path)

def _codex_workspace_context_reads(
    linter,
    codex: ast_module.CodexDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[ast_module.ResourceRef]:
    resources: list[ast_module.ResourceRef] = []
    for context in codex.contexts:
        if context.resource is not None:
            resources.append(context.resource)
        elif context.context_set is not None:
            resources.extend(linter._context_set_resources(context.context_set, context_sets))
    required: list[ast_module.ResourceRef] = []
    output_paths = _codex_output_paths(linter, codex)
    seen: set[tuple[str, str, str]] = set()
    for resource in resources:
        if not _context_resource_requires_contract_read(linter, resource):
            continue
        if resource.type == "file" and linter._normalize_path(resource.path) in output_paths:
            continue
        key = _resource_key(linter, resource)
        if key in seen:
            continue
        seen.add(key)
        required.append(resource)
    return required

def _context_resource_requires_contract_read(linter, resource: ast_module.ResourceRef) -> bool:
    if resource.root != "workspace" or resource.type not in {"file", "dir"}:
        return False
    path = linter._normalize_path(resource.path)
    if path.startswith("data/") or path.startswith(".tmp/"):
        return False
    return path.startswith(".lgwf/") or path.startswith("reports/")

def _contract_workspace_resource_reads(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[tuple[str, str, str]]:
    if contract is None:
        return set()
    return {
        _resource_key(linter, resource)
        for resource in contract.reads_resources
        if resource.root == "workspace" and resource.type in {"file", "dir"}
    }

def _contract_workspace_resource_writes(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[tuple[str, str, str]]:
    if contract is None:
        return set()
    return {
        _resource_key(linter, resource)
        for resource in contract.writes_resources
        if resource.root == "workspace" and resource.type in {"file", "dir"}
    }

def _resource_key(linter, resource: ast_module.ResourceRef) -> tuple[str, str, str]:
    return (resource.root, resource.type, linter._normalize_path(resource.path))

def _resource_text(linter, resource: ast_module.ResourceRef) -> str:
    return f'{resource.root} {resource.type} "{linter._normalize_path(resource.path)}"'

def lint_redundant_contract_state_writes(
    linter,
    ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        diagnostics.extend(_lint_statement_redundant_contract_state_writes(linter, statement))
    return diagnostics

def lint_runtime_output_contract_consistency(
    linter,
    ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for codex in linter._codex_decls(statement):
            contract = codex.contract
            output_paths = _codex_output_paths(linter, codex)
            if not output_paths:
                continue
            declared_reads = _contract_workspace_file_reads(linter, contract)
            read_conflicts = sorted(declared_reads & output_paths)
            if read_conflicts:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"CODEX {codex.id} CONTRACT READ includes this node's output file "
                            f"declaration: {', '.join(read_conflicts)}."
                        ),
                        codex.location,
                        severity="error",
                        code="LGWF_CONTRACT_OUTPUT_READ_CONFLICT",
                        suggestion=(
                            "OUTPUT_JSON/OUTPUT_FILE declares a file produced by this Codex node; "
                            "remove it from CONTRACT READ workspace file entries."
                        ),
                    )
                )
            declared_writes = _contract_workspace_file_writes(linter, contract)
            missing_writes = sorted(output_paths - declared_writes)
            if not missing_writes:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"CODEX {codex.id} output file declaration is missing matching "
                        f"CONTRACT WRITE: {', '.join(missing_writes)}."
                    ),
                    codex.location,
                    severity="error",
                    code="LGWF_CONTRACT_OUTPUT_WRITE_MISSING",
                    suggestion=(
                        "OUTPUT_JSON/OUTPUT_FILE produces node output files; declare matching "
                        "CONTRACT WRITE workspace file entries."
                    ),
                )
            )
        diagnostics.extend(_lint_statement_persist_contract_writes(linter, statement))
    return diagnostics

def _contract_workspace_file_reads(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[str]:
    if contract is None:
        return set()
    return {
        linter._normalize_path(resource.path)
        for resource in contract.reads_resources
        if resource.root == "workspace" and resource.type == "file"
    }

def _contract_workspace_file_writes(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[str]:
    if contract is None:
        return set()
    return {
        linter._normalize_path(resource.path)
        for resource in contract.writes_resources
        if resource.root == "workspace" and resource.type == "file"
    }

def _lint_statement_persist_contract_writes(
    linter,
    statement: ast_module.StatementDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    if isinstance(statement, (ast_module.ApprovalDecl, ast_module.ReviewDecl, ast_module.ChoiceDecl)):
        persist_path = statement.persist_path
        if persist_path:
            normalized = linter._normalize_path(persist_path)
            declared_writes = _contract_workspace_file_writes(linter, statement.contract)
            if normalized not in declared_writes:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"{statement.id} PERSIST output file is missing matching "
                            f"CONTRACT WRITE: {normalized}."
                        ),
                        statement.location,
                        severity="error",
                        code="LGWF_CONTRACT_PERSIST_WRITE_MISSING",
                        suggestion=(
                            "PERSIST produces a node output file; declare a matching "
                            "CONTRACT WRITE workspace file entry."
                        ),
                    )
                )
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_persist_contract_writes(linter, slot.task))
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_persist_contract_writes(linter, slot.task))
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            diagnostics.extend(_lint_statement_persist_contract_writes(linter, step.task))
    return diagnostics

def _lint_statement_redundant_contract_state_writes(
    linter,
    statement: ast_module.StatementDecl,
    label_prefix: str | None = None,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    contract = getattr(statement, "contract", None)
    node_id = getattr(statement, "id", "")
    label = f"{label_prefix}.{node_id}" if label_prefix and node_id else node_id or label_prefix or "node"
    if contract is not None:
        contract_writes = {item.path for item in contract.writes_state}
        result_path = getattr(statement, "result_path", None)
        if isinstance(result_path, ast_module.StateRef) and result_path.path in contract_writes:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"{label} CONTRACT WRITE state.{result_path.path} repeats "
                        f"RESULT state.{result_path.path}."
                    ),
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_RESULT_WRITE_REDUNDANT",
                    suggestion="RESULT already declares this execution result state path; remove the duplicate CONTRACT WRITE state entry.",
                )
            )
        if isinstance(statement, ast_module.PythonDecl):
            update_paths = {item.path for item in statement.state_update_writes}
            for path in sorted(contract_writes & update_paths):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"{label} CONTRACT WRITE state.{path} repeats UPDATES_STATE WRITE state.{path}.",
                        statement.location,
                        severity="error",
                        code="LGWF_CONTRACT_UPDATES_STATE_WRITE_REDUNDANT",
                        suggestion="UPDATES_STATE already declares this stdout state patch path; remove the duplicate CONTRACT WRITE state entry.",
                    )
                )

    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    slot.task,
                    f"{statement.id}.{slot.slot_name}",
                )
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    slot.task,
                    f"{statement.id}.{slot.slot_name}",
                )
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    step.task,
                    f"{statement.id}.{step.id}",
                )
            )
    return diagnostics
