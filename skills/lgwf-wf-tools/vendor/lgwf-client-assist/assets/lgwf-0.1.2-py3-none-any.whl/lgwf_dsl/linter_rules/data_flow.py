import json
import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


_WORKFLOW_ARTIFACT_NAME_HINTS = (
    "create",
    "generated",
    "generation",
    "result",
    "requirements",
    "confirmation",
    "decision",
    "final",
    "report",
)


def lint_node_data_flow(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    diagnostics.extend(_lint_state_inputs(linter, ast))
    diagnostics.extend(_lint_workspace_file_inputs(linter, ast, defaults))
    return diagnostics


def _lint_state_inputs(linter, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
    writes = linter._state_writes_by_path(ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in linter._statement_state_reads(statement):
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            if path in getattr(linter, "_boundary_input_state_paths", set()):
                continue
            if linter._is_external_initial_input(path):
                continue
            if not _state_path_requires_local_producer(linter, ast, path):
                continue
            writers = [writer for writer in writes.get(path, []) if writer != node_id]
            if writers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} reads state.{path} but no workflow node obviously writes it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_NODE_STATE_INPUT_UNPRODUCED",
                    suggestion=(
                        "Add an upstream RESULT/UPDATES_STATE/CONTRACT WRITE for this state path, "
                        "or use state.input for an explicit initial workflow input."
                    ),
                )
            )
    return diagnostics


def _state_path_requires_local_producer(linter, ast: ast_module.WorkflowAst, path: str) -> bool:
    normalized = linter._normalize_path(path)
    workflow_prefix = f"{ast.name}."
    return normalized.startswith(workflow_prefix)


def _lint_workspace_file_inputs(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    writes = _workspace_file_writes(linter, ast, defaults)
    boundary_inputs = set(getattr(linter, "_boundary_input_workspace_file_paths", set()))
    boundary_inputs.update(_artifact_contract_workspace_input_paths(linter))
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in _statement_workspace_file_reads(linter, statement):
            if path in boundary_inputs:
                continue
            if not _requires_workspace_file_producer(linter, path):
                continue
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            if node_id in writes.get(path, []):
                continue
            producers = [writer for writer in writes.get(path, []) if writer != node_id]
            if producers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} reads workspace file {path} but no workflow node obviously writes it.",
                    getattr(statement, "location", None),
                    severity="warning",
                    code="LGWF_NODE_FILE_INPUT_UNPRODUCED",
                    suggestion=(
                        "If this is a workflow-produced artifact, add an upstream OUTPUT_JSON/OUTPUT_FILE/PERSIST/"
                        "CONTRACT WRITE. If it is an intentional pre-existing input, keep it as an external workspace input."
                    ),
                )
            )
    return diagnostics

def _artifact_contract_workspace_input_paths(linter) -> set[str]:
    paths: set[str] = set()
    for contract_path in _artifact_contract_paths(linter):
        if not contract_path.is_file():
            continue
        try:
            payload = json.loads(contract_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        for key in ("bootstrap_inputs", "external_inputs", "input_files", "inputs"):
            _collect_artifact_contract_paths(linter, paths, payload.get(key))
    return paths

def _artifact_contract_paths(linter) -> list[pathlib.Path]:
    candidates: list[pathlib.Path] = []
    source_dir = linter._source_dir()
    if source_dir is not None:
        candidates.append(source_dir / "artifact_contracts.json")
    if linter.package_root is not None:
        package_contract = linter.package_root / "artifact_contracts.json"
        if package_contract not in candidates:
            candidates.append(package_contract)
    return candidates

def _collect_artifact_contract_paths(linter, paths: set[str], value: object) -> None:
    if isinstance(value, str):
        paths.add(linter._normalize_path(value))
        return
    if isinstance(value, list):
        for item in value:
            _collect_artifact_contract_paths(linter, paths, item)
        return
    if not isinstance(value, dict):
        return
    for key in ("path", "file", "workspace_file"):
        item = value.get(key)
        if isinstance(item, str):
            paths.add(linter._normalize_path(item))
    for key in ("paths", "files", "workspace_files"):
        _collect_artifact_contract_paths(linter, paths, value.get(key))


def _workspace_file_writes(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> dict[str, list[str]]:
    writes: dict[str, list[str]] = {}
    for statement in ast.statements:
        for node_id, path in _statement_workspace_file_writes(linter, statement, defaults):
            writes.setdefault(path, []).append(node_id)
    return writes


def _statement_workspace_file_reads(
    linter,
    statement: ast_module.StatementDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    reads: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        reads.extend(
            (node_id, linter._normalize_path(resource.path))
            for resource in contract.reads_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            reads.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_workspace_file_reads(linter, step.task)
            )
    return reads


def _statement_workspace_file_writes(
    linter,
    statement: ast_module.StatementDecl,
    defaults: ast_module.DefaultsDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    writes: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        writes.extend(
            (node_id, linter._normalize_path(resource.path))
            for resource in contract.writes_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    if isinstance(statement, ast_module.CodexDecl):
        for path in (statement.output_json_path, statement.output_file_path):
            if path is not None:
                writes.append((statement.id, linter._normalize_path(path)))
    if isinstance(statement, (ast_module.ApprovalDecl, ast_module.ReviewDecl, ast_module.ChoiceDecl)):
        if statement.persist_path:
            writes.append((statement.id, linter._normalize_path(statement.persist_path)))
    if isinstance(statement, ast_module.PythonDecl):
        script_writes = linter._python_script_file_writes(statement, defaults)
        for path in script_writes["paths"]:
            normalized = linter._normalize_path(path)
            if linter._is_business_artifact_path(normalized):
                writes.append((statement.id, normalized))
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_writes(linter, slot.task, defaults)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_writes(linter, slot.task, defaults)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            writes.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_workspace_file_writes(linter, step.task, defaults)
            )
    return writes


def _requires_workspace_file_producer(linter, path: str) -> bool:
    normalized = linter._normalize_path(path)
    if normalized.startswith("data/"):
        return False
    if normalized.startswith(".lgwf/") or normalized.startswith("reports/"):
        return _path_looks_workflow_artifact(normalized)
    return False


def _path_looks_workflow_artifact(path: str) -> bool:
    name = path.rsplit("/", 1)[-1].lower()
    stem = name.rsplit(".", 1)[0]
    parts = [part for part in stem.replace("-", "_").split("_") if part]
    return any(part in _WORKFLOW_ARTIFACT_NAME_HINTS for part in parts)
