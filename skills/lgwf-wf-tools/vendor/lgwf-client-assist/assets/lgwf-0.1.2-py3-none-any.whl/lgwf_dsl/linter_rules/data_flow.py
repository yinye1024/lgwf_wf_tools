import json
import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def lint_node_data_flow(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    diagnostics.extend(_lint_state_inputs(linter, ast))
    diagnostics.extend(_lint_contract_graph(linter, ast, defaults))
    return diagnostics


def _lint_state_inputs(linter, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
    writes = linter._state_writes_by_path(ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in linter._statement_state_reads(statement):
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            if path in getattr(linter, "_boundary_input_state_paths", set()):
                continue
            if linter._is_external_initial_input(path):
                continue
            if not _state_path_requires_local_producer(linter, ast, path):
                continue
            writers = [writer for writer in writes.get(path, []) if writer != node_id]
            if writers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} reads state.{path} but no workflow node obviously writes it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_NODE_STATE_INPUT_UNPRODUCED",
                    suggestion=(
                        "Add an upstream RESULT/UPDATES_STATE/CONTRACT WRITE for this state path, "
                        "or use state.input for an explicit initial workflow input."
                    ),
                )
            )
    return diagnostics


def _state_path_requires_local_producer(linter, ast: ast_module.WorkflowAst, path: str) -> bool:
    normalized = linter._normalize_path(path)
    workflow_prefix = f"{ast.name}."
    return normalized.startswith(workflow_prefix)


def _artifact_contract_workspace_input_paths(linter) -> set[str]:
    paths: set[str] = set()
    for contract_path in _artifact_contract_paths(linter):
        if not contract_path.is_file():
            continue
        try:
            payload = json.loads(contract_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        for key in ("bootstrap_inputs", "external_inputs", "input_files", "inputs"):
            _collect_artifact_contract_paths(linter, paths, payload.get(key))
    return paths

def _artifact_contract_workspace_output_paths(linter) -> set[str]:
    paths: set[str] = set()
    for contract_path in _artifact_contract_paths(linter):
        if not contract_path.is_file():
            continue
        try:
            payload = json.loads(contract_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        for key in ("final_outputs", "outputs", "output_files", "final_output_files", "reports"):
            _collect_artifact_contract_paths(linter, paths, payload.get(key))
    return paths

def _artifact_contract_state_output_paths(linter) -> set[str]:
    paths: set[str] = set()
    for contract_path in _artifact_contract_paths(linter):
        if not contract_path.is_file():
            continue
        try:
            payload = json.loads(contract_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            continue
        _collect_state_paths(linter, paths, payload.get("final_state_outputs"))
        _collect_state_paths(linter, paths, payload.get("state_outputs"))
    return paths

def _artifact_contract_paths(linter) -> list[pathlib.Path]:
    candidates: list[pathlib.Path] = []
    source_dir = linter._source_dir()
    if source_dir is not None:
        candidates.append(source_dir / "artifact_contracts.json")
    if linter.package_root is not None:
        package_contract = linter.package_root / "artifact_contracts.json"
        if package_contract not in candidates:
            candidates.append(package_contract)
    return candidates

def _collect_artifact_contract_paths(linter, paths: set[str], value: object) -> None:
    if isinstance(value, str):
        paths.add(linter._normalize_path(value))
        return
    if isinstance(value, list):
        for item in value:
            _collect_artifact_contract_paths(linter, paths, item)
        return
    if not isinstance(value, dict):
        return
    for key in ("path", "file", "workspace_file"):
        item = value.get(key)
        if isinstance(item, str):
            paths.add(linter._normalize_path(item))
    for key in ("paths", "files", "workspace_files"):
        _collect_artifact_contract_paths(linter, paths, value.get(key))

def _collect_state_paths(linter, paths: set[str], value: object) -> None:
    if isinstance(value, str):
        normalized = linter._normalize_path(value)
        paths.add(normalized.removeprefix("state."))
        return
    if isinstance(value, list):
        for item in value:
            _collect_state_paths(linter, paths, item)
        return
    if isinstance(value, dict):
        for key in ("path", "state", "state_path"):
            item = value.get(key)
            if isinstance(item, str):
                paths.add(linter._normalize_path(item).removeprefix("state."))
        for key in ("paths", "states", "state_paths"):
            _collect_state_paths(linter, paths, value.get(key))


def _lint_contract_graph(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    reachability = _workflow_reachability(ast)
    diagnostics.extend(_lint_contract_state_reads(linter, ast, reachability))
    diagnostics.extend(_lint_contract_workspace_file_reads(linter, ast, defaults, reachability))
    diagnostics.extend(_lint_contract_workspace_file_writes(linter, ast, defaults, reachability))
    return diagnostics


def _lint_contract_state_reads(
    linter,
    ast: ast_module.WorkflowAst,
    reachability: dict[str, set[str]] | None,
) -> list[diagnostics_module.Diagnostic]:
    writes = _contract_state_writes(linter, ast)
    boundary_inputs = set(getattr(linter, "_boundary_input_state_paths", set()))
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in _statement_contract_state_reads(linter, statement):
            if path in boundary_inputs or linter._is_external_initial_input(path):
                continue
            if not _state_path_requires_local_producer(linter, ast, path):
                continue
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            producers = [
                writer
                for writer in writes.get(path, [])
                if _is_upstream_node(writer, node_id, reachability)
            ]
            if producers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} CONTRACT reads state.{path} but no upstream contract writes it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_READ_UNPRODUCED",
                    suggestion=(
                        "Add an upstream CONTRACT WRITE for this state path, declare it as a STEP boundary READ, "
                        "or use state.input for an explicit initial workflow input."
                    ),
                )
            )
    return diagnostics


def _lint_contract_state_writes(
    linter,
    ast: ast_module.WorkflowAst,
    reachability: dict[str, set[str]] | None,
) -> list[diagnostics_module.Diagnostic]:
    reads = _contract_state_reads(linter, ast)
    final_outputs = set(getattr(linter, "_boundary_output_state_paths", set()))
    final_outputs.update(_artifact_contract_state_output_paths(linter))
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in _statement_contract_state_writes(linter, statement):
            if path in final_outputs:
                continue
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            consumers = [
                reader
                for reader in reads.get(path, [])
                if _is_downstream_node(node_id, reader, reachability)
            ]
            if consumers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} CONTRACT writes state.{path} but no downstream contract reads it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_WRITE_UNCONSUMED",
                    suggestion=(
                        "Add a downstream CONTRACT READ for this state path, expose it through a STEP boundary, "
                        "or list it in artifact_contracts.json final_state_outputs."
                    ),
                )
            )
    return diagnostics


def _lint_contract_workspace_file_reads(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
    reachability: dict[str, set[str]] | None,
) -> list[diagnostics_module.Diagnostic]:
    del defaults
    writes = _contract_workspace_file_writes(linter, ast)
    boundary_inputs = set(getattr(linter, "_boundary_input_workspace_file_paths", set()))
    boundary_inputs.update(_artifact_contract_workspace_input_paths(linter))
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in _statement_workspace_file_reads(linter, statement):
            if _is_external_contract_workspace_input(path, boundary_inputs):
                continue
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            producers = [
                writer
                for writer in writes.get(path, [])
                if _is_upstream_node(writer, node_id, reachability)
            ]
            if producers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} CONTRACT reads workspace file {path} but no upstream contract writes it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_READ_UNPRODUCED",
                    suggestion=(
                        "Add an upstream CONTRACT WRITE for this file, declare it as a STEP boundary READ, "
                        "or list it in artifact_contracts.json bootstrap_inputs/external_inputs."
                    ),
                )
            )
    return diagnostics


def _lint_contract_workspace_file_writes(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
    reachability: dict[str, set[str]] | None,
) -> list[diagnostics_module.Diagnostic]:
    del defaults
    reads = _contract_workspace_file_reads(linter, ast)
    final_outputs = set(getattr(linter, "_boundary_output_workspace_file_paths", set()))
    final_outputs.update(_artifact_contract_workspace_output_paths(linter))
    diagnostics: list[diagnostics_module.Diagnostic] = []
    seen: set[tuple[str, str]] = set()
    for statement in ast.statements:
        for node_id, path in _statement_contract_workspace_file_writes(linter, statement):
            if path in final_outputs or path.startswith(".tmp/"):
                continue
            key = (node_id, path)
            if key in seen:
                continue
            seen.add(key)
            consumers = [
                reader
                for reader in reads.get(path, [])
                if _is_downstream_node(node_id, reader, reachability)
            ]
            if consumers:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"{node_id} CONTRACT writes workspace file {path} but no downstream contract reads it.",
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_WRITE_UNCONSUMED",
                    suggestion=(
                        "Add a downstream CONTRACT READ for this file, expose it through a STEP boundary, "
                        "or list it in artifact_contracts.json final_outputs."
                    ),
                )
            )
    return diagnostics


def _contract_state_reads(linter, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
    reads: dict[str, list[str]] = {}
    for statement in ast.statements:
        for node_id, path in _statement_contract_state_reads(linter, statement):
            reads.setdefault(path, []).append(node_id)
    return reads


def _contract_state_writes(linter, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
    writes: dict[str, list[str]] = {}
    for statement in ast.statements:
        for node_id, path in _statement_contract_state_writes(linter, statement):
            writes.setdefault(path, []).append(node_id)
    return writes


def _contract_workspace_file_reads(linter, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
    reads: dict[str, list[str]] = {}
    for statement in ast.statements:
        for node_id, path in _statement_workspace_file_reads(linter, statement):
            reads.setdefault(path, []).append(node_id)
    return reads


def _contract_workspace_file_writes(linter, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
    writes: dict[str, list[str]] = {}
    for statement in ast.statements:
        for node_id, path in _statement_contract_workspace_file_writes(linter, statement):
            writes.setdefault(path, []).append(node_id)
    return writes


def _statement_contract_state_reads(
    linter,
    statement: ast_module.StatementDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    reads: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        reads.extend((node_id, item.path) for item in contract.reads_state)
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_state_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_state_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            reads.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_contract_state_reads(linter, step.task)
            )
    return reads


def _statement_contract_state_writes(
    linter,
    statement: ast_module.StatementDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    writes: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        writes.extend((node_id, item.path) for item in contract.writes_state)
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_state_writes(linter, slot.task)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_state_writes(linter, slot.task)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            writes.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_contract_state_writes(linter, step.task)
            )
    return writes


def _statement_workspace_file_reads(
    linter,
    statement: ast_module.StatementDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    reads: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        reads.extend(
            (node_id, linter._normalize_path(resource.path))
            for resource in contract.reads_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            reads.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_reads(linter, slot.task)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            reads.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_workspace_file_reads(linter, step.task)
            )
    return reads


def _statement_workspace_file_writes(
    linter,
    statement: ast_module.StatementDecl,
    defaults: ast_module.DefaultsDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    writes: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        writes.extend(
            (node_id, linter._normalize_path(resource.path))
            for resource in contract.writes_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    if isinstance(statement, ast_module.CodexDecl):
        for path in (statement.output_json_path, statement.output_file_path):
            if path is not None:
                writes.append((statement.id, linter._normalize_path(path)))
    if isinstance(statement, (ast_module.ApprovalDecl, ast_module.ReviewDecl, ast_module.ChoiceDecl)):
        if statement.persist_path:
            writes.append((statement.id, linter._normalize_path(statement.persist_path)))
    if isinstance(statement, ast_module.PythonDecl):
        script_writes = linter._python_script_file_writes(statement, defaults)
        for path in script_writes["paths"]:
            normalized = linter._normalize_path(path)
            if linter._is_business_artifact_path(normalized):
                writes.append((statement.id, normalized))
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_writes(linter, slot.task, defaults)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_workspace_file_writes(linter, slot.task, defaults)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            writes.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_workspace_file_writes(linter, step.task, defaults)
            )
    return writes


def _statement_contract_workspace_file_writes(
    linter,
    statement: ast_module.StatementDecl,
) -> list[tuple[str, str]]:
    node_id = getattr(statement, "id", "")
    writes: list[tuple[str, str]] = []
    contract = getattr(statement, "contract", None)
    if contract is not None and node_id:
        writes.extend(
            (node_id, linter._normalize_path(resource.path))
            for resource in contract.writes_resources
            if resource.root == "workspace" and resource.type == "file"
        )
    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_workspace_file_writes(linter, slot.task)
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            writes.extend(
                (f"{statement.id}.{slot.slot_name}", path)
                for _, path in _statement_contract_workspace_file_writes(linter, slot.task)
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            writes.extend(
                (f"{statement.id}.{step.id}", path)
                for _, path in _statement_contract_workspace_file_writes(linter, step.task)
            )
    return writes


def _workflow_reachability(ast: ast_module.WorkflowAst) -> dict[str, set[str]] | None:
    node_ids = _top_level_node_ids(ast)
    flow_aliases = {
        statement.name: statement.nodes[0]
        for statement in ast.statements
        if isinstance(statement, ast_module.FlowDecl) and statement.name is not None and statement.nodes
    }
    edges: dict[str, set[str]] = {}
    saw_flow = False
    for statement in ast.statements:
        if isinstance(statement, ast_module.FlowDecl):
            saw_flow = True
            for left, right in zip(statement.nodes, statement.nodes[1:]):
                if left in node_ids and right in node_ids:
                    edges.setdefault(left, set()).add(right)
        elif isinstance(statement, ast_module.EdgeDecl):
            saw_flow = True
            edges.setdefault(statement.from_node, set()).add(statement.to_node)
        elif isinstance(statement, ast_module.RouteDecl):
            saw_flow = True
            for target in statement.branches.values():
                resolved = flow_aliases.get(target, target)
                if resolved in node_ids:
                    edges.setdefault(statement.from_node, set()).add(resolved)
        elif isinstance(statement, ast_module.SwitchRouteDecl):
            saw_flow = True
            for target in statement.branches.values():
                resolved = flow_aliases.get(target, target)
                if resolved in node_ids:
                    edges.setdefault(statement.id, set()).add(resolved)
    if not saw_flow:
        return None

    reachability: dict[str, set[str]] = {node_id: set() for node_id in node_ids}
    for node_id in node_ids:
        stack = list(edges.get(node_id, set()))
        while stack:
            next_node = stack.pop()
            if next_node in reachability[node_id]:
                continue
            reachability[node_id].add(next_node)
            stack.extend(edges.get(next_node, set()))
    return reachability


def _top_level_node_ids(ast: ast_module.WorkflowAst) -> set[str]:
    return {
        statement.id
        for statement in ast.statements
        if isinstance(
            statement,
            (
                ast_module.PythonDecl,
                ast_module.ToolDecl,
                ast_module.CodexDecl,
                ast_module.ApprovalDecl,
                ast_module.ReviewDecl,
                ast_module.ChoiceDecl,
                ast_module.HandoffDecl,
                ast_module.HandoffFilesDecl,
                ast_module.RunWorkflowDecl,
                ast_module.WorkflowRefDecl,
                ast_module.ReactDecl,
                ast_module.AgentLoopDecl,
                ast_module.ParallelDecl,
                ast_module.SwitchRouteDecl,
            ),
        )
    }


def _is_upstream_node(
    writer: str,
    reader: str,
    reachability: dict[str, set[str]] | None,
) -> bool:
    return _is_directional_node_pair(writer, reader, reachability)


def _is_downstream_node(
    writer: str,
    reader: str,
    reachability: dict[str, set[str]] | None,
) -> bool:
    return _is_directional_node_pair(writer, reader, reachability)


def _is_directional_node_pair(
    source: str,
    target: str,
    reachability: dict[str, set[str]] | None,
) -> bool:
    if source == target:
        return False
    if reachability is None:
        return True
    source_root = source.split(".", 1)[0]
    target_root = target.split(".", 1)[0]
    if source_root == target_root:
        return True
    return target_root in reachability.get(source_root, set())


def _is_external_contract_workspace_input(path: str, boundary_inputs: set[str]) -> bool:
    if path in boundary_inputs or path.startswith("data/"):
        return True
    return not (path.startswith(".lgwf/") or path.startswith("reports/"))


