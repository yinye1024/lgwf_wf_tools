"""Focused authoring linter rule modules."""
