import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def lint_foreach_contracts(linter, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        if not isinstance(statement, ast_module.ForeachDecl):
            continue
        diagnostics.extend(_lint_foreach_boundary_contract(statement))
        diagnostics.extend(_lint_foreach_body_contract(linter, statement))
        diagnostics.extend(_lint_foreach_results_consumed(linter, ast, statement))
    return diagnostics


def _lint_foreach_boundary_contract(statement: ast_module.ForeachDecl) -> list[diagnostics_module.Diagnostic]:
    contract = statement.contract
    if contract is None:
        return []
    state_reads = {item.path for item in contract.reads_state}
    state_writes = {item.path for item in contract.writes_state}
    missing: list[str] = []
    if statement.items_path.path not in state_reads:
        missing.append(f"READ state.{statement.items_path.path}")
    if statement.results_path.path not in state_writes:
        missing.append(f"WRITE state.{statement.results_path.path}")
    if not missing:
        return []
    return [
        diagnostics_module.Diagnostic(
            f"FOREACH {statement.id} boundary CONTRACT is incomplete: {', '.join(missing)}.",
            statement.location,
            severity="error",
            code="LGWF_CONTRACT_FOREACH_BOUNDARY_MISSING",
            suggestion=(
                "Declare the foreach wrapper boundary only: READ the ITEMS state path "
                "and WRITE the RESULTS state path."
            ),
        )
    ]


def _lint_foreach_body_contract(linter, statement: ast_module.ForeachDecl) -> list[diagnostics_module.Diagnostic]:
    body = statement.body
    if body is None:
        return []
    contract = body.contract
    state_reads = {item.path for item in contract.reads_state} if contract is not None else set()
    state_writes = {item.path for item in contract.writes_state} if contract is not None else set()
    resource_reads = _contract_workspace_resource_reads(linter, contract)
    resource_writes = _contract_workspace_resource_writes(linter, contract)

    missing: list[str] = []
    if statement.current_path.path not in state_reads:
        missing.append(f"READ state.{statement.current_path.path}")
    if statement.index_path.path not in state_reads:
        missing.append(f"READ state.{statement.index_path.path}")
    if statement.output_path.path not in state_writes:
        missing.append(f"WRITE state.{statement.output_path.path}")

    if isinstance(body, ast_module.ForeachRunWorkflowBodyDecl):
        workflow_key = ("workspace", "file", linter._normalize_path(body.workflow_path))
        if workflow_key not in resource_reads:
            missing.append(f'READ workspace file "{linter._normalize_path(body.workflow_path)}"')
        work_dir_key = ("workspace", "dir", linter._normalize_path(body.work_dir))
        if work_dir_key not in resource_writes:
            missing.append(f'WRITE workspace dir "{linter._normalize_path(body.work_dir)}"')

    if not missing:
        return []
    return [
        diagnostics_module.Diagnostic(
            f"FOREACH {statement.id} body CONTRACT is incomplete: {', '.join(missing)}.",
            getattr(body, "location", None) or statement.location,
            severity="error",
            code="LGWF_CONTRACT_FOREACH_BODY_MISSING",
            suggestion=(
                "Declare the per-item body boundary: READ CURRENT and INDEX, WRITE OUTPUT, "
                "and for RUN_WORKFLOW also READ the child workflow file and WRITE the declared WORK_DIR."
            ),
        )
    ]


def _lint_foreach_results_consumed(
    linter,
    ast: ast_module.WorkflowAst,
    statement: ast_module.ForeachDecl,
) -> list[diagnostics_module.Diagnostic]:
    if not _has_successor(ast, statement.id):
        return []
    readers = [
        node_id
        for node_id in linter._state_reads_by_path(ast).get(statement.results_path.path, [])
        if node_id != statement.id
    ]
    if readers:
        return []
    return [
        diagnostics_module.Diagnostic(
            f"FOREACH {statement.id} RESULTS state.{statement.results_path.path} is not consumed by a later node.",
            statement.location,
            severity="info",
            code="LGWF_FOREACH_RESULTS_UNCONSUMED",
            suggestion=(
                "Add a downstream CONTRACT READ or INPUT that consumes the foreach RESULTS path, "
                "or remove downstream work that does not use the iteration result."
            ),
        )
    ]


def _has_successor(ast: ast_module.WorkflowAst, node_id: str) -> bool:
    flow_aliases = {
        statement.name: statement.nodes[0]
        for statement in ast.statements
        if isinstance(statement, ast_module.FlowDecl) and statement.name is not None and statement.nodes
    }
    for statement in ast.statements:
        if isinstance(statement, ast_module.FlowDecl):
            if any(left == node_id for left, _right in zip(statement.nodes, statement.nodes[1:])):
                return True
        elif isinstance(statement, ast_module.EdgeDecl):
            if statement.from_node == node_id:
                return True
        elif isinstance(statement, ast_module.RouteDecl):
            if statement.from_node == node_id:
                return any(flow_aliases.get(target, target) != "FAIL_ALL" for target in statement.branches.values())
        elif isinstance(statement, ast_module.SwitchRouteDecl):
            if statement.id == node_id:
                return any(flow_aliases.get(target, target) != "FAIL_ALL" for target in statement.branches.values())
    return False


def _contract_workspace_resource_reads(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[tuple[str, str, str]]:
    if contract is None:
        return set()
    return {
        (resource.root, resource.type, linter._normalize_path(resource.path))
        for resource in contract.reads_resources
        if resource.root == "workspace" and resource.type in {"file", "dir"}
    }


def _contract_workspace_resource_writes(
    linter,
    contract: ast_module.ContractDecl | None,
) -> set[tuple[str, str, str]]:
    if contract is None:
        return set()
    return {
        (resource.root, resource.type, linter._normalize_path(resource.path))
        for resource in contract.writes_resources
        if resource.root == "workspace" and resource.type in {"file", "dir"}
    }
