import ast as python_ast
import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.linter_rules.contracts as contract_rules_module
import lgwf_dsl.linter_rules.data_flow as data_flow_rules_module
import lgwf_dsl.linter_rules.foreach as foreach_rules_module
import lgwf_dsl.linter_rules.resources as resource_rules_module
import lgwf_dsl.linter_rules.run_workflow as run_workflow_rules_module
import lgwf_dsl.linter_rules.review as review_rules_module
import lgwf_dsl.linter_rules.react as react_rules_module
import lgwf_dsl.diagnostics as diagnostics_module


class WorkflowLinter:
    """Authoring-time checks for workflow contracts that are legal but risky."""

    def __init__(
        self,
        package_root: str | pathlib.Path | None = None,
        *,
        require_contracts: bool = True,
    ) -> None:
        self.package_root = pathlib.Path(package_root).resolve() if package_root is not None else None
        self.require_contracts = require_contracts
        self._visited_workflows: set[pathlib.Path] = set()

    def lint(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        previous_source_dir = getattr(self, "_current_source_dir", None)
        self._current_source_dir = self._source_dir_for_ast(ast)
        source_path = pathlib.Path(ast.source_name).expanduser().resolve() if ast.source_name is not None else None
        if source_path is not None and source_path in self._visited_workflows:
            return []
        if source_path is not None:
            self._visited_workflows.add(source_path)
        try:
            context_sets = self._context_sets(ast)
            defaults = self._defaults(ast)
            diagnostics: list[diagnostics_module.Diagnostic] = []
            diagnostics.extend(self._lint_entry_kind(ast))
            diagnostics.extend(resource_rules_module.lint_authoring_resources(self, ast, context_sets))
            for statement in ast.statements:
                if isinstance(statement, ast_module.ReactDecl):
                    diagnostics.extend(react_rules_module.lint_react_observe_scope(self, statement, context_sets))
                    diagnostics.extend(react_rules_module.lint_react_observe_feedback_loop(self, statement, context_sets))
                    diagnostics.extend(react_rules_module.lint_react_reason_consumes_feedback(self, statement, context_sets))
                    diagnostics.extend(react_rules_module.lint_repeated_react_inline_contexts(self, statement))
                elif isinstance(statement, ast_module.ParallelDecl):
                    diagnostics.extend(react_rules_module.lint_parallel_contexts(self, statement, context_sets))
            diagnostics.extend(self._lint_approval_routes(ast))
            diagnostics.extend(review_rules_module.lint_review_contracts(self, ast))
            diagnostics.extend(review_rules_module.lint_review_control_plane_data_use(self, ast, defaults))
            diagnostics.extend(review_rules_module.lint_human_control_plane_data_use(self, ast, defaults))
            diagnostics.extend(contract_rules_module.lint_required_contracts(self, ast))
            diagnostics.extend(contract_rules_module.lint_python_contracts(self, ast, defaults))
            diagnostics.extend(contract_rules_module.lint_codex_prompt_contracts(self, ast, defaults))
            diagnostics.extend(contract_rules_module.lint_context_contract_reads(self, ast, context_sets))
            diagnostics.extend(contract_rules_module.lint_run_workflow_boundary_contracts(self, ast))
            diagnostics.extend(foreach_rules_module.lint_foreach_contracts(self, ast))
            diagnostics.extend(contract_rules_module.lint_runtime_output_contract_consistency(self, ast))
            diagnostics.extend(data_flow_rules_module.lint_node_data_flow(self, ast, defaults))
            diagnostics.extend(run_workflow_rules_module.lint_run_workflow_handoffs(self, ast, defaults))
            return diagnostics
        finally:
            self._current_source_dir = previous_source_dir

    def _lint_entry_kind(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        if ast.entry_kind is not None:
            return []
        if not any(isinstance(statement, ast_module.FlowDecl) and statement.name is not None for statement in ast.statements):
            return []
        return [
            diagnostics_module.Diagnostic(
                f"ENTRY {ast.entry_point} is untyped; use ENTRY NODE {ast.entry_point} or ENTRY FLOW <flow_name>.",
                ast.location,
                code="LGWF_ENTRY_UNTYPED",
                suggestion="Use ENTRY NODE for a concrete runtime node, or ENTRY FLOW for a named authoring flow.",
            )
        ]

    def _defaults(self, ast: ast_module.WorkflowAst) -> ast_module.DefaultsDecl:
        defaults = ast_module.DefaultsDecl()
        for statement in ast.statements:
            if isinstance(statement, ast_module.DefaultsDecl):
                defaults = statement
        return defaults

    def _resolve_relative(self, base_dir: pathlib.Path, raw_path: str) -> pathlib.Path | None:
        path = pathlib.Path(raw_path)
        if path.is_absolute() or ".." in path.parts:
            return None
        resolved = (base_dir / path).resolve()
        if self.package_root is not None and not resolved.is_relative_to(self.package_root):
            return None
        return resolved

    def _source_dir(self) -> pathlib.Path | None:
        return getattr(self, "_current_source_dir", None)

    def _source_dir_for_ast(self, ast: ast_module.WorkflowAst) -> pathlib.Path | None:
        if self.package_root is None:
            return None
        if ast.source_name is not None:
            return pathlib.Path(ast.source_name).expanduser().resolve().parent
        return self.package_root

    def _lint_approval_routes(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        approval_locations = {
            statement.id: statement.location
            for statement in ast.statements
            if isinstance(statement, ast_module.ApprovalDecl) and statement.route_on_decision
        }
        if not approval_locations:
            return []
        diagnostics: list[diagnostics_module.Diagnostic] = []
        allowed = {"approve", "reject"}
        for statement in ast.statements:
            if not isinstance(statement, ast_module.RouteDecl):
                continue
            if statement.from_node not in approval_locations:
                continue
            invalid = sorted(key for key in statement.branches if key not in allowed)
            if not invalid:
                continue
            node_id = statement.from_node
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"APPROVAL {node_id} uses non-binary route keys: {', '.join(invalid)}. APPROVAL route keys must be approve/reject only.",
                    statement.location or approval_locations[node_id],
                    severity="error",
                    code="LGWF_APPROVAL_NON_BINARY_ROUTE",
                    suggestion=(
                        "Use fixed-option REVIEW for approve/revise/reject flows, "
                        "or keep APPROVAL routes limited to approve/reject and move business branching into a downstream node."
                    ),
                )
            )
        return diagnostics

    def _python_script_file_reads(
        self,
        python: ast_module.PythonDecl,
        defaults: ast_module.DefaultsDecl,
    ) -> dict[str, object]:
        script_path = self._resolve_python_script_path(python.script_path, defaults)
        if script_path is None or not script_path.is_file():
            return {"paths": set(), "unknown": False}
        try:
            content = script_path.read_text(encoding="utf-8")
            tree = python_ast.parse(content)
        except (UnicodeDecodeError, SyntaxError):
            return {"paths": set(), "unknown": False}

        paths: set[str] = set()
        unknown = False
        for node in python_ast.walk(tree):
            if not isinstance(node, python_ast.Call):
                continue
            path = self._read_path_from_call(node)
            if path is None:
                if self._is_file_read_call(node):
                    unknown = True
                continue
            paths.add(path)
        return {"paths": paths, "unknown": unknown}

    def _python_script_file_writes(
        self,
        python: ast_module.PythonDecl,
        defaults: ast_module.DefaultsDecl,
    ) -> dict[str, object]:
        script_path = self._resolve_python_script_path(python.script_path, defaults)
        if script_path is None or not script_path.is_file():
            return {"paths": set(), "unknown": False}
        try:
            content = script_path.read_text(encoding="utf-8")
            tree = python_ast.parse(content)
        except (UnicodeDecodeError, SyntaxError):
            return {"paths": set(), "unknown": False}

        paths: set[str] = set()
        unknown = False
        for node in python_ast.walk(tree):
            if not isinstance(node, python_ast.Call):
                continue
            path = self._write_path_from_call(node)
            if path is None:
                if self._is_file_write_call(node):
                    unknown = True
                continue
            paths.add(path)
        return {"paths": paths, "unknown": unknown}

    def _read_path_from_call(self, node: python_ast.Call) -> str | None:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"read_text", "read_bytes"}:
            return self._literal_path_expr(node.func.value)
        if self._call_name(node.func) == "open" and self._open_call_reads(node):
            return self._literal_path_expr(node.args[0]) if node.args else None
        if self._call_name(node.func) in {"load_json", "read_json"} and node.args:
            return self._literal_path_expr(node.args[0])
        return None

    def _is_file_read_call(self, node: python_ast.Call) -> bool:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"read_text", "read_bytes"}:
            return True
        if self._call_name(node.func) == "open":
            return self._open_call_reads(node)
        return self._call_name(node.func) in {"load_json", "read_json"}

    def _write_path_from_call(self, node: python_ast.Call) -> str | None:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"write_text", "write_bytes"}:
            return self._literal_path_expr(node.func.value)
        if self._call_name(node.func) == "open" and self._open_call_writes(node):
            return self._literal_path_expr(node.args[0]) if node.args else None
        if self._call_name(node.func) == "write_json" and node.args:
            return self._literal_path_expr(node.args[0])
        return None

    def _is_file_write_call(self, node: python_ast.Call) -> bool:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"write_text", "write_bytes"}:
            return True
        if self._call_name(node.func) == "open":
            return self._open_call_writes(node)
        return self._call_name(node.func) == "write_json"

    def _literal_path_expr(self, node: python_ast.AST) -> str | None:
        if isinstance(node, python_ast.Constant) and isinstance(node.value, str):
            return self._normalize_path(node.value)
        if isinstance(node, python_ast.Call) and self._call_name(node.func) in {"Path", "pathlib.Path"} and node.args:
            return self._literal_path_expr(node.args[0])
        if isinstance(node, python_ast.BinOp) and isinstance(node.op, python_ast.Div):
            left = node.left
            right = node.right
            right_path = self._literal_path_expr(right)
            if right_path is None:
                return None
            left_path = self._literal_path_expr(left)
            if left_path is not None:
                return self._normalize_path(f"{left_path}/{right_path}")
            if isinstance(left, python_ast.Name) and left.id == "lgwf_dir":
                return self._normalize_path(f".lgwf/{right_path}")
            if isinstance(left, python_ast.Name) or isinstance(left, python_ast.Call):
                return right_path
        return None

    def _open_call_reads(self, node: python_ast.Call) -> bool:
        mode = None
        if len(node.args) >= 2 and isinstance(node.args[1], python_ast.Constant) and isinstance(node.args[1].value, str):
            mode = node.args[1].value
        for keyword in node.keywords:
            if keyword.arg == "mode" and isinstance(keyword.value, python_ast.Constant) and isinstance(keyword.value.value, str):
                mode = keyword.value.value
        if mode is None:
            return True
        return isinstance(mode, str) and "r" in mode and not any(flag in mode for flag in ("w", "a", "x"))

    def _open_call_writes(self, node: python_ast.Call) -> bool:
        mode = None
        if len(node.args) >= 2 and isinstance(node.args[1], python_ast.Constant) and isinstance(node.args[1].value, str):
            mode = node.args[1].value
        for keyword in node.keywords:
            if keyword.arg == "mode" and isinstance(keyword.value, python_ast.Constant) and isinstance(keyword.value.value, str):
                mode = keyword.value.value
        return isinstance(mode, str) and any(flag in mode for flag in ("w", "a", "x"))

    def _call_name(self, node: python_ast.AST) -> str | None:
        if isinstance(node, python_ast.Name):
            return node.id
        if isinstance(node, python_ast.Attribute):
            parent = self._call_name(node.value)
            return f"{parent}.{node.attr}" if parent else node.attr
        return None

    def _contract_read_resource_paths(self, contract: ast_module.ContractDecl) -> set[str]:
        return {
            self._normalize_path(resource.path)
            for resource in contract.reads_resources
            if resource.type in {"file", "dir"}
        }

    def _contract_read_workspace_file_paths(self, contract: ast_module.ContractDecl) -> set[str]:
        return {
            self._normalize_path(resource.path)
            for resource in contract.reads_resources
            if resource.root == "workspace" and resource.type == "file"
        }

    def _contract_write_resource_paths(self, contract: ast_module.ContractDecl) -> set[str]:
        return {
            self._normalize_path(resource.path)
            for resource in contract.writes_resources
            if resource.type in {"file", "dir"}
        }

    def _is_business_artifact_path(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        return normalized.startswith(".lgwf/") or normalized.startswith("reports/") or normalized.startswith("data/")

    def _is_business_artifact_read_path(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        if normalized.startswith(".lgwf/child-runs/"):
            return False
        return self._is_business_artifact_path(normalized)

    def _state_reads_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        reads: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_reads(statement):
                reads.setdefault(path, []).append(node_id)
        return reads

    def _state_writes_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        writes: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_writes(statement):
                writes.setdefault(path, []).append(node_id)
        return writes

    def _statement_state_reads(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        statement_id = getattr(statement, "id", "")
        contract_reads = self._contract_state_reads(statement, statement_id)
        if isinstance(statement, ast_module.PythonDecl):
            reads = [(statement.id, statement.input_path.path)] if statement.input_path is not None else []
            return reads + contract_reads
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.input_path.path)] + contract_reads
        if isinstance(statement, ast_module.ForeachDecl):
            return [(statement.id, statement.items_path.path)] + contract_reads
        if isinstance(statement, ast_module.ApprovalDecl):
            return [(statement.id, statement.read_path.path)] + contract_reads
        if isinstance(statement, ast_module.ReviewDecl):
            return [(statement.id, statement.context_path.path)] + contract_reads
        if isinstance(statement, ast_module.ChoiceDecl):
            return [(statement.id, "input")] + contract_reads
        if isinstance(statement, ast_module.SwitchRouteDecl):
            return [(statement.id, statement.read_path.path)] + contract_reads
        if isinstance(statement, ast_module.HandoffDecl):
            return [(statement.id, statement.context_path.path)] + contract_reads
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.source_path.path)] + contract_reads
        if isinstance(statement, ast_module.CodexDecl):
            reads = []
            if statement.target_dirs_path is not None:
                reads.append((statement.id, statement.target_dirs_path.path))
            if statement.target_files_path is not None:
                reads.append((statement.id, statement.target_files_path.path))
            if statement.edit_dirs_path is not None:
                reads.append((statement.id, statement.edit_dirs_path.path))
            return reads + contract_reads
        if isinstance(statement, ast_module.ReactDecl):
            return contract_reads + [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_reads(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            reads = contract_reads
            for slot in statement.slots.values():
                reads.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_reads(slot.task))
            return reads
        if isinstance(statement, ast_module.ParallelDecl):
            return contract_reads + [
                (f"{statement.id}.{step.id}", path)
                for step in statement.steps
                for _, path in self._statement_state_reads(step.task)
            ]
        return contract_reads

    def _statement_state_writes(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        statement_id = getattr(statement, "id", "")
        contract_writes = self._contract_state_writes(statement, statement_id)
        if isinstance(statement, ast_module.PythonDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            writes.extend((statement.id, item.path) for item in statement.state_update_writes)
            return writes + contract_writes
        if isinstance(statement, ast_module.ToolDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.CodexDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.ApprovalDecl):
            writes = [(statement.id, statement.write_path.path)]
            if statement.result_path is not None:
                writes.append((statement.id, statement.result_path.path))
            return writes + contract_writes
        if isinstance(statement, ast_module.ReviewDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.HandoffDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.result_path.path)] + contract_writes
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.result_path.path)] + contract_writes
        if isinstance(statement, ast_module.ForeachDecl):
            return [
                (statement.id, statement.current_path.path),
                (statement.id, statement.index_path.path),
                (statement.id, statement.output_path.path),
                (statement.id, statement.results_path.path),
            ] + contract_writes
        if isinstance(statement, ast_module.WorkflowRefDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.ReactDecl):
            return contract_writes + [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_writes(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            writes = contract_writes
            if statement.status_path is not None:
                writes.append((statement.id, statement.status_path.path))
            if statement.report_path is not None:
                writes.append((statement.id, statement.report_path.path))
            for slot in statement.slots.values():
                writes.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_writes(slot.task))
            return writes
        if isinstance(statement, ast_module.ParallelDecl):
            writes = contract_writes
            for step in statement.steps:
                writes.append((f"{statement.id}.{step.id}", step.output_path.path))
                writes.append((f"{statement.id}.{step.id}", step.result_path.path))
                writes.extend((f"{statement.id}.{step.id}", path) for _, path in self._statement_state_writes(step.task))
            return writes
        return contract_writes

    def _contract_state_reads(
        self,
        statement: ast_module.StatementDecl,
        node_id: str,
    ) -> list[tuple[str, str]]:
        contract = getattr(statement, "contract", None)
        if contract is None or not node_id:
            return []
        return [(node_id, item.path) for item in contract.reads_state]

    def _contract_state_writes(
        self,
        statement: ast_module.StatementDecl,
        node_id: str,
    ) -> list[tuple[str, str]]:
        contract = getattr(statement, "contract", None)
        if contract is None or not node_id:
            return []
        return [(node_id, item.path) for item in contract.writes_state]

    def _python_decls(self, statement: ast_module.StatementDecl) -> list[ast_module.PythonDecl]:
        if isinstance(statement, ast_module.PythonDecl):
            return [statement]
        if isinstance(statement, ast_module.ReactDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.ParallelDecl):
            return [
                step.task
                for step in statement.steps
                if isinstance(step.task, ast_module.PythonDecl)
            ]
        return []

    def _codex_decls(self, statement: ast_module.StatementDecl) -> list[ast_module.CodexDecl]:
        if isinstance(statement, ast_module.CodexDecl):
            return [statement]
        if isinstance(statement, ast_module.ReactDecl):
            return [
                codex
                for slot in statement.slots.values()
                for codex in self._codex_decls(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            return [
                codex
                for slot in statement.slots.values()
                for codex in self._codex_decls(slot.task)
            ]
        if isinstance(statement, ast_module.ParallelDecl):
            return [
                codex
                for step in statement.steps
                for codex in self._codex_decls(step.task)
            ]
        return []

    def _resolve_python_script_path(
        self,
        raw_path: str,
        defaults: ast_module.DefaultsDecl,
    ) -> pathlib.Path | None:
        root = defaults.ref_root.get("root", "workflow")
        if root != "workflow":
            return None
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        ref_root_path = defaults.ref_root.get("path", ".")
        resolved_base = self._resolve_relative(base_dir, ref_root_path)
        if resolved_base is None:
            return None
        return self._resolve_relative(resolved_base, raw_path)

    def _is_external_initial_input(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        return normalized in {"input", "target", "pipeline.target"}

    def _resource_diagnostic(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
        suggestion: str,
    ) -> diagnostics_module.Diagnostic:
        return diagnostics_module.Diagnostic(
            f"{label} resource not found or invalid: {raw_path}",
            location,
            severity="error",
            code="LGWF_RESOURCE_MISSING",
            suggestion=suggestion,
        )

    def _context_sets(self, ast: ast_module.WorkflowAst) -> dict[str, ast_module.ContextSetDecl]:
        return {
            statement.name: statement
            for statement in ast.statements
            if isinstance(statement, ast_module.ContextSetDecl)
        }

    def _context_set_resources(
        self,
        name: str,
        context_sets: dict[str, ast_module.ContextSetDecl],
        stack: tuple[str, ...] = (),
    ) -> list[ast_module.ResourceRef]:
        if name not in context_sets or name in stack:
            return []
        context_set = context_sets[name]
        resources: list[ast_module.ResourceRef] = []
        for parent in context_set.extends:
            resources.extend(self._context_set_resources(parent, context_sets, (*stack, name)))
        resources.extend(context_set.resources)
        return resources

    def _normalize_path(self, path: str) -> str:
        return path.replace("\\", "/")
