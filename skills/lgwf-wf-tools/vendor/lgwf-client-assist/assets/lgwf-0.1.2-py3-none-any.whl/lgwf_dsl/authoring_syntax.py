import json
from pathlib import Path
from typing import Any


AuthoringSyntax = dict[str, Any]

SYNTAX_PATH = Path(__file__).with_name("authoring_syntax.json")
REACT_SLOT_TYPES = ["CODEX", "PY", "TOOL", "WORKFLOW"]


class AuthoringSyntaxLoadError(ValueError):
    """Raised when the authoring syntax spec cannot be loaded."""


class AuthoringSyntaxValidationError(ValueError):
    """Raised when the authoring syntax spec document is invalid."""


def load_authoring_syntax(path: Path = SYNTAX_PATH) -> AuthoringSyntax:
    try:
        content = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise AuthoringSyntaxLoadError(f"Authoring syntax spec file not found: {path}") from exc
    except OSError as exc:
        raise AuthoringSyntaxLoadError(f"Failed to read authoring syntax spec file: {path}") from exc

    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise AuthoringSyntaxLoadError(f"Authoring syntax spec file is not valid JSON: {path}") from exc

    if not isinstance(data, dict):
        raise AuthoringSyntaxLoadError(f"Authoring syntax spec root must be a JSON object: {path}")

    validate_authoring_syntax(data)
    return data


def validate_authoring_syntax(spec: AuthoringSyntax) -> None:
    version = spec.get("version")
    if not isinstance(version, int) or version < 1:
        raise AuthoringSyntaxValidationError("Authoring syntax spec must include a positive integer version.")

    if "statements" not in spec:
        raise AuthoringSyntaxValidationError("Authoring syntax spec must include statements object.")

    for section in ("source", "lexical", "top_level", "shared_types", "constraints"):
        if section not in spec:
            raise AuthoringSyntaxValidationError(f"Authoring syntax spec must include {section} object.")

    if not isinstance(spec["source"], str) or not spec["source"]:
        raise AuthoringSyntaxValidationError("Authoring syntax spec source must be a non-empty string.")
    if not isinstance(spec["lexical"], dict):
        raise AuthoringSyntaxValidationError("Authoring syntax spec lexical must be an object.")
    if not isinstance(spec["top_level"], dict):
        raise AuthoringSyntaxValidationError("Authoring syntax spec top_level must be an object.")
    if not isinstance(spec["shared_types"], dict):
        raise AuthoringSyntaxValidationError("Authoring syntax spec shared_types must be an object.")

    statements = spec["statements"]
    if not isinstance(statements, dict) or not statements:
        raise AuthoringSyntaxValidationError("Authoring syntax spec must include statements object.")

    for name, statement in statements.items():
        if not isinstance(name, str) or not name:
            raise AuthoringSyntaxValidationError("Authoring syntax statement names must be non-empty strings.")
        if not isinstance(statement, dict):
            raise AuthoringSyntaxValidationError(f"Authoring syntax statement {name} must be an object.")
        if not isinstance(statement.get("category"), str) or not statement["category"]:
            raise AuthoringSyntaxValidationError(f"Authoring syntax statement {name} must include category.")
        fields = statement.get("fields", {})
        if not isinstance(fields, dict):
            raise AuthoringSyntaxValidationError(f"Authoring syntax statement {name} fields must be an object.")
        for field_name, field in fields.items():
            if not isinstance(field_name, str) or not field_name:
                raise AuthoringSyntaxValidationError(f"Authoring syntax statement {name} has invalid field name.")
            if not isinstance(field, dict):
                raise AuthoringSyntaxValidationError(
                    f"Authoring syntax statement {name} field {field_name} must be an object."
                )
            if not isinstance(field.get("type"), str) or not field["type"]:
                raise AuthoringSyntaxValidationError(
                    f"Authoring syntax statement {name} field {field_name} must include type."
                )

    constraints = spec["constraints"]
    if not isinstance(constraints, list) or any(not isinstance(item, str) for item in constraints):
        raise AuthoringSyntaxValidationError("Authoring syntax spec constraints must be a list of strings.")

    react = statements.get("REACT")
    if isinstance(react, dict):
        slot_types = react.get("slot_types")
        if slot_types != REACT_SLOT_TYPES:
            expected = ", ".join(REACT_SLOT_TYPES)
            raise AuthoringSyntaxValidationError(
                f"Authoring syntax REACT slot_types must be exactly: {expected}."
            )
