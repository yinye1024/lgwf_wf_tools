from typing import Any

import lgwf_dsl.ast as ast_module


def wrap_sandbox(ast: ast_module.WorkflowAst, workflow: dict[str, Any]) -> dict[str, Any]:
    sandbox = ast.sandbox
    if sandbox is None:
        return workflow
    sandbox_id = f"__sandbox__{ast.name or ast.entry_point}"
    config: dict[str, Any] = {
        "sandbox_path": sandbox.path,
        "work_dir": {
            "include": list(sandbox.work_dir.include),
            "exclude": list(sandbox.work_dir.exclude),
            "promote_include": list(sandbox.work_dir.promote_include),
        },
        "workflow": workflow,
    }
    if sandbox.target_dir is not None:
        config["target_dir"] = {
            "root": sandbox.target_dir.root,
            "path": sandbox.target_dir.path,
            "include": list(sandbox.target_dir.include),
            "exclude": list(sandbox.target_dir.exclude),
            "promote_include": list(sandbox.target_dir.promote_include),
        }
    if sandbox.result_path is not None:
        config["result_path"] = sandbox.result_path.path
    return {
        "nodes": [
            {
                "id": sandbox_id,
                "capability": "subgraph.validation_sandbox",
                "config": config,
            }
        ],
        "edges": [],
        "routes": [],
        "entry_point": sandbox_id,
    }


def validate_sandbox(validator: Any, sandbox: ast_module.SandboxDecl | None) -> None:
    if sandbox is None:
        return
    validator._validate_relative_path(sandbox.path, "SANDBOX PATH", sandbox.location)
    validator._validate_patterns(sandbox.work_dir.include, "WORK_DIR INCLUDE", sandbox.work_dir.location)
    validator._validate_patterns(sandbox.work_dir.exclude, "WORK_DIR EXCLUDE", sandbox.work_dir.location)
    validator._validate_patterns(
        sandbox.work_dir.promote_include,
        "WORK_DIR PROMOTE_INCLUDE",
        sandbox.work_dir.location,
    )
    if sandbox.target_dir is None:
        return
    if sandbox.target_dir.root != "workspace":
        validator._raise("TARGET_DIR root must be workspace.", sandbox.target_dir.location)
    validator._validate_relative_path(sandbox.target_dir.path, "TARGET_DIR path", sandbox.target_dir.location)
    validator._validate_patterns(sandbox.target_dir.include, "TARGET_DIR INCLUDE", sandbox.target_dir.location)
    validator._validate_patterns(sandbox.target_dir.exclude, "TARGET_DIR EXCLUDE", sandbox.target_dir.location)
    validator._validate_patterns(
        sandbox.target_dir.promote_include,
        "TARGET_DIR PROMOTE_INCLUDE",
        sandbox.target_dir.location,
    )
