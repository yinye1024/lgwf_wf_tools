from typing import Any

import lgwf_dsl.ast as ast_module


def lower_run_workflow(lowerer: Any, task: ast_module.RunWorkflowDecl) -> dict[str, Any]:
    lowerer._validate_external_workflow_path(task.workflow_path)
    lowerer._validate_relative_path(task.work_dir, "RUN_WORKFLOW WORK_DIR")
    config: dict[str, Any] = {
        "workflow_lgwf": task.workflow_path,
        "work_dir": task.work_dir,
        "input_path": task.input_path.path,
        "result_path": task.result_path.path,
    }
    lowerer._attach_contract(config, task.contract)
    return {
        "id": task.id,
        "capability": "flow.run_workflow",
        "config": config,
    }
