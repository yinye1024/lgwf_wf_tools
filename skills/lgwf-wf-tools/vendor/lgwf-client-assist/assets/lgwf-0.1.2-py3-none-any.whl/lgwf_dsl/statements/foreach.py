from typing import Any

import lgwf_dsl.ast as ast_module


def lower_foreach(lowerer: Any, task: ast_module.ForeachDecl) -> dict[str, Any]:
    if task.body is None:
        raise ValueError("FOREACH requires WORKFLOW or RUN_WORKFLOW body.")
    config: dict[str, Any] = {
        "items_path": task.items_path.path,
        "current_path": task.current_path.path,
        "index_path": task.index_path.path,
        "output_path": task.output_path.path,
        "results_path": task.results_path.path,
        "fail_strategy": task.fail_strategy,
        "status_path": f"foreach.{task.id}.status",
        "report_path": f"foreach.{task.id}.report",
    }
    if isinstance(task.body, ast_module.ForeachWorkflowBodyDecl):
        body = ast_module.WorkflowRefDecl(
            id=f"{task.id}__body",
            workflow_path=task.body.workflow_path,
            contract=task.body.contract,
            location=task.body.location,
        )
        config["body"] = lowerer._lower_workflow_ref(body)
    elif isinstance(task.body, ast_module.ForeachRunWorkflowBodyDecl):
        lowerer._validate_external_workflow_path(task.body.workflow_path)
        lowerer._validate_relative_path(task.body.work_dir, "FOREACH RUN_WORKFLOW WORK_DIR")
        body_config: dict[str, Any] = {
            "workflow_lgwf": task.body.workflow_path,
            "work_dir": task.body.work_dir,
            "input_path": "__foreach_current_input",
            "result_path": "__foreach_child_result",
        }
        lowerer._attach_contract(body_config, task.body.contract)
        config["body"] = {
            "id": f"{task.id}__body",
            "capability": "flow.run_workflow",
            "config": body_config,
        }
    lowerer._attach_contract(config, task.contract)
    return {
        "id": task.id,
        "capability": "subgraph.foreach",
        "config": config,
    }
