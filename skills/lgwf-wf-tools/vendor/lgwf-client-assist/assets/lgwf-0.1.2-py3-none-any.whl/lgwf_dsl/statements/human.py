"""Human-facing statement helpers reserved for approval/review/handoff splitting."""
