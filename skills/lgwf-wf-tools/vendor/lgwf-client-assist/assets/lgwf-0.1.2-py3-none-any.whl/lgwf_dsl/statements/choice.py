from typing import Any

import lgwf.control_flow as control_flow_module
import lgwf_dsl.ast as ast_module
import lgwf_dsl.errors as errors_module
import lgwf_dsl.tokens as tokens_module


def parse_choice(parser: Any) -> ast_module.ChoiceDecl:
    start = parser._expect_keyword("CHOICE")
    node_id = parser._expect_identifier("choice node id")
    prompt: str | None = None
    prompt_ref_path: str | None = None
    routes: dict[str, str] | None = None
    options: list[str] | None = None
    read_path: ast_module.StateRef | None = None
    write_path: ast_module.StateRef | None = None
    result_path: ast_module.StateRef | None = None
    option_labels: dict[str, str] = {}
    persist_path: str | None = None
    poll_interval_seconds: int | None = None
    contract: ast_module.ContractDecl | None = None
    seen: set[str] = set()

    while not parser._matches_symbol(";"):
        field = parser._peek().value.upper()
        if field not in {
            "PROMPT",
            "PROMPT_REF",
            "OPTIONS",
            "ROUTES",
            "READ",
            "WRITE",
            "RESULT",
            "OPTION",
            "PERSIST",
            "POLL",
            "CONTRACT",
        }:
            raise errors_module.DSLParseError(
                f"Unexpected CHOICE token: {parser._peek().value}",
                parser._peek().location,
            )
        if field in seen and field != "OPTION":
            raise errors_module.DSLParseError(
                f"Duplicate CHOICE field: {field}.",
                parser._peek().location,
            )
        if field != "OPTION":
            seen.add(field)
        parser._advance()
        if field == "PROMPT":
            prompt = parser._expect_string("PROMPT text")
        elif field == "PROMPT_REF":
            prompt_ref_path = parser._expect_string("PROMPT_REF path")
        elif field == "OPTIONS":
            value = parser._parse_json_value()
            if not isinstance(value, list) or not value:
                raise errors_module.DSLParseError("CHOICE OPTIONS must be a non-empty JSON string array.", start.location)
            if not all(isinstance(item, str) and item for item in value):
                raise errors_module.DSLParseError("CHOICE OPTIONS must contain non-empty strings only.", start.location)
            if len(set(value)) != len(value):
                raise errors_module.DSLParseError("CHOICE OPTIONS must not contain duplicates.", start.location)
            options = list(value)
        elif field == "ROUTES":
            if routes is not None:
                raise errors_module.DSLParseError("CHOICE cannot mix ROUTES with OPTION declarations.", parser._peek().location)
            routes = parse_inline_routes(parser, "CHOICE")
        elif field == "READ":
            read_path = parser._expect_state_ref("READ")
        elif field == "WRITE":
            write_path = parser._expect_state_ref("WRITE")
        elif field == "RESULT":
            result_path = parser._expect_state_ref("RESULT")
        elif field == "OPTION":
            if "ROUTES" in seen:
                raise errors_module.DSLParseError("CHOICE cannot mix ROUTES with OPTION declarations.", parser._peek().location)
            if routes is None:
                routes = {}
            key, label, target = parse_choice_option_after_keyword(parser)
            if key in routes:
                raise errors_module.DSLParseError(
                    f"Duplicate CHOICE route key: {key}.",
                    parser._peek().location,
                )
            routes[key] = target
            option_labels[key] = label
        elif field == "PERSIST":
            persist_path = parser._expect_string("PERSIST path")
        elif field == "POLL":
            poll_interval_seconds = parser._expect_positive_int("POLL")
        else:
            contract = parser._parse_contract_body_after_keyword()
    parser._expect_symbol(";")
    if (prompt is None) == (prompt_ref_path is None):
        raise errors_module.DSLParseError("CHOICE requires exactly one of PROMPT or PROMPT_REF.", start.location)
    if routes is None and options is None:
        raise errors_module.DSLParseError("CHOICE requires ROUTES.", start.location)
    if routes is not None and not routes:
        raise errors_module.DSLParseError("CHOICE ROUTES must not be empty.", start.location)
    if routes is None:
        routes = {}
    if options is None:
        options = list(routes.keys())
    elif routes and set(options) != set(routes.keys()):
        raise errors_module.DSLParseError("CHOICE OPTIONS must match ROUTES keys.", start.location)
    return ast_module.ChoiceDecl(
        id=node_id,
        prompt=prompt,
        prompt_ref_path=prompt_ref_path,
        routes=routes,
        options=options,
        read_path=read_path,
        write_path=write_path,
        result_path=result_path,
        option_labels=option_labels,
        persist_path=persist_path,
        poll_interval_seconds=poll_interval_seconds,
        contract=contract,
        location=start.location,
    )


def parse_inline_routes(parser: Any, label: str) -> dict[str, str]:
    parser._expect_symbol("{")
    routes: dict[str, str] = {}
    if parser._matches_symbol("}"):
        parser._advance()
        return routes
    while True:
        key = parser._expect_string(f"{label} route key")
        if key in routes:
            raise errors_module.DSLParseError(
                f"Duplicate {label} route key: {key}.",
                parser._peek().location,
            )
        parser._expect_symbol(":")
        routes[key] = parser._expect_route_target(f"{label} route target")
        if parser._matches_symbol("}"):
            parser._advance()
            return routes
        parser._expect_symbol(",")


def parse_choice_option_after_keyword(parser: Any) -> tuple[str, str, str]:
    key = expect_choice_option_key(parser)
    parser._expect_keyword("LABEL")
    label = parser._expect_string("OPTION LABEL")
    if not label.strip():
        raise errors_module.DSLParseError("OPTION LABEL must be a non-empty string.", parser._peek().location)
    parser._expect_keyword("THEN")
    target = parser._expect_route_target("OPTION route target")
    return key, label, target


def expect_choice_option_key(parser: Any) -> str:
    token = parser._peek()
    if token.kind == tokens_module.TokenKind.STRING:
        value = parser._advance().value
        if not value:
            raise errors_module.DSLParseError("OPTION key must be non-empty.", token.location)
        return value
    return parser._expect_identifier("OPTION key")


def lower_choice(lowerer: Any, task: ast_module.ChoiceDecl, defaults: ast_module.DefaultsDecl) -> dict[str, Any]:
    config = {
        "result_path": lowerer._state_path_or_default(task.result_path, defaults.result_path_template, task.id),
        "options": list(task.options),
    }
    if task.prompt is not None:
        config["prompt"] = task.prompt
    elif task.prompt_ref_path is not None:
        config["prompt_ref"] = {
            "root": "workflow",
            "path": lowerer._package_relative_path(task.prompt_ref_path, "PROMPT_REF"),
        }
    if task.read_path is not None:
        config["context_path"] = task.read_path.path
    if task.write_path is not None:
        config["choice_value_path"] = task.write_path.path
    if task.option_labels:
        config["option_labels"] = dict(task.option_labels)
    if task.persist_path is not None:
        config["persist_value_path"] = task.persist_path
    if task.poll_interval_seconds is not None:
        config["poll_interval_seconds"] = task.poll_interval_seconds
    lowerer._attach_contract(config, task.contract)
    return {
        "id": task.id,
        "capability": "flow.human_choice",
        "config": config,
    }


def validate_choice(validator: Any, statement: ast_module.ChoiceDecl, target_ids: set[str]) -> None:
    if statement.prompt_ref_path is not None:
        validator._validate_relative_path(statement.prompt_ref_path, "CHOICE PROMPT_REF path", statement.location)
    if statement.persist_path is not None:
        validator._validate_relative_path(statement.persist_path, "CHOICE PERSIST path", statement.location)
    for target in statement.routes.values():
        if control_flow_module.is_fail_all_target(target):
            continue
        validator._validate_node_ref(target, target_ids, "route target", statement.location)
