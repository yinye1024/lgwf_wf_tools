from typing import Any

import lgwf_dsl.ast as ast_module


def lower_react(
    lowerer: Any,
    react: ast_module.ReactDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> dict[str, Any]:
    config: dict[str, Any] = {"max_steps": react.max_steps}
    react_context_refs = lowerer._lower_context_refs(react.contexts, context_sets)
    lowerer._attach_contract(config, react.contract)
    if react.spec_path is not None:
        config["spec_ref"] = {
            "path": lowerer._lower_task_resource_path(react.spec_path, "SPEC", defaults),
        }
    for slot_name in ("reason", "act", "observe", "decide"):
        task = react.slots[slot_name].task
        if isinstance(task, ast_module.PythonDecl):
            lowered = lowerer._lower_python(task, defaults)
        elif isinstance(task, ast_module.ToolDecl):
            lowered = lowerer._lower_tool(task, defaults)
        elif isinstance(task, ast_module.WorkflowRefDecl):
            lowered = lowerer._lower_workflow_ref(task)
        else:
            lowered = lowerer._lower_codex(task, defaults, context_sets)
            slot_config = dict(lowered.get("config", {}))
            if react_context_refs:
                slot_context_refs = list(slot_config.get("context_refs", []))
                slot_config["context_refs"] = [*react_context_refs, *slot_context_refs]
            if isinstance(slot_config.get("session"), dict):
                session = dict(slot_config["session"])
                session["scope"] = "react_slot"
                session["parent_node_id"] = react.id
                session["slot_name"] = slot_name
                slot_config["session"] = session
            if slot_config != lowered.get("config", {}):
                lowered = {
                    "id": lowered["id"],
                    "capability": lowered["capability"],
                    "config": slot_config,
                }
        slot_data = {"capability": lowered["capability"]}
        if lowered.get("config"):
            slot_data["config"] = lowered["config"]
        config[slot_name] = slot_data
    if react.on_max_ask is not None:
        on_max = react.on_max_ask
        config["on_max"] = {
            "type": "human_approval",
            "prompt": on_max.prompt,
            "context_path": on_max.read_path.path,
            "approved_value_path": on_max.write_path.path,
            "result_path": lowerer._state_path_or_default(
                on_max.result_path,
                defaults.result_path_template,
                f"{react.id}__on_max",
            ),
            "status_path": lowerer._state_path_or_default(
                on_max.status_path,
                "react.{node}",
                react.id,
            ),
            "extra_max_steps": on_max.extra_max_steps,
            "poll_interval_seconds": on_max.poll_interval_seconds or 1,
            "timeout_seconds": lowerer._resolve_timeout_seconds(
                on_max.timeout_seconds,
                on_max.timeout_unlimited,
                defaults.timeout_seconds,
                inherit_defaults=False,
            ),
        }
    return {
        "id": react.id,
        "capability": "subgraph.react",
        "config": config,
    }


def validate_react_context_refs(
    validator: Any,
    react: ast_module.ReactDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> None:
    validator._validate_context_refs(react.contexts, context_sets)
    for slot in react.slots.values():
        if isinstance(slot.task, ast_module.CodexDecl):
            validator._validate_context_refs(slot.task.contexts, context_sets)
        elif isinstance(slot.task, ast_module.ToolDecl):
            validator._validate_tool(slot.task)
        elif isinstance(slot.task, ast_module.WorkflowRefDecl) and slot.task.result_path is None:
            validator._raise("REACT WORKFLOW requires RESULT state.*.", slot.task.location)
