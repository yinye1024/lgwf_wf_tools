﻿import pathlib
import os
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module


DEFAULT_CODEX_MODEL = "gpt-5.5"
DEFAULT_CODEX_REASONING_EFFORT = "xhigh"
DEFAULT_CODEX_SERVICE_TIER = "default"
CODEX_DEFAULTS_CONFIG_ENV = "LGWF_CODEX_DEFAULTS_CONFIG"
CONFIG_VERSION = 1
DEFAULT_ON_TOKEN_LIMIT = "warn"
ON_TOKEN_LIMIT_VALUES = {"warn", "fail"}
REASONING_EFFORT_VALUES = {"low", "medium", "high", "xhigh"}
SERVICE_TIER_VALUES = {"default", "priority"}


def get_codex_model(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    default_config = _default_model_config()
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    payload: dict[str, Any] = {
        "model": default_config["model"],
        "model_reasoning_effort": default_config["model_reasoning_effort"],
        "service_tier": default_config["service_tier"],
        "source": default_config["source"],
        "default_model": default_config["model"],
        "default_model_reasoning_effort": default_config["model_reasoning_effort"],
        "default_service_tier": default_config["service_tier"],
        "default_source": default_config["source"],
        "config_path": str(config_path),
    }
    if default_config.get("config_path") is not None:
        payload["default_config_path"] = default_config["config_path"]
    if not config_path.is_file():
        return payload

    config = _read_config(config_path)
    if "model" in config:
        payload["model"] = _normalize_model(config.get("model"))
        payload["source"] = "workspace"
    if "model_reasoning_effort" in config:
        payload["model_reasoning_effort"] = _normalize_reasoning_effort(config.get("model_reasoning_effort"))
        payload["model_reasoning_effort_source"] = "workspace"
    if "service_tier" in config:
        payload["service_tier"] = _normalize_service_tier(config.get("service_tier"))
        payload["service_tier_source"] = "workspace"
    return payload


def set_codex_model(workspace_root: str | pathlib.Path, model: str) -> dict[str, Any]:
    normalized_model = _validate_model(model)
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config["model"] = normalized_model
    _write_config(config_path, config)
    payload = get_codex_model(workspace_root)
    payload["ok"] = True
    return payload


def reset_codex_model(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config.pop("model", None)
    _write_or_remove_config(config_path, config)
    payload = get_codex_model(workspace_root)
    payload["ok"] = True
    return payload


def get_codex_token_limit(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    has_token_max = "token_max" in config
    token_max = _normalize_optional_token_max(config.get("token_max")) if has_token_max else None
    on_token_limit = _normalize_on_token_limit(config.get("on_token_limit", DEFAULT_ON_TOKEN_LIMIT))
    return {
        "token_max": token_max,
        "on_token_limit": on_token_limit,
        "source": "workspace" if has_token_max or "on_token_limit" in config else "default",
        "default_on_token_limit": DEFAULT_ON_TOKEN_LIMIT,
        "config_path": str(config_path),
    }


def set_codex_token_limit(
    workspace_root: str | pathlib.Path,
    *,
    token_max: int,
    on_token_limit: str = "fail",
) -> dict[str, Any]:
    normalized_max = _normalize_token_max(token_max)
    normalized_action = _normalize_on_token_limit(on_token_limit)
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config["token_max"] = normalized_max
    config["on_token_limit"] = normalized_action
    _write_config(config_path, config)
    payload = get_codex_token_limit(workspace_root)
    payload["ok"] = True
    return payload


def reset_codex_token_limit(workspace_root: str | pathlib.Path) -> dict[str, Any]:
    config_path = workspace_layout_module.codex_config_path(workspace_root)
    config = _read_config(config_path)
    config.pop("token_max", None)
    config.pop("on_token_limit", None)
    _write_or_remove_config(config_path, config)
    payload = get_codex_token_limit(workspace_root)
    payload["ok"] = True
    return payload


def _normalize_model(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return _default_model_config()["model"]
    return _validate_model(value)


def _validate_model(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("model must be a non-empty string.")
    model = value.strip()
    if any(char.isspace() for char in model):
        raise ValueError("model must not contain whitespace.")
    return model


def _normalize_reasoning_effort(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_REASONING_EFFORT
    if not isinstance(value, str):
        raise ValueError("model_reasoning_effort must be low, medium, high, or xhigh.")
    effort = value.strip().lower()
    if effort not in REASONING_EFFORT_VALUES:
        raise ValueError("model_reasoning_effort must be low, medium, high, or xhigh.")
    return effort


def _normalize_service_tier(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_SERVICE_TIER
    if not isinstance(value, str):
        raise ValueError("service_tier must be default or priority.")
    tier = value.strip().lower()
    if tier not in SERVICE_TIER_VALUES:
        raise ValueError("service_tier must be default or priority.")
    return tier


def _normalize_token_max(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("token_max must be a positive integer.")
    return value


def _normalize_optional_token_max(value: Any) -> int | None:
    if value is None:
        return None
    return _normalize_token_max(value)


def _normalize_on_token_limit(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("on_token_limit must be 'warn' or 'fail'.")
    action = value.strip().lower()
    if action not in ON_TOKEN_LIMIT_VALUES:
        raise ValueError("on_token_limit must be 'warn' or 'fail'.")
    return action


def _read_config(config_path: pathlib.Path) -> dict[str, Any]:
    if not config_path.is_file():
        return {}
    return file_ops_module.read_json_object(config_path, label="Codex config")


def _default_model_config() -> dict[str, Any]:
    config_path = _default_config_path()
    if config_path is None or not config_path.is_file():
        return {
            "model": DEFAULT_CODEX_MODEL,
            "model_reasoning_effort": DEFAULT_CODEX_REASONING_EFFORT,
            "service_tier": DEFAULT_CODEX_SERVICE_TIER,
            "source": "default",
            "config_path": None,
        }
    config = file_ops_module.read_json_object(config_path, label="Codex defaults config")
    return {
        "model": _normalize_default_model(config.get("model")),
        "model_reasoning_effort": _normalize_reasoning_effort(config.get("model_reasoning_effort")),
        "service_tier": _normalize_service_tier(config.get("service_tier")),
        "source": "package",
        "config_path": str(config_path),
    }


def _default_config_path() -> pathlib.Path | None:
    raw_path = os.environ.get(CODEX_DEFAULTS_CONFIG_ENV)
    if not raw_path:
        return None
    return pathlib.Path(raw_path).expanduser().resolve()


def _normalize_default_model(value: Any) -> str:
    if value is None:
        return DEFAULT_CODEX_MODEL
    return _validate_model(value)


def _write_config(config_path: pathlib.Path, config: dict[str, Any]) -> None:
    payload = {"version": CONFIG_VERSION, **{key: value for key, value in config.items() if key != "version"}}
    file_ops_module.write_json_atomic(config_path, payload)


def _write_or_remove_config(config_path: pathlib.Path, config: dict[str, Any]) -> None:
    meaningful = {key: value for key, value in config.items() if key != "version"}
    if meaningful:
        _write_config(config_path, meaningful)
    else:
        config_path.unlink(missing_ok=True)
