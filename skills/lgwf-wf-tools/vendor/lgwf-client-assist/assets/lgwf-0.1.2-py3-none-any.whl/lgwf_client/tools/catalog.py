import json
import pathlib
from typing import Any

import jsonschema


class ToolCatalogError(ValueError):
    def __init__(self, message: str, code: str) -> None:
        self.code = code
        super().__init__(message)


def load_tool_catalog() -> dict[str, Any]:
    path = pathlib.Path(__file__).with_name("catalog.json")
    catalog = json.loads(path.read_text(encoding="utf-8"))
    validate_tool_catalog(catalog)
    return catalog


def validate_tool_catalog(catalog: dict[str, Any]) -> None:
    version = catalog.get("version")
    if not isinstance(version, int) or version < 1:
        raise ToolCatalogError("tool catalog must include a positive integer version.", "LGWF_TOOL_CATALOG_INVALID")

    tools = catalog.get("tools")
    if not isinstance(tools, list) or not tools:
        raise ToolCatalogError("tool catalog must include a non-empty tools list.", "LGWF_TOOL_CATALOG_INVALID")

    seen_names: set[str] = set()
    for tool in tools:
        _validate_tool_descriptor(tool, seen_names)


def tool_descriptors() -> dict[str, dict[str, Any]]:
    catalog = load_tool_catalog()
    return {tool["name"]: tool for tool in catalog["tools"]}


def validate_public_tool_options(name: object, options: object) -> dict[str, Any]:
    if not isinstance(name, str) or not name.strip():
        raise ToolCatalogError("tool name must be a non-empty string.", "LGWF_TOOL_UNKNOWN")
    descriptor = tool_descriptors().get(name)
    if descriptor is None or not descriptor.get("public", False):
        raise ToolCatalogError(f"Unknown public tool: {name}", "LGWF_TOOL_UNKNOWN")
    if not isinstance(options, dict):
        raise ToolCatalogError("tool options must be a JSON object.", "LGWF_TOOL_OPTIONS_INVALID")
    try:
        jsonschema.validate(options, descriptor["options_schema"])
    except jsonschema.ValidationError as exc:
        path = ".".join(str(part) for part in exc.absolute_path)
        location = f"options.{path}" if path else "options"
        raise ToolCatalogError(
            f"Invalid options for tool '{name}' at {location}: {exc.message}",
            "LGWF_TOOL_OPTIONS_INVALID",
        ) from exc
    return descriptor


def _validate_tool_descriptor(tool: Any, seen_names: set[str]) -> None:
    if not isinstance(tool, dict):
        raise ToolCatalogError("tool catalog entries must be objects.", "LGWF_TOOL_CATALOG_INVALID")

    name = tool.get("name")
    if not isinstance(name, str) or not name:
        raise ToolCatalogError("tool catalog entry must include a non-empty name.", "LGWF_TOOL_CATALOG_INVALID")
    if name in seen_names:
        raise ToolCatalogError(f"duplicate tool catalog entry: {name}", "LGWF_TOOL_CATALOG_INVALID")
    seen_names.add(name)

    _require_string(tool, "description", name)
    _require_bool(tool, "public", name)
    _require_string(tool, "path_mode", name)
    _require_string(tool, "workflow_path_mode", name)
    _require_bool(tool, "mutates_files", name)
    _require_object(tool, "options_schema", name)
    _require_bool(tool, "destructive", name)
    _require_string_list(tool, "permissions", name, allow_empty=False)
    _require_object(tool, "input_schema", name)
    _require_object(tool, "output_schema", name)
    _require_string_list(tool, "error_codes", name)
    _require_idempotency(tool, name)
    _require_string_list(tool, "reads", name)
    _require_string_list(tool, "writes", name)
    _require_retry_semantics(tool, name)
    _require_timeout_expectation(tool, name)
    _require_artifact_contract(tool, name)
    _require_error_taxonomy(tool, name)
    _require_string_list(tool, "when_to_use", name, allow_empty=False)
    _require_string_list(tool, "when_not_to_use", name, allow_empty=False)

    examples = tool.get("examples")
    if not isinstance(examples, list) or not examples:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'examples' must be a non-empty list.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_string(tool: dict[str, Any], field: str, name: str) -> None:
    value = tool.get(field)
    if not isinstance(value, str) or not value:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field '{field}' must be a non-empty string.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_bool(tool: dict[str, Any], field: str, name: str) -> None:
    value = tool.get(field)
    if not isinstance(value, bool):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field '{field}' must be a boolean.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_object(tool: dict[str, Any], field: str, name: str) -> None:
    value = tool.get(field)
    if not isinstance(value, dict):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field '{field}' must be an object.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_string_list(
    tool: dict[str, Any],
    field: str,
    name: str,
    *,
    allow_empty: bool = True,
) -> None:
    value = tool.get(field)
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field '{field}' must be a list of strings.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    if not allow_empty and not value:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field '{field}' must not be empty.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_idempotency(tool: dict[str, Any], name: str) -> None:
    value = tool.get("idempotency")
    if value not in {"idempotent", "conditionally_idempotent", "non_idempotent"}:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'idempotency' must be idempotent, conditionally_idempotent, or non_idempotent.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_retry_semantics(tool: dict[str, Any], name: str) -> None:
    value = tool.get("retry_semantics")
    if not isinstance(value, dict):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'retry_semantics' must be an object.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    if not isinstance(value.get("safe"), bool):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'retry_semantics.safe' must be a boolean.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    if not isinstance(value.get("strategy"), str) or not value.get("strategy"):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'retry_semantics.strategy' must be a non-empty string.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_timeout_expectation(tool: dict[str, Any], name: str) -> None:
    value = tool.get("timeout_expectation")
    if not isinstance(value, dict):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'timeout_expectation' must be an object.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    default_seconds = value.get("default_seconds")
    if not isinstance(default_seconds, int) or default_seconds < 0:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'timeout_expectation.default_seconds' must be a non-negative integer.",
            "LGWF_TOOL_CATALOG_INVALID",
        )


def _require_artifact_contract(tool: dict[str, Any], name: str) -> None:
    value = tool.get("artifact_contract")
    if not isinstance(value, dict):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'artifact_contract' must be an object.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    for field in ("produces", "consumes"):
        items = value.get(field)
        if not isinstance(items, list) or any(not isinstance(item, str) for item in items):
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'artifact_contract.{field}' must be a list of strings.",
                "LGWF_TOOL_CATALOG_INVALID",
            )


def _require_error_taxonomy(tool: dict[str, Any], name: str) -> None:
    taxonomy = tool.get("error_taxonomy")
    if not isinstance(taxonomy, list) or not taxonomy:
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'error_taxonomy' must be a non-empty list.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
    taxonomy_codes: set[str] = set()
    for item in taxonomy:
        if not isinstance(item, dict):
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'error_taxonomy' entries must be objects.",
                "LGWF_TOOL_CATALOG_INVALID",
            )
        code = item.get("code")
        category = item.get("category")
        retryable = item.get("retryable")
        description = item.get("description")
        if not isinstance(code, str) or not code:
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'error_taxonomy.code' must be a non-empty string.",
                "LGWF_TOOL_CATALOG_INVALID",
            )
        if not isinstance(category, str) or not category:
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'error_taxonomy.category' must be a non-empty string.",
                "LGWF_TOOL_CATALOG_INVALID",
            )
        if not isinstance(retryable, bool):
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'error_taxonomy.retryable' must be a boolean.",
                "LGWF_TOOL_CATALOG_INVALID",
            )
        if not isinstance(description, str) or not description:
            raise ToolCatalogError(
                f"tool catalog entry '{name}' field 'error_taxonomy.description' must be a non-empty string.",
                "LGWF_TOOL_CATALOG_INVALID",
            )
        taxonomy_codes.add(code)
    if taxonomy_codes != set(tool.get("error_codes", [])):
        raise ToolCatalogError(
            f"tool catalog entry '{name}' field 'error_taxonomy' must cover exactly error_codes.",
            "LGWF_TOOL_CATALOG_INVALID",
        )
