﻿import argparse
import json
import pathlib
import sys
from collections.abc import Callable
from typing import Any, TextIO

import lgwf.client_provider as client_provider_module
import lgwf.checkpoints as checkpoints_module
import lgwf.human_gate_policy as human_gate_policy_module
import lgwf.resume as resume_module
import lgwf_client.json_io as json_io_module
import lgwf.runs.records as run_records_module
import lgwf.runtime as runtime_module
import lgwf_client.timing as timing_module
import lgwf_client.client_factory as client_factory_module
import lgwf_client.commands as command_modules


WorkflowRunner = Callable[
    [dict[str, Any], dict[str, Any], pathlib.Path, pathlib.Path, bool],
    dict[str, Any],
]


def main(
    argv: list[str] | None = None,
    runner: WorkflowRunner | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    output = stdout or sys.stdout
    error_output = stderr or sys.stderr
    effective_argv = argv if argv is not None else sys.argv[1:]
    if effective_argv and effective_argv[0] in _command_names():
        return _run_command(effective_argv, output, error_output)

    parser = _build_parser()
    args = parser.parse_args(argv)

    timer = timing_module.Timer.start()
    run_id = run_records_module.new_run_id()
    try:
        load_timer = timing_module.Timer.start()
        workflow_json = _resolve_workflow_json(args.workflow_json)
        work_dir = _resolve_work_dir(args.work_dir)
        input_state = _parse_input_json_arg(args)
        record = _parse_record(args.record)
        human_gate_policy = human_gate_policy_module.auto_approve_policy() if args.auto_human else None
        workflow = _load_workflow(workflow_json)
        resume_checkpoint = checkpoints_module.load_checkpoint(work_dir, args.resume_run_id) if args.resume_run_id else None
        resume_plan = None
        if resume_checkpoint is not None:
            resume_plan = resume_module.build_resume_plan(
                workflow,
                resume_checkpoint,
                work_dir=work_dir,
                allow_workflow_changed=args.resume_allow_workflow_changed,
                orphaned_running=args.resume_orphaned_running,
            )
            if not resume_plan.can_resume:
                _write_resume_start_failed(error_output, resume_checkpoint, resume_plan.reason or "checkpoint cannot be resumed.")
                return 2
            _write_resume_start(error_output, resume_checkpoint, resume_plan)
        effective_run_id = args.resume_run_id or run_id
        error_output.write(f"[workflow] startup step=load_workflow duration_ms={load_timer.elapsed_ms()} run_id={run_id}\n")

        error_output.write(f"[workflow] started workflow_json={workflow_json} work_dir={work_dir} run_id={run_id}\n")
        if runner is None:
            final_state = run_local_workflow(
                workflow,
                input_state,
                workflow_json.parent,
                work_dir,
                record,
                progress_writer=_stderr_progress_writer(error_output),
                run_id=effective_run_id,
                resume_checkpoint=resume_checkpoint,
                resume_allow_workflow_changed=args.resume_allow_workflow_changed,
                resume_orphaned_running=args.resume_orphaned_running,
                human_gate_policy=human_gate_policy,
            )
        elif resume_checkpoint is not None:
            resume_kwargs = {
                "resume_checkpoint": resume_checkpoint,
                "resume_allow_workflow_changed": args.resume_allow_workflow_changed,
                "run_id": args.resume_run_id,
            }
            if args.resume_orphaned_running:
                resume_kwargs["resume_orphaned_running"] = True
            if human_gate_policy is not None:
                resume_kwargs["human_gate_policy"] = human_gate_policy
            final_state = runner(
                workflow,
                input_state,
                workflow_json.parent,
                work_dir,
                record,
                **resume_kwargs,
            )
        else:
            runner_kwargs = {}
            if human_gate_policy is not None:
                runner_kwargs["human_gate_policy"] = human_gate_policy
            final_state = runner(
                workflow,
                input_state,
                workflow_json.parent,
                work_dir,
                record,
                **runner_kwargs,
            )
        error_output.write(f"[workflow] completed duration_ms={timer.elapsed_ms()} run_id={run_id}\n")
    except Exception as exc:
        error_output.write(f"[workflow] failed duration_ms={timer.elapsed_ms()} run_id={run_id}\n")
        error_output.write(f"{type(exc).__name__}: {exc}\n")
        return 2

    json_io_module.write_json_line(output, final_state)
    return 0


def run_local_workflow(
    workflow: dict[str, Any],
    input_state: dict[str, Any],
    workflow_root: pathlib.Path,
    work_dir: pathlib.Path,
    record: bool,
    progress_writer: Callable[[str], None] | None = None,
    run_id: str | None = None,
    resume_checkpoint: dict[str, Any] | None = None,
    resume_allow_workflow_changed: bool = False,
    resume_orphaned_running: bool = False,
    human_gate_policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    client_timer = timing_module.Timer.start()
    client = client_factory_module.create_default_client(
        workflow_root=str(workflow_root),
        workspace_root=str(work_dir),
    )
    if progress_writer is not None:
        progress_writer(f"[workflow] startup step=create_client duration_ms={client_timer.elapsed_ms()}")
    with client_provider_module.use_client(client):
        if resume_checkpoint is None and not resume_allow_workflow_changed:
            return runtime_module.invoke_dsl(
                workflow,
                input_state,
                workflow_root=workflow_root,
                workspace_root=work_dir,
                record=record,
                progress_writer=progress_writer,
                run_id=run_id,
                human_gate_policy=human_gate_policy,
            )
        return runtime_module.invoke_dsl(
            workflow,
            input_state,
            workflow_root=workflow_root,
            workspace_root=work_dir,
            record=record,
            progress_writer=progress_writer,
            run_id=run_id,
            resume_checkpoint=resume_checkpoint,
            resume_allow_workflow_changed=resume_allow_workflow_changed,
            resume_orphaned_running=resume_orphaned_running,
            human_gate_policy=human_gate_policy,
        )


def _stderr_progress_writer(stderr: TextIO) -> Callable[[str], None]:
    def write(message: str) -> None:
        stderr.write(message)
        stderr.write("\n")
        stderr.flush()

    return write


def _write_resume_start(stderr: TextIO, checkpoint: dict[str, Any], resume_plan: resume_module.ResumePlan) -> None:
    payload: dict[str, Any] = {
        "resume": True,
        "resume_run_id": checkpoint.get("run_id"),
        "resume_from_node": resume_plan.resume_from,
        "resume_strategy": resume_plan.strategy,
        "state_source": resume_plan.state_source,
        "checkpoint_status": checkpoint.get("status"),
    }
    if resume_plan.warnings:
        payload["warnings"] = resume_plan.warnings
    json_io_module.write_json_line(stderr, payload, sort_keys=False)


def _write_resume_start_failed(stderr: TextIO, checkpoint: dict[str, Any], message: str) -> None:
    reason = _resume_start_failure_reason(message)
    payload: dict[str, Any] = {
        "resume": False,
        "reason": reason,
        "current_node": checkpoint.get("current_node"),
        "failed_node": checkpoint.get("failed_node"),
        "checkpoint_status": checkpoint.get("status"),
        "message": message,
        "suggested_action": _resume_start_suggested_action(reason, checkpoint),
    }
    json_io_module.write_json_line(stderr, payload, sort_keys=False)


def _resume_start_failure_reason(message: str) -> str:
    if "missing failed_node" in message or "missing current_node" in message:
        return "checkpoint_missing_failed_node"
    if "missing state_before_current_node" in message:
        return "checkpoint_missing_state_before_current_node"
    if "workflow hash mismatch" in message:
        return "workflow_hash_mismatch"
    if "orphaned running checkpoint missing current_node" in message:
        return "checkpoint_missing_current_node"
    if "orphaned running checkpoint status must be running" in message:
        return "checkpoint_status_not_running"
    if "status must be failed" in message:
        return "checkpoint_status_not_failed"
    return "checkpoint_invalid"


def _resume_start_suggested_action(reason: str, checkpoint: dict[str, Any]) -> str:
    if reason == "checkpoint_missing_failed_node" and checkpoint.get("current_node"):
        return "fallback_to_current_node"
    if reason == "workflow_hash_mismatch":
        return "pass_resume_allow_workflow_changed_for_debugging_or_rerun_existing"
    return "rerun_existing"


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m lgwf_client.cli",
        description="Run an LGWF workflow JSON locally in a Python process.",
    )
    parser.add_argument("--workflow-json", required=True)
    parser.add_argument("--work-dir", required=True)
    parser.add_argument("--input-json")
    parser.add_argument("--input-json-file")
    parser.add_argument("--record", choices=["true", "false"], default="true")
    parser.add_argument("--resume-run-id")
    parser.add_argument("--resume-allow-workflow-changed", action="store_true")
    parser.add_argument("--resume-orphaned-running", action="store_true")
    parser.add_argument("--auto-human", action="store_true")
    return parser


def _command_names() -> set[str]:
    return command_modules.command_names()


def _run_command(argv: list[str], stdout: TextIO, stderr: TextIO) -> int:
    try:
        parser = _build_command_parser(stderr)
        args = parser.parse_args(argv)
        payload = command_modules.handle(args)
    except _CommandParseError:
        return 2
    except Exception as exc:
        stderr.write(f"{type(exc).__name__}: {exc}\n")
        return 2

    json_io_module.write_json_line(stdout, payload)
    return 0


class _CommandParseError(Exception):
    pass


class _CommandArgumentParser(argparse.ArgumentParser):
    def __init__(self, *args: Any, error_output: TextIO | None = None, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._error_output = error_output

    def error(self, message: str) -> None:
        if self._error_output is None:
            super().error(message)
        self.print_usage(self._error_output)
        self._error_output.write(f"{self.prog}: error: {message}\n")
        raise _CommandParseError(message)


def _build_command_parser(error_output: TextIO | None = None) -> argparse.ArgumentParser:
    parser = _CommandArgumentParser(
        prog="python -m lgwf_client.cli",
        description="Run LGWF workflows and inspect local LGWF artifacts.",
        error_output=error_output,
    )
    subparsers = parser.add_subparsers(
        dest="command",
        required=True,
        parser_class=lambda *args, **kwargs: _CommandArgumentParser(
            *args,
            error_output=error_output,
            **kwargs,
        ),
    )

    command_modules.add_parsers(subparsers)

    return parser


def _resolve_workflow_json(raw_path: str) -> pathlib.Path:
    path = pathlib.Path(raw_path).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"workflow-json must be an existing file: {raw_path}")
    return path


def _resolve_work_dir(raw_path: str) -> pathlib.Path:
    path = pathlib.Path(raw_path).expanduser().resolve()
    if not path.exists() or not path.is_dir():
        raise ValueError(f"work-dir must be an existing directory: {raw_path}")
    return path


def _parse_input_json_arg(args: argparse.Namespace) -> dict[str, Any]:
    if args.input_json and args.input_json_file:
        raise ValueError("--input-json and --input-json-file cannot be combined.")
    if args.input_json_file:
        raw = pathlib.Path(args.input_json_file).read_text(encoding="utf-8-sig")
        return json_io_module.parse_json_object(raw, "input-json-file")
    if args.input_json and args.input_json.startswith("@"):
        raw = pathlib.Path(args.input_json[1:]).read_text(encoding="utf-8-sig")
        return json_io_module.parse_json_object(raw, "input-json")
    return json_io_module.parse_json_object(args.input_json or "{}", "input-json")


def _parse_record(raw: str) -> bool:
    return raw == "true"


def _load_workflow(path: pathlib.Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"workflow-json must contain valid JSON: {path}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"workflow-json root must be a JSON object: {path}")

    return data


if __name__ == "__main__":
    raise SystemExit(main())

