﻿import argparse
import datetime
import pathlib
import time
from typing import Any

import lgwf.checkpoints as checkpoints_module
import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module
import lgwf_client.commands.common as command_common_module
import lgwf_client.process_execution as process_execution_module
import lgwf_client.workflow_package.package_snapshot as package_snapshot_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    agent_sleep = subparsers.add_parser("agent-sleep")
    agent_sleep.set_defaults(handler=handle_agent_sleep)

    stop_workflow = subparsers.add_parser("stop-workflow")
    stop_workflow.add_argument("--pid", type=command_common_module.positive_pid, required=True)
    stop_workflow.add_argument("--work-dir")
    stop_workflow.set_defaults(handler=handle_stop_workflow)

    copy_package = subparsers.add_parser("copy-workflow-package")
    copy_package.add_argument("--workflow-lgwf", required=True)
    copy_package.add_argument("--work-dir", required=True)
    copy_package.set_defaults(handler=handle_copy_workflow_package)


def handle_agent_sleep(args: argparse.Namespace) -> dict[str, Any]:
    del args
    seconds = 5
    time.sleep(seconds)
    return {"ok": True, "slept_seconds": seconds}


def handle_stop_workflow(args: argparse.Namespace) -> dict[str, Any]:
    work_dir = command_common_module.resolve_work_dir(args.work_dir) if args.work_dir else None
    return stop_workflow(args.pid, work_dir)


def handle_copy_workflow_package(args: argparse.Namespace) -> dict[str, Any]:
    return package_snapshot_module.copy_workflow_package(
        args.workflow_lgwf,
        command_common_module.resolve_work_dir(args.work_dir),
    )


def stop_workflow(pid: int, work_dir: pathlib.Path | None = None) -> dict[str, Any]:
    if not process_execution_module.is_process_running(pid):
        return {
            "ok": True,
            "pid": pid,
            "stopped": False,
            "reason": "already_not_running",
        }
    completed = process_execution_module.stop_process_tree(pid)
    payload: dict[str, Any] = {
        "ok": completed.returncode == 0,
        "pid": pid,
        "stopped": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }
    if completed.returncode == 0 and work_dir is not None:
        checkpoint = mark_latest_running_checkpoint_stopped(work_dir, pid)
        if checkpoint is not None:
            payload["checkpoint"] = {
                "run_id": checkpoint.get("run_id"),
                "status": checkpoint.get("status"),
                "resume_from_node": checkpoint.get("failed_node") or checkpoint.get("current_node"),
            }
    return payload


def mark_latest_running_checkpoint_stopped(work_dir: pathlib.Path, pid: int) -> dict[str, Any] | None:
    checkpoint = checkpoints_module.latest_checkpoint_with_status(work_dir, {"running"})
    if checkpoint is None:
        return None
    current_node = checkpoint.get("current_node")
    checkpoint.update(
        {
            "status": "stopped",
            "failed_node": current_node if isinstance(current_node, str) and current_node else None,
            "failure_summary": {
                "stopped_by": "stop-workflow",
                "pid": pid,
            },
            "updated_at": datetime.datetime.now(datetime.UTC).isoformat(),
        }
    )
    path = workspace_layout_module.checkpoint_path(work_dir.resolve(), str(checkpoint["run_id"]))
    file_ops_module.write_json_atomic(path, checkpoint, sort_keys=False)
    return checkpoint
