﻿import argparse
import pathlib
from typing import Any

import lgwf.runs.records as run_records_module
import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module
import lgwf_client.commands.common as command_common_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    list_runs = subparsers.add_parser("list-runs")
    list_runs.add_argument("--work-dir", required=True)
    list_runs.add_argument("--limit", type=int, default=10)
    list_runs.set_defaults(handler=handle_list_runs)

    for name, handler in (
        ("get-run", handle_get_run),
        ("get-run-trace", handle_get_run_trace),
        ("get-run-eval", handle_get_run_eval),
        ("get-run-eval-suite", handle_get_run_eval_suite),
        ("get-run-changes", handle_get_run_changes),
        ("get-run-summary", handle_get_run_summary),
    ):
        parser = subparsers.add_parser(name)
        parser.add_argument("--work-dir", required=True)
        parser.add_argument("--run-id", required=True)
        parser.set_defaults(handler=handler)


def handle_list_runs(args: argparse.Namespace) -> dict[str, Any]:
    return list_runs(command_common_module.resolve_work_dir(args.work_dir), args.limit)


def handle_get_run(args: argparse.Namespace) -> dict[str, Any]:
    return get_run(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def handle_get_run_trace(args: argparse.Namespace) -> dict[str, Any]:
    return get_run_trace(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def handle_get_run_eval(args: argparse.Namespace) -> dict[str, Any]:
    return get_run_eval(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def handle_get_run_eval_suite(args: argparse.Namespace) -> dict[str, Any]:
    return get_run_eval_suite(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def handle_get_run_changes(args: argparse.Namespace) -> dict[str, Any]:
    return get_run_changes(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def handle_get_run_summary(args: argparse.Namespace) -> dict[str, Any]:
    return get_run_summary(command_common_module.resolve_work_dir(args.work_dir), args.run_id)


def list_runs(work_dir: pathlib.Path, limit: int) -> dict[str, Any]:
    if limit < 1:
        raise ValueError("limit must be a positive integer.")
    runs_dir = workspace_layout_module.runs_dir(work_dir)
    if not runs_dir.is_dir():
        return {"runs": []}
    records = []
    for path in runs_dir.glob("*/record.json"):
        record = run_records_module.load_run_record(path)
        records.append(
            {
                "run_id": record["run_id"],
                "status": record["status"],
                "started_at": record["started_at"],
                "finished_at": record["finished_at"],
                "workflow": record["workflow"],
                "change_summary": record.get("change_summary", {}),
                "has_trace": workspace_layout_module.run_trace_path(work_dir, record["run_id"]).is_file(),
                "has_eval": workspace_layout_module.run_eval_path(work_dir, record["run_id"]).is_file(),
                "has_eval_suite": workspace_layout_module.run_eval_suite_path(work_dir, record["run_id"]).is_file(),
            }
        )
    records.sort(key=lambda item: item["finished_at"], reverse=True)
    return {"runs": records[:limit]}


def get_run(work_dir: pathlib.Path, run_id: str) -> dict[str, Any]:
    return run_records_module.load_run_record(run_record_path(work_dir, run_id))


def get_run_trace(work_dir: pathlib.Path, run_id: str) -> dict[str, Any]:
    run_record_path(work_dir, run_id)
    trace_path = workspace_layout_module.run_trace_path(work_dir, run_id)
    if not trace_path.is_file():
        raise ValueError(f"run trace not found: {run_id}")
    data = file_ops_module.read_json(trace_path)
    if not isinstance(data, dict):
        raise ValueError(f"run trace root must be a JSON object: {trace_path}")
    return data


def get_run_eval(work_dir: pathlib.Path, run_id: str) -> dict[str, Any]:
    run_record_path(work_dir, run_id)
    eval_path = workspace_layout_module.run_eval_path(work_dir, run_id)
    if not eval_path.is_file():
        raise ValueError(f"run eval artifact not found: {run_id}")
    data = file_ops_module.read_json(eval_path)
    if not isinstance(data, dict):
        raise ValueError(f"run eval artifact root must be a JSON object: {eval_path}")
    return data


def get_run_eval_suite(work_dir: pathlib.Path, run_id: str) -> dict[str, Any]:
    run_record_path(work_dir, run_id)
    eval_suite_path = workspace_layout_module.run_eval_suite_path(work_dir, run_id)
    if not eval_suite_path.is_file():
        raise ValueError(f"run eval suite artifact not found: {run_id}")
    data = file_ops_module.read_json(eval_suite_path)
    if not isinstance(data, dict):
        raise ValueError(f"run eval suite artifact root must be a JSON object: {eval_suite_path}")
    return data


def get_run_summary(work_dir: pathlib.Path, run_id: str) -> dict[str, str]:
    run_record_path(work_dir, run_id)
    summary_path = workspace_layout_module.run_summary_path(work_dir, run_id)
    if not summary_path.is_file():
        raise ValueError(f"run summary not found: {run_id}")
    return {"run_id": run_id, "summary": file_ops_module.read_text(summary_path)}


def get_run_changes(work_dir: pathlib.Path, run_id: str) -> dict[str, Any]:
    run_record_path(work_dir, run_id)
    changed_path = workspace_layout_module.run_changes_path(work_dir, run_id)
    if not changed_path.is_file():
        raise ValueError(f"run changes artifact not found: {run_id}")
    try:
        data = file_ops_module.read_json(changed_path)
    except file_ops_module.FileOperationError as exc:
        raise ValueError(f"run changes artifact must contain valid JSON: {changed_path}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"run changes artifact root must be a JSON object: {changed_path}")
    return data


def run_record_path(work_dir: pathlib.Path, run_id: str) -> pathlib.Path:
    if not isinstance(run_id, str) or not run_id or "/" in run_id or "\\" in run_id or ".." in run_id:
        raise ValueError("run_id must be a non-empty run id without path separators.")
    path = workspace_layout_module.run_record_path(work_dir, run_id)
    if not path.is_file():
        raise ValueError(f"run not found: {run_id}")
    return path
