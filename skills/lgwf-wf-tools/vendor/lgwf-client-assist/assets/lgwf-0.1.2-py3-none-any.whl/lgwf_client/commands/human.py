﻿import argparse
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf_client.json_io as json_io_module
import lgwf_client.commands.common as command_common_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    list_human = subparsers.add_parser("list-human-requests")
    list_human.add_argument("--work-dir", required=True)
    list_human.set_defaults(handler=handle_list_human_requests)

    get_human = subparsers.add_parser("get-human-request")
    get_human.add_argument("--work-dir", required=True)
    get_human.add_argument("--request-id", required=True)
    get_human.set_defaults(handler=handle_get_human_request)

    respond_human = subparsers.add_parser("respond-human-request")
    respond_human.add_argument("--work-dir", required=True)
    respond_human.add_argument("--request-id", required=True)
    respond_human.add_argument("--caller", choices=["agent", "human_controller"], default="agent")
    respond_human.add_argument("--approval-token")
    respond_human.add_argument("--response-json", required=True)
    respond_human.set_defaults(handler=handle_respond_human_request)

    write_controller_payload = subparsers.add_parser("write-human-controller-payload")
    write_controller_payload.add_argument("--work-dir", required=True)
    write_controller_payload.add_argument("--request-id", required=True)
    write_controller_payload.add_argument("--payload-json", required=True)
    write_controller_payload.set_defaults(handler=handle_write_controller_payload)

    get_controller_payload = subparsers.add_parser("get-human-controller-payload")
    get_controller_payload.add_argument("--work-dir", required=True)
    get_controller_payload.add_argument("--request-id", required=True)
    get_controller_payload.set_defaults(handler=handle_get_controller_payload)

    submit_controller_payload = subparsers.add_parser("submit-human-controller-payload")
    submit_controller_payload.add_argument("--work-dir", required=True)
    submit_controller_payload.add_argument("--request-id", required=True)
    submit_controller_payload.add_argument("--final-user-confirmed", choices=["true", "false"], required=True)
    submit_controller_payload.set_defaults(handler=handle_submit_controller_payload)


def handle_list_human_requests(args: argparse.Namespace) -> dict[str, Any]:
    return {"requests": human_approval_module.list_pending_requests(command_common_module.resolve_work_dir(args.work_dir))}


def handle_get_human_request(args: argparse.Namespace) -> dict[str, Any]:
    return human_approval_module.load_request(command_common_module.resolve_work_dir(args.work_dir), args.request_id)


def handle_respond_human_request(args: argparse.Namespace) -> dict[str, Any]:
    response = json_io_module.parse_json_object(args.response_json, "response-json")
    human_approval_module.write_response(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        response,
        caller=args.caller,
        approval_token=args.approval_token,
    )
    return {"request_id": args.request_id, "ok": True}


def handle_write_controller_payload(args: argparse.Namespace) -> dict[str, Any]:
    controller_payload = command_common_module.parse_payload_json(args.payload_json)
    human_approval_module.write_controller_payload(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        controller_payload,
    )
    return {"request_id": args.request_id, "ok": True}


def handle_get_controller_payload(args: argparse.Namespace) -> dict[str, Any]:
    return human_approval_module.load_controller_payload(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
    )


def handle_submit_controller_payload(args: argparse.Namespace) -> dict[str, Any]:
    human_approval_module.submit_controller_payload(
        command_common_module.resolve_work_dir(args.work_dir),
        args.request_id,
        final_user_confirmed=command_common_module.parse_boolean_arg(
            args.final_user_confirmed,
            "final-user-confirmed",
        ),
    )
    return {"request_id": args.request_id, "ok": True}
