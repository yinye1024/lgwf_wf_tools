﻿import argparse
import pathlib
from typing import Any

import lgwf_client.json_io as json_io_module


def positive_pid(raw: str) -> int:
    try:
        pid = int(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("pid must be a positive integer.") from exc
    if pid < 1:
        raise argparse.ArgumentTypeError("pid must be a positive integer.")
    return pid


def positive_int(raw: str) -> int:
    try:
        value = int(raw)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("value must be a positive integer.") from exc
    if value < 1:
        raise argparse.ArgumentTypeError("value must be a positive integer.")
    return value


def parse_payload_json(raw: str) -> dict[str, Any]:
    return json_io_module.parse_json_object(raw, "payload-json")


def parse_boolean_arg(raw: str, name: str) -> bool:
    if raw == "true":
        return True
    if raw == "false":
        return False
    raise ValueError(f"{name} must be true or false.")


def resolve_work_dir(raw_path: str) -> pathlib.Path:
    path = pathlib.Path(raw_path).expanduser().resolve()
    if not path.exists() or not path.is_dir():
        raise ValueError(f"work-dir must be an existing directory: {raw_path}")
    return path
