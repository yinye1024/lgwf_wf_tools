﻿import argparse
import pathlib
from typing import Any

import lgwf.runs.eval as run_eval_module
import lgwf_client.json_io as json_io_module
import lgwf_client.commands.common as command_common_module
import lgwf_client.commands.runs as runs_command_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    eval_run = subparsers.add_parser("eval-run")
    eval_run.add_argument("--work-dir", required=True)
    eval_run.add_argument("--run-id", required=True)
    eval_run.add_argument("--spec-json", required=True)
    eval_run.add_argument("--golden-trace")
    eval_run.set_defaults(handler=handle_eval_run)

    eval_suite = subparsers.add_parser("eval-suite")
    eval_suite.add_argument("--work-dir", required=True)
    eval_suite.add_argument("--run-id", required=True)
    eval_suite.add_argument("--cases-dir", required=True)
    eval_suite.set_defaults(handler=handle_eval_suite)


def handle_eval_run(args: argparse.Namespace) -> dict[str, Any]:
    return eval_run(
        command_common_module.resolve_work_dir(args.work_dir),
        args.run_id,
        args.spec_json,
        args.golden_trace,
    )


def handle_eval_suite(args: argparse.Namespace) -> dict[str, Any]:
    return eval_suite(
        command_common_module.resolve_work_dir(args.work_dir),
        args.run_id,
        args.cases_dir,
    )


def eval_run(
    work_dir: pathlib.Path,
    run_id: str,
    spec_json: str,
    golden_trace_path: str | None,
) -> dict[str, Any]:
    runs_command_module.run_record_path(work_dir, run_id)
    spec = json_io_module.parse_json_object(spec_json, "spec-json")
    golden_trace = None
    if golden_trace_path:
        golden_trace = run_eval_module.load_golden_trace(pathlib.Path(golden_trace_path).expanduser().resolve())
    return run_eval_module.evaluate_run(work_dir, run_id, spec, golden_trace=golden_trace)


def eval_suite(
    work_dir: pathlib.Path,
    run_id: str,
    cases_dir: str,
) -> dict[str, Any]:
    runs_command_module.run_record_path(work_dir, run_id)
    return run_eval_module.evaluate_suite(work_dir, run_id, pathlib.Path(cases_dir).expanduser().resolve())
