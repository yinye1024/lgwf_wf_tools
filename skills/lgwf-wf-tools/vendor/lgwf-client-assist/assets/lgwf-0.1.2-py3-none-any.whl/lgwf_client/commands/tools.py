import argparse
from typing import Any

import lgwf_client.commands.common as command_common_module
import lgwf_client.tools.registry as tool_registry_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    tool = subparsers.add_parser("tool")
    tool_subparsers = tool.add_subparsers(dest="tool_command", required=True)
    tool_list = tool_subparsers.add_parser("list")
    tool_list.set_defaults(handler=handle_tool)
    tool_describe = tool_subparsers.add_parser("describe")
    tool_describe.add_argument("name")
    tool_describe.set_defaults(handler=handle_tool)
    tool_run = tool_subparsers.add_parser("run")
    tool_run.add_argument("name")
    tool_run.add_argument("--work-dir")
    tool_run.add_argument("--options-json", default="{}")
    tool_run.set_defaults(handler=handle_tool)


def handle_tool(args: argparse.Namespace) -> dict[str, Any]:
    if args.tool_command == "list":
        return {"tools": tool_registry_module.list_public_tools()}
    if args.tool_command == "describe":
        return {"tool": tool_registry_module.describe_public_tool(args.name)}
    if args.tool_command == "run":
        options = command_common_module.parse_payload_json(args.options_json)
        work_dir = command_common_module.resolve_work_dir(args.work_dir) if args.work_dir else None
        result = tool_registry_module.run_cli_tool(
            args.name,
            options,
            work_dir=work_dir,
        )
        return {"ok": True, "tool": args.name, "result": result}
    raise ValueError(f"Unknown tool command: {args.tool_command}")
