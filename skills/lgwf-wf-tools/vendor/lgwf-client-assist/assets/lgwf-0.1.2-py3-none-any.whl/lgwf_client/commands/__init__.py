"""Internal command handlers for ``lgwf_client.cli``."""

import argparse
from collections.abc import Callable
from typing import Any

import lgwf_client.commands.codex as codex_command_module
import lgwf_client.commands.eval as eval_command_module
import lgwf_client.commands.human as human_command_module
import lgwf_client.commands.human_gate as human_gate_command_module
import lgwf_client.commands.main_agent as main_agent_command_module
import lgwf_client.commands.runs as runs_command_module
import lgwf_client.commands.tools as tools_command_module
import lgwf_client.commands.workflow_control as workflow_control_command_module


CommandHandler = Callable[[argparse.Namespace], dict[str, Any]]

COMMAND_NAMES = {
    "list-runs",
    "get-run",
    "get-run-trace",
    "get-run-eval",
    "get-run-eval-suite",
    "get-run-changes",
    "get-run-summary",
    "eval-run",
    "eval-suite",
    "list-human-requests",
    "get-human-request",
    "respond-human-request",
    "write-human-controller-payload",
    "get-human-controller-payload",
    "submit-human-controller-payload",
    "get-human-gate-policy",
    "set-human-gate-policy",
    "clear-human-gate-policy",
    "get-main-agent-status",
    "submit-main-agent-approval",
    "submit-main-agent-review",
    "agent-sleep",
    "stop-workflow",
    "copy-workflow-package",
    "tool",
    "codex",
}


def command_names() -> set[str]:
    return set(COMMAND_NAMES)


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    runs_command_module.add_parsers(subparsers)
    eval_command_module.add_parsers(subparsers)
    human_command_module.add_parsers(subparsers)
    human_gate_command_module.add_parsers(subparsers)
    main_agent_command_module.add_parsers(subparsers)
    workflow_control_command_module.add_parsers(subparsers)
    tools_command_module.add_parsers(subparsers)
    codex_command_module.add_parsers(subparsers)


def handle(args: argparse.Namespace) -> dict[str, Any]:
    handler = getattr(args, "handler", None)
    if handler is None:
        raise ValueError(f"Unknown command: {getattr(args, 'command', None)}")
    return handler(args)
