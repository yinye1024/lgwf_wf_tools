import argparse
import pathlib
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf.human_gate_control as human_gate_control_module
import lgwf.human_gate_policy as human_gate_policy_module
import lgwf_client.commands.common as command_common_module
import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    get_policy = subparsers.add_parser("get-human-gate-policy")
    get_policy.add_argument("--work-dir", required=True)
    get_policy.set_defaults(handler=handle_get_human_gate_policy)

    set_policy = subparsers.add_parser("set-human-gate-policy")
    set_policy.add_argument("--work-dir", required=True)
    set_policy.add_argument("--enabled", choices=["true", "false"], required=True)
    set_policy.add_argument("--apply-pending", action="store_true")
    set_policy.add_argument("--cascade-children", action="store_true")
    set_policy.set_defaults(handler=handle_set_human_gate_policy)

    clear_policy = subparsers.add_parser("clear-human-gate-policy")
    clear_policy.add_argument("--work-dir", required=True)
    clear_policy.add_argument("--cascade-children", action="store_true")
    clear_policy.set_defaults(handler=handle_clear_human_gate_policy)


def handle_get_human_gate_policy(args: argparse.Namespace) -> dict[str, Any]:
    root = command_common_module.resolve_work_dir(args.work_dir)
    policy = human_gate_control_module.load_policy(root)
    return {
        "ok": True,
        "work_dir": str(root),
        "exists": policy is not None,
        "policy": policy,
        "policy_path": str(human_gate_control_module.policy_path(root)),
    }


def handle_set_human_gate_policy(args: argparse.Namespace) -> dict[str, Any]:
    root = command_common_module.resolve_work_dir(args.work_dir)
    enabled = command_common_module.parse_boolean_arg(args.enabled, "enabled")
    targets = _target_roots(root, cascade_children=args.cascade_children)
    policies = []
    applied_pending: list[dict[str, Any]] = []
    for target in targets:
        policy = human_gate_control_module.write_policy(target, enabled=enabled, updated_by="cli")
        policies.append(
            {
                "work_dir": str(target),
                "policy_path": str(human_gate_control_module.policy_path(target)),
                "policy": policy,
            }
        )
        if enabled and args.apply_pending:
            applied_pending.extend(_apply_pending_auto(target))
    return {
        "ok": True,
        "enabled": enabled,
        "targets": policies,
        "applied_pending": applied_pending,
    }


def handle_clear_human_gate_policy(args: argparse.Namespace) -> dict[str, Any]:
    root = command_common_module.resolve_work_dir(args.work_dir)
    targets = _target_roots(root, cascade_children=args.cascade_children)
    cleared = []
    for target in targets:
        cleared.append(
            {
                "work_dir": str(target),
                "policy_path": str(human_gate_control_module.policy_path(target)),
                "removed": human_gate_control_module.clear_policy(target),
            }
        )
    return {
        "ok": True,
        "cleared": cleared,
    }


def _apply_pending_auto(root: pathlib.Path) -> list[dict[str, Any]]:
    applied = []
    for request in human_approval_module.list_pending_requests(root):
        response = human_gate_policy_module.write_auto_response_for_request(
            workspace_root=root,
            request=request,
        )
        if response is None:
            continue
        applied.append(
            {
                "work_dir": str(root),
                "request_id": request["request_id"],
                "kind": request.get("kind", "human_approval"),
                "response": response,
            }
        )
    return applied


def _target_roots(root: pathlib.Path, *, cascade_children: bool) -> list[pathlib.Path]:
    targets = [root]
    if not cascade_children:
        return targets
    seen = {root}
    for child_root in _child_work_dirs(root):
        if child_root not in seen:
            seen.add(child_root)
            targets.append(child_root)
    return targets


def _child_work_dirs(root: pathlib.Path) -> list[pathlib.Path]:
    child_dir = workspace_layout_module.child_runs_dir(root)
    if not child_dir.is_dir():
        return []
    children = []
    for record_path in sorted(child_dir.glob("*.json"), key=_safe_mtime, reverse=True):
        try:
            record = file_ops_module.read_json(record_path)
        except (OSError, ValueError, file_ops_module.FileOperationError):
            continue
        if not isinstance(record, dict):
            continue
        work_dir = record.get("work_dir")
        if not isinstance(work_dir, str) or not work_dir:
            continue
        child_root = pathlib.Path(work_dir).expanduser().resolve()
        if child_root.is_dir():
            children.append(child_root)
    return children


def _safe_mtime(path: pathlib.Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0
