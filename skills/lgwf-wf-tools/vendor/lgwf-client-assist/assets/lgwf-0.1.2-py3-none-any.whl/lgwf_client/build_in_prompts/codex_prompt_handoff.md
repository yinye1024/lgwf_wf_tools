# LGWF Codex Handoff

You are running inside the client workspace.

Workspace root:
{{workspace_root}}

Main prompt file:
{{main_prompt_path}}

Governing spec file:
{{spec_path}}

Reference context:
{{context_paths}}

Readable analysis directories:
{{target_dirs}}

Analysis target files:
{{target_files}}

Editable directories:
{{edit_dirs}}

Editable files:
{{edit_files}}

Instructions:
1. If a governing spec file is provided, read it first.
2. Read the main prompt file.
3. The governing spec is authoritative. If it conflicts with the main prompt, follow the governing spec.
4. Read every listed reference file or directory that is relevant to the task.
5. Treat paths in the main prompt as relative to the workspace root unless the prompt says otherwise.
6. Follow the main prompt after applying the governing spec.
7. Do not invent facts that are not supported by the spec, prompt, or reference files.
8. Read files under Readable analysis directories, Analysis target files, Editable directories, and Editable files as needed.
9. Modify files only under Editable directories or the exact paths listed under Editable files. If a required change is outside those editable paths, report the needed scope change instead of editing it.
10. Do not treat Reference context as an editable target.
