import pathlib


LGWF_DIR = ".lgwf"


def lgwf_dir(root: str | pathlib.Path) -> pathlib.Path:
    return pathlib.Path(root) / LGWF_DIR


def human_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "human"


def human_request_path(root: str | pathlib.Path, request_id: str) -> pathlib.Path:
    return human_dir(root) / f"{request_id}.request.json"


def human_response_path(root: str | pathlib.Path, request_id: str) -> pathlib.Path:
    return human_dir(root) / f"{request_id}.response.json"


def human_controller_payload_path(root: str | pathlib.Path, request_id: str) -> pathlib.Path:
    return human_dir(root) / f"{request_id}.controller_payload.json"


def control_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "control"


def human_gate_policy_path(root: str | pathlib.Path) -> pathlib.Path:
    return control_dir(root) / "human_gate_policy.json"


def human_codex_windows_dir(root: str | pathlib.Path) -> pathlib.Path:
    return human_dir(root) / "codex_windows"


def handoff_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "handoff"


def handoff_pending_path(root: str | pathlib.Path, request_id: str) -> pathlib.Path:
    return handoff_dir(root) / f"{request_id}.pending.json"


def handoff_received_path(root: str | pathlib.Path, request_id: str) -> pathlib.Path:
    return handoff_dir(root) / f"{request_id}.received.json"


def child_runs_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "child-runs"


def child_run_path(root: str | pathlib.Path, node_id: str) -> pathlib.Path:
    return child_runs_dir(root) / f"{node_id}.json"


def isolations_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "isolations"


def isolation_run_dir(root: str | pathlib.Path, namespace: str, key: str) -> pathlib.Path:
    return isolations_dir(root) / namespace / key


def runs_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "runs"


def run_dir(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return runs_dir(root) / run_id


def checkpoints_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "checkpoints"


def checkpoint_dir(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return checkpoints_dir(root) / run_id


def checkpoint_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return checkpoint_dir(root, run_id) / "checkpoint.json"


def run_record_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "record.json"


def run_trace_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "trace.json"


def run_eval_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "eval.json"


def run_eval_suite_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "eval-suite.json"


def run_changes_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "changes.json"


def changed_files_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_changes_path(root, run_id)


def run_summary_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "summary.md"


def run_feedback_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "feedback.md"


def run_diff_path(root: str | pathlib.Path, run_id: str) -> pathlib.Path:
    return run_dir(root, run_id) / "diff.patch"


def processes_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "processes"


def codex_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "codex"


def codex_key_session_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "codex_key_session"


def codex_status_path(root: str | pathlib.Path) -> pathlib.Path:
    return codex_dir(root) / "status.json"


def codex_config_path(root: str | pathlib.Path) -> pathlib.Path:
    return codex_dir(root) / "config.json"


def logs_dir(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "logs"


def runtime_log_path(root: str | pathlib.Path) -> pathlib.Path:
    return logs_dir(root) / "runtime.log"


def context_manifest_path(root: str | pathlib.Path) -> pathlib.Path:
    return lgwf_dir(root) / "context.json"
