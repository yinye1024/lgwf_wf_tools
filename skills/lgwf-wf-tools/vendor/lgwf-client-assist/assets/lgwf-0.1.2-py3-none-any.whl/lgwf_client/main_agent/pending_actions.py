from typing import Any


REVIEW_OPTIONS = ["approve", "revise", "reject"]


def human_approval_action(request: dict[str, Any]) -> dict[str, Any]:
    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("human approval request_id must be a non-empty string.")
    return {
        "type": "human_approval",
        "request_id": request_id,
        "prompt": request.get("prompt"),
        "context": request.get("context"),
        "allowed_responses": ["approve", "reject"],
    }


def human_review_action(request: dict[str, Any]) -> dict[str, Any]:
    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("human review request_id must be a non-empty string.")
    options = request.get("options", REVIEW_OPTIONS)
    if options != REVIEW_OPTIONS:
        options = REVIEW_OPTIONS
    context = request.get("review_context_json", request.get("context"))
    action = {
        "type": "human_review",
        "request_id": request_id,
        "prompt": request.get("prompt"),
        "context": context,
        "review_context_json": context,
        "options": list(options),
        "allowed_responses": list(options),
        "display_template": _review_display_template(request.get("display_template")),
        "revise_requires_full_json": True,
    }
    option_labels = request.get("option_labels")
    if isinstance(option_labels, dict) and all(
        isinstance(key, str) and isinstance(value, str)
        for key, value in option_labels.items()
    ):
        action["option_labels"] = option_labels
    return action


def _review_display_template(raw_template: Any) -> dict[str, Any]:
    if isinstance(raw_template, dict) and raw_template.get("kind") == "review_json_v1":
        template = dict(raw_template)
    else:
        template = {
            "kind": "review_json_v1",
            "context_field": "review_context_json",
            "revise_value": "complete_updated_context_json_object",
        }
    template["options"] = list(REVIEW_OPTIONS)
    return template


def agent_handoff_action(action: dict[str, Any]) -> dict[str, Any]:
    request_id = action.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("agent handoff request_id must be a non-empty string.")
    return dict(action)
