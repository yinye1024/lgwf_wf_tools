import pathlib
from typing import Any

import lgwf.handoff as handoff_module


def submit_main_agent_handoff(
    work_dir: str | pathlib.Path,
    request_id: str,
    *,
    comment: str | None = None,
) -> dict[str, Any]:
    root = pathlib.Path(work_dir).expanduser().resolve()
    result = handoff_module.acknowledge_pending_action(
        root,
        request_id,
        received_by="main_agent",
        comment=comment,
    )
    return {
        "ok": True,
        "request_id": request_id,
        "status": "received",
        "already_received": result["already_received"],
        "received_path": result["received_path"],
        "work_dir": str(root),
    }
