﻿import datetime
import pathlib
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module


MISSING = object()
REVIEW_OPTIONS = ["approve", "revise", "reject"]


def submit_main_agent_review(
    work_dir: str | pathlib.Path,
    request_id: str,
    *,
    route: str,
    value: Any = MISSING,
    comment: str | None = None,
) -> dict[str, Any]:
    root = pathlib.Path(work_dir).expanduser().resolve()
    review_root = _request_root(root, request_id)
    request = human_approval_module.load_request(review_root, request_id)
    if request.get("kind") != "human_review":
        raise ValueError("request is not a human_review request.")
    options = request.get("options", REVIEW_OPTIONS)
    if options != REVIEW_OPTIONS:
        raise ValueError("human_review options are fixed to approve, revise, reject.")
    if route not in options:
        raise ValueError(f"route must be one of: {', '.join(options)}.")
    payload = _controller_payload(
        request_id=request_id,
        route=route,
        value=value,
        comment=comment,
    )
    human_approval_module.write_controller_payload(review_root, request_id, payload)
    response_path = human_approval_module.submit_controller_payload(review_root, request_id, final_user_confirmed=True)
    return {
        "ok": True,
        "request_id": request_id,
        "route": route,
        "response_path": str(response_path),
        "work_dir": str(review_root),
    }


def _controller_payload(
    *,
    request_id: str,
    route: str,
    value: Any,
    comment: str | None,
) -> dict[str, Any]:
    if not isinstance(route, str) or not route:
        raise ValueError("route must be a non-empty string.")
    if route == "reject":
        decision = "reject"
        payload_value = value
    else:
        if route == "revise" and value is MISSING:
            raise ValueError("revise route requires value-json with the complete updated context JSON object.")
        if route == "revise" and not isinstance(value, dict):
            raise ValueError("revise route requires value-json with the complete updated context JSON object.")
        decision = "approve"
        payload_value = _value_with_route(route, value)

    payload: dict[str, Any] = {
        "request_id": request_id,
        "decision": decision,
        "created_by": "main_agent_ask",
        "created_at": datetime.datetime.now(datetime.UTC).isoformat(),
    }
    if payload_value is not MISSING:
        payload["value"] = payload_value
    if comment is not None:
        payload["comment"] = comment
    if decision == "reject" and "comment" not in payload and "value" not in payload:
        raise ValueError("reject route requires comment or value-json.")
    return payload


def _value_with_route(route: str, value: Any) -> Any:
    if value is MISSING:
        return {"route": route}
    if route == "revise":
        return {"route": route, "updated_context": value}
    if isinstance(value, dict) and "route" not in value:
        return {**value, "route": route}
    return value


def _request_root(root: pathlib.Path, request_id: str) -> pathlib.Path:
    try:
        human_approval_module.load_request(root, request_id)
        return root
    except Exception:
        pass
    child_root = _child_request_root(root, request_id)
    if child_root is not None:
        return child_root
    return root


def _child_request_root(root: pathlib.Path, request_id: str) -> pathlib.Path | None:
    child_dir = workspace_layout_module.child_runs_dir(root)
    if not child_dir.is_dir():
        return None
    for record_path in sorted(child_dir.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True):
        try:
            record = file_ops_module.read_json(record_path)
        except (OSError, ValueError, file_ops_module.FileOperationError):
            continue
        if not isinstance(record, dict):
            continue
        work_dir = record.get("work_dir")
        if not isinstance(work_dir, str) or not work_dir:
            continue
        child_root = pathlib.Path(work_dir).expanduser().resolve()
        try:
            human_approval_module.load_request(child_root, request_id)
            return child_root
        except Exception:
            continue
    return None
