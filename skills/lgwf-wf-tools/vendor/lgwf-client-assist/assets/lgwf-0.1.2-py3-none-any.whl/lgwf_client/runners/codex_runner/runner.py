﻿import json
import os
import pathlib
import subprocess
import tempfile
import threading
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.codex_config as codex_config_module
import lgwf_client.python_execution as python_execution_module
import lgwf_client.process_execution as process_execution_module
import lgwf_client.resource_refs as resource_refs_module
import lgwf_client.runners.codex_runner.json_output as json_output_module
import lgwf_client.runners.codex_runner.session_store as session_store_module
import lgwf_client.runners.codex_runner.token_usage as token_usage_module
import lgwf_client.runners.codex_runner.track_store as track_store_module
import lgwf_client.types as client_types


DEFAULT_CODEX_MODEL = codex_config_module.DEFAULT_CODEX_MODEL
DEFAULT_CODEX_TRANSPORT_ARGS = [
    "--disable",
    "responses_websockets",
    "--disable",
    "responses_websockets_v2",
    "--disable",
    "plugins",
]
DEFAULT_CODEX_JSON_ARGS = ["--json"]
DEFAULT_CODEX_EXEC_ARGS = ["--skip-git-repo-check", "--sandbox", "danger-full-access"]
HANDOFF_TEMPLATE_PATH = pathlib.Path(__file__).resolve().parents[2] / "build_in_prompts" / "codex_prompt_handoff.md"


class CodexRunner:
    instruction_type: client_types.InstructionType = "codex"

    def __init__(
        self,
        workflow_root: str | pathlib.Path | None = None,
        workspace_root: str | pathlib.Path | None = None,
    ) -> None:
        self._roots = resource_refs_module.ResourceRoots(
            workflow_root=workflow_root,
            workspace_root=workspace_root,
        )
        self._live_token_usage = self._empty_token_usage()
        self._live_turn_count = 0
        self._token_budget_exceeded: dict[str, Any] | None = None

    def run(
        self,
        instruction: client_types.Instruction,
    ) -> client_types.ExecutionResult:
        payload = instruction["payload"]
        prompt = payload.get("prompt")
        prompt_ref = payload.get("prompt_ref")
        spec_ref = payload.get("spec_ref")
        mode = payload.get("mode", "exec")
        args = payload.get("args", [])
        model = payload.get("model")
        foreground = payload.get("foreground", True)
        ref_root = instruction.get("ref_root")
        output_json = payload.get("output_json")
        output_file = payload.get("output_file")
        contract = payload.get("contract")
        token_budget = self._token_budget(payload.get("token_budget"))
        session = payload.get("session")

        cwd = resource_refs_module.resolve_cwd(
            instruction.get("cwd"),
            self._roots,
        )
        output_json_path = self._output_json_path(cwd, output_json)
        output_json_mode = self._output_json_mode(output_json)
        output_json_repair_attempts = self._output_json_repair_attempts(output_json)
        output_file_path = self._output_file_path(cwd, output_file)
        target_dirs = self._target_paths(cwd, payload.get("target_dirs", []), "target_dirs", expected_type="dir")
        target_files = self._target_paths(cwd, payload.get("target_files", []), "target_files", expected_type="file")
        prompt_text, main_prompt_path, context_paths = self._prompt_text(
            str(cwd),
            prompt,
            prompt_ref,
            spec_ref,
            payload.get("context_refs", []),
            target_dirs,
            target_files,
            output_json_path,
            output_json_mode,
            output_file_path,
            contract,
            ref_root,
        )
        if mode != "exec":
            raise ValueError("codex instruction payload mode currently only supports 'exec'.")
        if not isinstance(args, list) or any(not isinstance(item, str) for item in args):
            raise ValueError("codex instruction payload args must be a list of strings.")
        if session is not None and not isinstance(session, dict):
            raise ValueError("codex instruction payload session must be an object when provided.")
        if foreground and isinstance(session, dict) and session.get("enabled") is True:
            raise ValueError("codex instruction payload session cannot be used with foreground=true.")
        default_config = self._default_codex_config(cwd)
        effective_model = self._effective_model(args, model, default_config)
        codex_args = self._codex_args(args, model, default_config)
        session_plan = self._session_plan(cwd, instruction, session, effective_model)

        if foreground and os.name == "nt":
            if output_json_path is not None:
                raise ValueError("codex instruction payload output_json cannot be used with foreground=true on Windows.")
            if output_file_path is not None:
                raise ValueError("codex instruction payload output_file cannot be used with foreground=true on Windows.")
            return self._run_foreground_windows(
                instruction,
                cwd,
                prompt_text,
                codex_args,
                mode,
                main_prompt_path,
                context_paths,
                target_dirs,
                target_files,
                output_json_path,
                output_json_mode,
                output_file_path,
            )

        return self._run_direct(
            instruction,
            cwd,
            prompt_text,
            codex_args,
            mode,
            main_prompt_path,
            context_paths,
            target_dirs,
            target_files,
            output_json_path,
            output_json_mode,
            output_json_repair_attempts,
            0,
            output_file_path,
            token_budget,
            session_plan,
        )

    def _subprocess_timeout(
        self,
        instruction: client_types.Instruction,
        *,
        extra: int = 0,
    ) -> float | None:
        timeout_seconds = instruction.get("timeout_seconds")
        if timeout_seconds is None:
            return None
        return float(timeout_seconds + extra)

    def _run_direct(
        self,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        prompt_text: str,
        args: list[str],
        mode: str,
        main_prompt_path: str | None,
        context_paths: list[dict[str, str]],
        target_dirs: list[str],
        target_files: list[str],
        output_json_path: pathlib.Path | None,
        output_json_mode: str,
        output_json_repair_attempts: int,
        output_json_repair_attempts_used: int,
        output_file_path: pathlib.Path | None,
        token_budget: dict[str, Any],
        session_plan: session_store_module.SessionPlan | None = None,
    ) -> client_types.ExecutionResult:
        resume_manifest = session_store_module.matching_manifest(session_plan) if session_plan is not None else None
        resume_session_id = (
            str(resume_manifest["codex_session_id"])
            if isinstance(resume_manifest, dict)
            else None
        )
        command = [
            "codex",
            "exec",
        ]
        if resume_session_id is not None:
            command.extend(["resume", *self._resume_args(args), resume_session_id, "-"])
        else:
            command.extend([*args, "-"])
        launch_command = process_execution_module.CommandResolver().resolve(command)
        track_dir = self._create_track_dir(cwd, instruction["id"])
        self._token_budget_exceeded = None
        node_token_usage = self._empty_token_usage()
        stdout_path = track_dir / "stdout.txt"
        stderr_path = track_dir / "stderr.txt"
        self._write_track_start(
            track_dir,
            instruction,
            cwd,
            launch_command,
            prompt_text,
            mode,
            main_prompt_path,
            context_paths,
            target_dirs,
            target_files,
            output_json_path,
            output_json_mode,
            output_file_path,
        )

        with stdout_path.open("w", encoding="utf-8", errors="replace") as stdout_file:
            with stderr_path.open("w", encoding="utf-8", errors="replace") as stderr_file:
                try:
                    process = process_execution_module.popen_cli_command(
                        command,
                        cwd=cwd,
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        env=self._codex_env(),
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                        **self._background_process_kwargs(),
                    )
                except (FileNotFoundError, PermissionError) as exc:
                    self._write_track_launch_error(track_dir, instruction, cwd, mode, exc)
                    raise RuntimeError(f"Codex CLI launch failed: {exc}") from exc
                try:
                    self._write_live_status(cwd, instruction, track_dir, status="running")
                    stdout_thread = self._stream_process_output(
                        process,
                        process.stdout,
                        stdout_file,
                        cwd,
                        instruction,
                        track_dir,
                        token_budget,
                        node_token_usage,
                    )
                    stderr_thread = self._stream_process_output(
                        process,
                        process.stderr,
                        stderr_file,
                        cwd,
                        instruction,
                        track_dir,
                        token_budget,
                        node_token_usage,
                    )
                    self._write_process_stdin(process, prompt_text)
                    returncode = process.wait(timeout=self._subprocess_timeout(instruction))
                    stdout_thread.join(timeout=5)
                    stderr_thread.join(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    stdout_thread.join(timeout=5)
                    stderr_thread.join(timeout=5)
                    self._write_live_status(cwd, instruction, track_dir, status="failed")
                    self._write_track_finish(
                        track_dir,
                        instruction,
                        cwd,
                        mode,
                        -1,
                        timed_out=True,
                        runner_error_type="TimeoutExpired",
                        runner_error_message=f"Codex CLI timed out after {instruction.get('timeout_seconds')} seconds.",
                    )
                    raise
                except BaseException as exc:
                    self._write_live_status(cwd, instruction, track_dir, status="failed")
                    self._write_track_finish(
                        track_dir,
                        instruction,
                        cwd,
                        mode,
                        -1,
                        timed_out=False,
                        runner_error_type=type(exc).__name__,
                        runner_error_message=str(exc),
                    )
                    raise

        stdout = stdout_path.read_text(encoding="utf-8", errors="replace")
        stderr = stderr_path.read_text(encoding="utf-8", errors="replace")
        self._write_track_finish(
            track_dir,
            instruction,
            cwd,
            mode,
            returncode,
            timed_out=False,
            runner_error_type=(
                "token_budget_exceeded" if self._token_budget_exceeded is not None else None
            ),
            runner_error_message=(
                self._token_budget_message(self._token_budget_exceeded)
                if self._token_budget_exceeded is not None
                else None
            ),
        )
        self._write_live_status(
            cwd,
            instruction,
            track_dir,
            status="failed" if self._token_budget_exceeded is not None else "completed" if returncode == 0 else "failed",
            reason="token_budget_exceeded" if self._token_budget_exceeded is not None else None,
            token_budget=self._token_budget_exceeded,
        )

        result = self._result_from_completed(
            instruction,
            cwd,
            mode,
            returncode,
            stdout,
            stderr,
            foreground=False,
            main_prompt_path=main_prompt_path,
            context_paths=context_paths,
            target_dirs=target_dirs,
            target_files=target_files,
        )
        if session_plan is not None:
            session_metadata = session_store_module.metadata(
                session_plan,
                resumed=resume_session_id is not None,
                codex_session_id=resume_session_id,
            )
            result["metadata"]["session"] = session_metadata
            if result["ok"]:
                extracted_session_id = session_store_module.extract_codex_session_id(stdout, stderr)
                codex_session_id = extracted_session_id or resume_session_id
                if codex_session_id is None:
                    message = "Codex session was enabled, but Codex CLI output did not include a session id."
                    result["ok"] = False
                    result["exit_code"] = 1
                    result["stderr"] = (result.get("stderr") or stderr or "") + ("\n" if result.get("stderr") or stderr else "") + message
                    result["metadata"]["runner_error_type"] = "missing_codex_session_id"
                    result["metadata"]["runner_error_message"] = message
                    self._write_track_finish(
                        track_dir,
                        instruction,
                        cwd,
                        mode,
                        1,
                        timed_out=False,
                        runner_error_type="missing_codex_session_id",
                        runner_error_message=message,
                    )
                else:
                    manifest = session_store_module.write_manifest(session_plan, codex_session_id)
                    result["metadata"]["session"] = session_store_module.metadata(
                        session_plan,
                        resumed=resume_session_id is not None,
                        codex_session_id=codex_session_id,
                    )
                    result["metadata"]["session"]["manifest"] = manifest
        if self._token_budget_exceeded is not None:
            result["ok"] = False
            result["exit_code"] = -1
            result["stderr"] = self._token_budget_message(self._token_budget_exceeded)
            result["metadata"]["runner_error_type"] = "token_budget_exceeded"
            result["metadata"]["runner_error_message"] = result["stderr"]
            result["metadata"]["token_budget"] = self._token_budget_exceeded
        if output_json_path is not None and result["ok"]:
            try:
                self._write_output_json(
                    output_json_path,
                    output_json_mode,
                    stdout,
                    stderr,
                    result,
                    repair_attempts_used=output_json_repair_attempts_used,
                )
            except Exception as exc:
                self._write_track_finish(
                    track_dir,
                    instruction,
                    cwd,
                    mode,
                    1,
                    timed_out=False,
                    runner_error_type=type(exc).__name__,
                    runner_error_message=str(exc),
                )
                if output_json_repair_attempts > 0:
                    repair_prompt = self._output_json_repair_prompt(
                        output_json_mode,
                        output_json_path,
                        exc,
                        stdout,
                        stderr,
                    )
                    return self._run_direct(
                        instruction,
                        cwd,
                        repair_prompt,
                        args,
                        mode,
                        main_prompt_path,
                        context_paths,
                        target_dirs,
                        target_files,
                        output_json_path,
                        output_json_mode,
                        output_json_repair_attempts - 1,
                        output_json_repair_attempts_used + 1,
                        output_file_path,
                        token_budget,
                        session_plan,
                    )
                raise
        if output_file_path is not None and result["ok"]:
            try:
                self._write_output_file(output_file_path, result)
            except Exception as exc:
                self._write_track_finish(
                    track_dir,
                    instruction,
                    cwd,
                    mode,
                    1,
                    timed_out=False,
                    runner_error_type=type(exc).__name__,
                    runner_error_message=str(exc),
                )
                raise
        token_usage = result["metadata"].get("token_usage")
        if isinstance(token_usage, dict):
            self._write_track_token_usage(track_dir, token_usage)
        result["metadata"]["background"] = True
        self._attach_track_result(result, track_dir, prompt_text, stdout_path, stderr_path)
        return result

    def _write_process_stdin(self, process: subprocess.Popen, prompt_text: str) -> None:
        setattr(process, "stdin_input", prompt_text)
        stdin = process.stdin
        if stdin is None:
            return
        stdin.write(prompt_text)
        stdin.flush()
        stdin.close()

    def _stream_process_output(
        self,
        process: subprocess.Popen,
        stream: Any,
        output_file: Any,
        cwd: pathlib.Path,
        instruction: client_types.Instruction,
        track_dir: pathlib.Path,
        token_budget: dict[str, Any],
        node_token_usage: dict[str, int],
    ) -> threading.Thread:
        def read_stream() -> None:
            if stream is None:
                return
            for line in stream:
                output_file.write(line)
                output_file.flush()
                usage = self._token_usage_from_json_line(line)
                if usage is not None:
                    self._live_turn_count += 1
                    self._add_token_usage(self._live_token_usage, usage)
                    self._add_token_usage(node_token_usage, usage)
                    budget_exceeded = self._check_token_budget(token_budget, node_token_usage)
                    if budget_exceeded is not None:
                        self._token_budget_exceeded = budget_exceeded
                        self._write_live_status(
                            cwd,
                            instruction,
                            track_dir,
                            status="failed",
                            reason="token_budget_exceeded",
                            token_budget=budget_exceeded,
                        )
                        try:
                            process.kill()
                        except Exception:
                            pass
                        return
                    self._write_live_status(cwd, instruction, track_dir, status="running")

        thread = threading.Thread(target=read_stream, daemon=True)
        thread.start()
        return thread

    def _write_live_status(
        self,
        cwd: pathlib.Path,
        instruction: client_types.Instruction,
        track_dir: pathlib.Path,
        *,
        status: str,
        reason: str | None = None,
        token_budget: dict[str, Any] | None = None,
    ) -> None:
        track_store_module.write_live_status(
            cwd,
            instruction,
            track_dir,
            status=status,
            live_turn_count=self._live_turn_count,
            live_token_usage=self._live_token_usage,
            reason=reason,
            token_budget=token_budget,
        )

    def _codex_env(self) -> dict[str, str]:
        env = dict(os.environ)
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        if os.name == "nt":
            env["PYTHONLEGACYWINDOWSSTDIO"] = "0"
        return env

    def _background_process_kwargs(self) -> dict[str, Any]:
        flags = process_execution_module.background_no_window_flags()
        return {} if flags == 0 else {"creationflags": flags}

    def _attach_track_result(
        self,
        result: client_types.ExecutionResult,
        track_dir: pathlib.Path,
        prompt_text: str,
        stdout_path: pathlib.Path,
        stderr_path: pathlib.Path,
    ) -> None:
        track_store_module.attach_track_result(result, track_dir, prompt_text, stdout_path, stderr_path)

    def _create_track_dir(self, cwd: pathlib.Path, instruction_id: str) -> pathlib.Path:
        return track_store_module.create_track_dir(cwd, instruction_id)

    def _write_track_start(
        self,
        track_dir: pathlib.Path,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        command: list[str],
        prompt_text: str,
        mode: str,
        main_prompt_path: str | None,
        context_paths: list[dict[str, str]],
        target_dirs: list[str],
        target_files: list[str],
        output_json_path: pathlib.Path | None = None,
        output_json_mode: str = "managed",
        output_file_path: pathlib.Path | None = None,
        *,
        foreground: bool = False,
        background: bool = True,
    ) -> None:
        track_store_module.write_track_start(
            track_dir,
            instruction,
            cwd,
            command,
            prompt_text,
            mode,
            main_prompt_path,
            context_paths,
            target_dirs,
            target_files,
            output_json_path,
            output_json_mode,
            output_file_path,
            foreground=foreground,
            background=background,
        )

    def _write_track_finish(
        self,
        track_dir: pathlib.Path,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        mode: str,
        returncode: int,
        *,
        timed_out: bool,
        runner_error_type: str | None = None,
        runner_error_message: str | None = None,
        foreground: bool = False,
        background: bool = True,
    ) -> None:
        track_store_module.write_track_finish(
            track_dir,
            instruction,
            cwd,
            mode,
            returncode,
            timed_out=timed_out,
            runner_error_type=runner_error_type,
            runner_error_message=runner_error_message,
            foreground=foreground,
            background=background,
        )

    def _write_track_token_usage(self, track_dir: pathlib.Path, token_usage: dict[str, int]) -> None:
        track_store_module.write_track_token_usage(track_dir, token_usage)

    def _write_track_launch_error(
        self,
        track_dir: pathlib.Path,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        mode: str,
        exc: Exception,
    ) -> None:
        track_store_module.write_track_launch_error(track_dir, instruction, cwd, mode, exc)

    def _write_json(self, path: pathlib.Path, data: dict[str, Any]) -> None:
        track_store_module.write_json(path, data)

    def _output_json_path(self, cwd: pathlib.Path, output_json: Any) -> pathlib.Path | None:
        return json_output_module.output_json_path(cwd, output_json)

    def _output_json_mode(self, output_json: Any) -> str:
        return json_output_module.output_json_mode(output_json)

    def _output_json_repair_attempts(self, output_json: Any) -> int:
        return json_output_module.output_json_repair_attempts(output_json)

    def _output_file_path(self, cwd: pathlib.Path, output_file: Any) -> pathlib.Path | None:
        return json_output_module.output_file_path(cwd, output_file)

    def _write_output_json(
        self,
        output_json_path: pathlib.Path,
        output_json_mode: str,
        stdout: str,
        stderr: str,
        result: client_types.ExecutionResult,
        *,
        repair_attempts_used: int = 0,
    ) -> None:
        json_output_module.write_output_json(
            output_json_path,
            output_json_mode,
            stdout,
            stderr,
            result,
            repair_attempts_used=repair_attempts_used,
        )

    def _output_json_repair_prompt(
        self,
        output_json_mode: str,
        output_json_path: pathlib.Path,
        exc: BaseException,
        stdout: str,
        stderr: str,
    ) -> str:
        return json_output_module.output_json_repair_prompt(output_json_mode, output_json_path, exc, stdout, stderr)

    def _managed_output_json_repair_prompt(
        self,
        output_json_path: pathlib.Path,
        exc: BaseException,
        stdout: str,
        stderr: str,
    ) -> str:
        return json_output_module.managed_output_json_repair_prompt(output_json_path, exc, stdout, stderr)

    def _file_output_json_repair_prompt(
        self,
        output_json_path: pathlib.Path,
        exc: BaseException,
        stdout: str,
        stderr: str,
    ) -> str:
        return json_output_module.file_output_json_repair_prompt(output_json_path, exc, stdout, stderr)

    def _compact_output_for_repair(self, text: str, limit: int = 4000) -> str:
        return json_output_module.compact_output_for_repair(text, limit)

    def _read_file_output_json(self, output_json_path: pathlib.Path) -> dict[str, Any]:
        return json_output_module.read_file_output_json(output_json_path)

    def _write_output_file(self, output_file_path: pathlib.Path, result: client_types.ExecutionResult) -> None:
        json_output_module.write_output_file(output_file_path, result)

    def _extract_json_object(self, stdout: str, stderr: str) -> dict[str, Any]:
        return json_output_module.extract_json_object(stdout, stderr)

    def _json_object_from_json_events(self, text: str) -> dict[str, Any] | None:
        return json_output_module.json_object_from_json_events(text)

    def _looks_like_json_events(self, text: str) -> bool:
        return json_output_module.looks_like_json_events(text)

    def _json_event_objects(self, text: str) -> list[dict[str, Any]]:
        return json_output_module.json_event_objects(text)

    def _event_text_values(self, value: Any) -> list[str]:
        return json_output_module.event_text_values(value)

    def _first_json_value(self, text: str) -> Any | None:
        return json_output_module.first_json_value(text)

    def _first_json_value_with_object_error(self, text: str) -> tuple[Any | None, tuple[int, int, str] | None]:
        return json_output_module.first_json_value_with_object_error(text)

    def _json_decode_location(self, text: str, start_index: int, exc: BaseException | None) -> tuple[int, int, str]:
        return json_output_module.json_decode_location(text, start_index, exc)

    def _mojibake_report(self, text: str) -> dict[str, Any]:
        return json_output_module.mojibake_report(text)

    def _run_foreground_windows(
        self,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        prompt_text: str,
        args: list[str],
        mode: str,
        main_prompt_path: str | None,
        context_paths: list[dict[str, str]],
        target_dirs: list[str],
        target_files: list[str],
        output_json_path: pathlib.Path | None,
        output_json_mode: str,
        output_file_path: pathlib.Path | None,
    ) -> client_types.ExecutionResult:
        command = [
            "codex",
            "exec",
            *args,
            "-",
        ]
        launch_command = process_execution_module.CommandResolver().resolve(command)
        track_dir = self._create_track_dir(cwd, instruction["id"])
        stdout_path = track_dir / "stdout.txt"
        stderr_path = track_dir / "stderr.txt"
        self._write_track_start(
            track_dir,
            instruction,
            cwd,
            launch_command,
            prompt_text,
            mode,
            main_prompt_path,
            context_paths,
            target_dirs,
            target_files,
            output_json_path,
            output_json_mode,
            output_file_path,
            foreground=True,
            background=False,
        )
        with tempfile.TemporaryDirectory(prefix="lgwf-codex-") as temp_dir:
            temp_root = pathlib.Path(temp_dir)
            prompt_path = temp_root / "prompt.txt"
            args_path = temp_root / "args.json"
            runner_path = temp_root / "run_codex.py"
            exit_code_path = temp_root / "exit_code.txt"

            file_ops_module.write_text_atomic(prompt_path, prompt_text)
            file_ops_module.write_json_atomic(args_path, args, indent=None)
            file_ops_module.write_text_atomic(
                runner_path,
                self._foreground_runner_source(
                    cwd,
                    prompt_path,
                    args_path,
                    exit_code_path,
                ),
            )

            title = f"LGWF Codex {instruction['id']}"
            python_env = python_execution_module.discover_python()
            completed = process_execution_module.run_command(
                [
                    "cmd.exe",
                    "/c",
                    "start",
                    title,
                    "/wait",
                    *python_env.script_command(runner_path),
                ],
                cwd=temp_root,
                env=python_env.env(),
                timeout_seconds=self._subprocess_timeout(instruction, extra=15),
            )

            returncode = self._foreground_returncode(exit_code_path, completed.returncode)

        file_ops_module.write_text_atomic(stdout_path, "")
        file_ops_module.write_text_atomic(stderr_path, completed.stderr)
        self._write_track_finish(
            track_dir,
            instruction,
            cwd,
            mode,
            returncode,
            timed_out=completed.timed_out,
            runner_error_type="TimeoutExpired" if completed.timed_out else None,
            runner_error_message=(
                f"Codex CLI timed out after {instruction.get('timeout_seconds')} seconds."
                if completed.timed_out
                else None
            ),
            foreground=True,
            background=False,
        )

        result = self._result_from_completed(
            instruction,
            cwd,
            mode,
            returncode,
            "",
            completed.stderr,
            foreground=True,
            interactive=True,
            main_prompt_path=main_prompt_path,
            context_paths=context_paths,
            target_dirs=target_dirs,
            target_files=target_files,
        )
        result["metadata"]["background"] = False
        self._attach_track_result(result, track_dir, prompt_text, stdout_path, stderr_path)
        return result

    def _result_from_completed(
        self,
        instruction: client_types.Instruction,
        cwd: pathlib.Path,
        mode: str,
        returncode: int,
        stdout: str,
        stderr: str,
        foreground: bool,
        interactive: bool = False,
        main_prompt_path: str | None = None,
        context_paths: list[dict[str, str]] | None = None,
        target_dirs: list[str] | None = None,
        target_files: list[str] | None = None,
    ) -> client_types.ExecutionResult:
        metadata: dict[str, Any] = {
            "cwd": str(cwd),
            "mode": mode,
            "foreground": foreground,
            "interactive": interactive,
            "timeout": instruction.get("timeout_seconds"),
        }
        if main_prompt_path is not None:
            metadata["main_prompt_path"] = main_prompt_path
        if context_paths is not None:
            metadata["context_paths"] = context_paths
        if target_dirs is not None:
            metadata["target_dirs"] = target_dirs
        if target_files is not None:
            metadata["target_files"] = target_files
        token_usage = self._parse_token_usage(stdout, stderr)
        if token_usage is not None:
            metadata["token_usage"] = token_usage

        return {
            "instruction_id": instruction["id"],
            "ok": returncode == 0,
            "exit_code": returncode,
            "stdout": stdout,
            "stderr": stderr,
            "artifacts": [],
            "changed_files": [],
            "metadata": metadata,
        }

    def _foreground_runner_source(
        self,
        cwd: pathlib.Path,
        prompt_path: pathlib.Path,
        args_path: pathlib.Path,
        exit_code_path: pathlib.Path,
    ) -> str:
        return f'''import json
import os
import pathlib
import subprocess
import time

import lgwf_client.process_execution as process_execution

cwd = pathlib.Path({str(cwd)!r})
prompt = pathlib.Path({str(prompt_path)!r}).read_text(encoding="utf-8")
args = json.loads(pathlib.Path({str(args_path)!r}).read_text(encoding="utf-8"))
exit_code_path = pathlib.Path({str(exit_code_path)!r})

command = process_execution.CommandResolver().resolve(["codex", *args, "-"])
completed = subprocess.run(
    command,
    cwd=cwd,
    env={{
        **os.environ,
        "PYTHONUTF8": "1",
        "PYTHONIOENCODING": "utf-8",
        "PYTHONLEGACYWINDOWSSTDIO": "0",
    }},
    input=prompt,
    text=True,
    encoding="utf-8",
    errors="replace",
)
exit_code_path.write_text(str(completed.returncode), encoding="utf-8")
time.sleep(5)
raise SystemExit(completed.returncode)
'''

    def _foreground_returncode(self, exit_code_path: pathlib.Path, fallback: int) -> int:
        if not exit_code_path.exists():
            return fallback
        try:
            return int(exit_code_path.read_text(encoding="utf-8").strip())
        except ValueError:
            return fallback

    def _parse_token_usage(self, stdout: str, stderr: str) -> dict[str, int] | None:
        return token_usage_module.parse_token_usage(stdout, stderr)

    def _token_usage_from_json_line(self, line: str) -> dict[str, int] | None:
        return token_usage_module.token_usage_from_json_line(line)

    def _parse_json_usage(self, text: str) -> dict[str, Any] | None:
        return token_usage_module.parse_json_usage(text)

    def _find_usage_object(self, value: Any) -> dict[str, Any] | None:
        return token_usage_module.find_usage_object(value)

    def _parse_text_usage(self, text: str) -> dict[str, int] | None:
        return token_usage_module.parse_text_usage(text)

    def _normalize_token_usage(self, usage: dict[str, Any]) -> dict[str, int]:
        return token_usage_module.normalize_token_usage(usage)

    def _empty_token_usage(self) -> dict[str, int]:
        return token_usage_module.empty_token_usage()

    def _add_token_usage(self, total: dict[str, int], usage: dict[str, int]) -> None:
        token_usage_module.add_token_usage(total, usage)

    def _token_budget(self, raw: Any) -> dict[str, Any]:
        return token_usage_module.token_budget(raw)

    def _check_token_budget(
        self,
        token_budget: dict[str, Any],
        node_token_usage: dict[str, int],
    ) -> dict[str, Any] | None:
        return token_usage_module.check_token_budget(token_budget, node_token_usage)

    def _token_budget_message(self, token_budget: dict[str, Any] | None) -> str:
        return token_usage_module.token_budget_message(token_budget)

    def _positive_int_or_none(self, value: Any) -> int | None:
        return token_usage_module.positive_int_or_none(value)

    def _parse_int(self, value: Any) -> int:
        return token_usage_module.parse_int(value)

    def _codex_args(self, args: list[str], model: Any, default_config: dict[str, Any] | None = None) -> list[str]:
        has_model_arg = self._has_model_arg(args)
        if model is not None and (not isinstance(model, str) or not model.strip()):
            raise ValueError("codex instruction payload model must be a non-empty string when provided.")
        if model is not None and has_model_arg:
            raise ValueError("codex instruction payload model must not be set in both model and args.")
        transport_args = self._transport_args(args)
        json_args = self._json_args(args)
        exec_args = self._default_exec_args(args)
        config_args = self._codex_default_config_args(args, default_config or {})
        if model is not None:
            return [*transport_args, *json_args, *exec_args, *args, *config_args, "--model", model]
        if has_model_arg:
            return [*transport_args, *json_args, *exec_args, *args, *config_args]
        default_model = str((default_config or {}).get("model") or DEFAULT_CODEX_MODEL)
        return [*transport_args, *json_args, *exec_args, *args, *config_args, "--model", default_model]

    def _resume_args(self, args: list[str]) -> list[str]:
        filtered: list[str] = []
        skip_next = False
        for item in args:
            if skip_next:
                skip_next = False
                continue
            if item in {"--sandbox", "-s", "--ask-for-approval", "-a"}:
                skip_next = True
                continue
            if item.startswith("--sandbox=") or item.startswith("--ask-for-approval="):
                continue
            filtered.append(item)
        return filtered

    def _effective_model(self, args: list[str], model: Any, default_config: dict[str, Any]) -> str:
        if isinstance(model, str) and model.strip():
            return model.strip()
        model_arg = self._model_arg_value(args)
        if model_arg is not None:
            return model_arg
        default_model = default_config.get("model")
        return str(default_model or DEFAULT_CODEX_MODEL)

    def _model_arg_value(self, args: list[str]) -> str | None:
        for index, item in enumerate(args):
            if item in {"-m", "--model"} and index + 1 < len(args):
                value = args[index + 1]
                if isinstance(value, str) and value.strip():
                    return value.strip()
            if item.startswith("--model="):
                value = item.split("=", 1)[1]
                if value.strip():
                    return value.strip()
        return None

    def _session_plan(
        self,
        cwd: pathlib.Path,
        instruction: client_types.Instruction,
        session: Any,
        model: str,
    ) -> session_store_module.SessionPlan | None:
        if not isinstance(session, dict) or session.get("enabled") is not True:
            return None
        if self._roots.workspace_root is not None:
            workspace_root = pathlib.Path(self._roots.workspace_root).resolve()
        elif isinstance(session.get("work_dir"), str) and session["work_dir"].strip():
            workspace_root = pathlib.Path(session["work_dir"]).expanduser().resolve()
        else:
            workspace_root = cwd
        return session_store_module.build_session_plan(
            workspace_root=workspace_root,
            cwd=cwd,
            instruction_id=instruction["id"],
            session=session,
            model=model,
        )

    def _default_codex_config(self, cwd: pathlib.Path) -> dict[str, Any]:
        workspace_root = self._roots.workspace_root
        root = pathlib.Path(workspace_root).resolve() if workspace_root is not None else cwd
        return codex_config_module.get_codex_model(root)

    def _codex_default_config_args(self, args: list[str], config: dict[str, Any]) -> list[str]:
        defaults: list[str] = []
        for key in ("model_reasoning_effort", "service_tier"):
            value = config.get(key)
            if isinstance(value, str) and value and not self._has_config_arg(args, key):
                defaults.extend(["-c", f"{key}={json.dumps(value)}"])
        return defaults

    def _has_model_arg(self, args: list[str]) -> bool:
        return any(item == "-m" or item == "--model" or item.startswith("--model=") for item in args)

    def _has_config_arg(self, args: list[str], key: str) -> bool:
        for index, item in enumerate(args):
            if item in {"-c", "--config"} and index + 1 < len(args):
                if args[index + 1].split("=", 1)[0] == key:
                    return True
            if item.startswith("--config="):
                if item[len("--config=") :].split("=", 1)[0] == key:
                    return True
        return False

    def _transport_args(self, args: list[str]) -> list[str]:
        if "responses_websockets" in args or "responses_websockets_v2" in args:
            return []
        return DEFAULT_CODEX_TRANSPORT_ARGS

    def _json_args(self, args: list[str]) -> list[str]:
        if "--json" in args:
            return []
        return DEFAULT_CODEX_JSON_ARGS

    def _default_exec_args(self, args: list[str]) -> list[str]:
        if "--skip-git-repo-check" in args:
            return []
        return DEFAULT_CODEX_EXEC_ARGS

    def _prompt_text(
        self,
        cwd: str,
        prompt: Any,
        prompt_ref: Any,
        spec_ref: Any = None,
        context_refs: Any = None,
        target_dirs: list[str] | None = None,
        target_files: list[str] | None = None,
        output_json_path: pathlib.Path | None = None,
        output_json_mode: str = "managed",
        output_file_path: pathlib.Path | None = None,
        contract: Any = None,
        ref_root: Any = None,
    ) -> tuple[str, str | None, list[dict[str, str]]]:
        has_prompt = isinstance(prompt, str) and bool(prompt.strip())
        has_prompt_ref = prompt_ref is not None

        if has_prompt == has_prompt_ref:
            raise ValueError("codex instruction payload requires exactly one of prompt or prompt_ref.")

        spec_path: pathlib.Path | None = None
        if spec_ref is not None:
            spec_path = resource_refs_module.resolve_resource_path(
                cwd,
                spec_ref,
                "spec_ref",
                self._roots,
                ref_root,
            )
            if not spec_path.is_file():
                raise ValueError(f"codex instruction spec_ref does not exist or is not a file: {spec_path}")

        if has_prompt:
            output_contract_text = (
                self._contract_instruction(contract)
                + self._output_json_instruction(output_json_path, output_json_mode)
                + self._output_file_instruction(output_file_path)
            )
            if spec_path is not None:
                return (
                    self._render_inline_spec_prompt(prompt, spec_path) + output_contract_text,
                    None,
                    [],
                )
            return prompt + output_contract_text, None, []

        prompt_path = resource_refs_module.resolve_resource_path(cwd, prompt_ref, "prompt_ref", self._roots, ref_root)
        if not prompt_path.is_file():
            raise ValueError(f"codex instruction prompt_ref does not exist or is not a file: {prompt_path}")
        context_paths = self._context_paths(cwd, context_refs, ref_root)
        return (
            self._render_handoff_prompt(
                cwd,
                prompt_path,
                spec_path,
                context_paths,
                target_dirs or [],
                target_files or [],
                output_json_path,
                output_json_mode,
                output_file_path,
                contract,
            ),
            str(prompt_path),
            context_paths,
        )

    def _render_inline_spec_prompt(self, prompt: str, spec_path: pathlib.Path) -> str:
        return (
            "# LGWF Codex Handoff\n\n"
            f"Governing spec file:\n{spec_path}\n\n"
            "The governing spec is authoritative. If it conflicts with the main prompt, "
            "follow the governing spec.\n\n"
            f"Main prompt:\n{prompt}\n"
        )

    def _context_paths(
        self,
        cwd: str,
        context_refs: Any,
        ref_root: Any = None,
    ) -> list[dict[str, str]]:
        if context_refs is None:
            return []
        if not isinstance(context_refs, list):
            raise ValueError("codex instruction payload context_refs must be a list.")

        resolved: list[dict[str, str]] = []
        for index, item in enumerate(context_refs):
            label = f"context_refs[{index}]"
            if not isinstance(item, dict):
                raise ValueError(f"codex instruction payload {label} must be an object.")
            ref_type = item.get("type")
            if ref_type not in {"file", "dir"}:
                raise ValueError(f"codex instruction payload {label}.type must be 'file' or 'dir'.")
            path = resource_refs_module.resolve_resource_path(cwd, item, label, self._roots, ref_root)
            if ref_type == "file" and not path.is_file():
                raise ValueError(f"codex instruction payload {label} must be a file: {path}")
            if ref_type == "dir" and not path.is_dir():
                raise ValueError(f"codex instruction payload {label} must be a directory: {path}")
            resolved.append(
                {
                    "type": ref_type,
                    "path": str(path),
                }
            )
        return resolved

    def _render_handoff_prompt(
        self,
        cwd: str,
        prompt_path: pathlib.Path,
        spec_path: pathlib.Path | None,
        context_paths: list[dict[str, str]],
        target_dirs: list[str],
        target_files: list[str],
        output_json_path: pathlib.Path | None = None,
        output_json_mode: str = "managed",
        output_file_path: pathlib.Path | None = None,
        contract: Any = None,
    ) -> str:
        template = HANDOFF_TEMPLATE_PATH.read_text(encoding="utf-8")
        context_text = "\n".join(
            f"- {item['type']}: {item['path']}"
            for item in context_paths
        )
        if not context_text:
            context_text = "- none"
        target_dirs_text = "\n".join(f"- dir: {path}" for path in target_dirs)
        if not target_dirs_text:
            target_dirs_text = "- none"
        target_files_text = "\n".join(f"- file: {path}" for path in target_files)
        if not target_files_text:
            target_files_text = "- none"
        spec_text = str(spec_path) if spec_path is not None else "- none"
        managed_json_context = self._render_managed_json_context(context_paths)

        return (
            template
            .replace("{{main_prompt_path}}", str(prompt_path))
            .replace("{{spec_path}}", spec_text)
            .replace("{{workspace_root}}", str(pathlib.Path(cwd).resolve()))
            .replace("{{context_paths}}", context_text)
            .replace("{{target_dirs}}", target_dirs_text)
            .replace("{{target_files}}", target_files_text)
            + managed_json_context
            + self._contract_instruction(contract)
            + self._output_json_instruction(output_json_path, output_json_mode)
            + self._output_file_instruction(output_file_path)
        )

    def _render_managed_json_context(self, context_paths: list[dict[str, str]]) -> str:
        json_files = [
            pathlib.Path(item["path"])
            for item in context_paths
            if item.get("type") == "file" and pathlib.Path(item.get("path", "")).suffix.lower() == ".json"
        ]
        if not json_files:
            return ""

        sections = [
            "\n\nRuntime-provided JSON context:\n",
            "The following JSON files were read by LGWF runtime using UTF-8 and parsed before Codex was started. "
            "Treat this section as authoritative. Do not read these JSON files with shell, PowerShell, or ad-hoc scripts.\n",
        ]
        for path in json_files:
            text = path.read_text(encoding="utf-8-sig")
            try:
                data = json.loads(text)
            except json.JSONDecodeError as exc:
                raise ValueError(f"JSON context is invalid: {path}: {exc.msg}") from exc
            report = self._mojibake_report(text)
            if report["detected"]:
                raise ValueError(f"JSON context appears mojibake-corrupted: {path}: {report['reason']}")
            rendered = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
            sections.append(f"\n[json_context:{path.name}]\npath: {path}\nparsed: true\nmojibake_detected: false\ncontent:\n")
            sections.append("```json\n")
            sections.append(rendered)
            sections.append("\n```\n")
        return "".join(sections)

    def _output_json_instruction(self, output_json_path: pathlib.Path | None, output_json_mode: str = "managed") -> str:
        if output_json_path is None:
            return ""
        if output_json_mode == "file":
            return (
                "\n\nCodex-written JSON output:\n"
                f"- Output path: {output_json_path}\n"
                "- Write, edit, or create this output JSON file yourself before finishing.\n"
                "- The file must be UTF-8 encoded JSON with exactly one top-level object.\n"
                "- Your final response can be concise; LGWF runtime will validate the file after Codex exits.\n"
            )
        return (
            "\n\nRuntime-managed JSON output:\n"
            f"- Output path: {output_json_path}\n"
            "- Return exactly one JSON object in your final response.\n"
            "- Do not write, edit, or create the output JSON file yourself. LGWF runtime will parse your JSON object, "
            "validate it, and write the file using UTF-8 atomic IO.\n"
        )

    def _contract_instruction(self, contract: Any) -> str:
        if contract is None:
            return ""
        if not isinstance(contract, dict):
            raise ValueError("codex instruction payload contract must be an object when provided.")
        rendered = json.dumps(contract, ensure_ascii=False, indent=2, sort_keys=True)
        return (
            "\n\nLGWF node contract:\n"
            "Treat this contract as workflow-authoritative input/output scope for this node.\n"
            "Use reads_state and reads_resources as declared inputs; produce writes_state and writes_resources as declared outputs when applicable.\n"
            "```json\n"
            f"{rendered}\n"
            "```\n"
        )

    def _output_file_instruction(self, output_file_path: pathlib.Path | None) -> str:
        if output_file_path is None:
            return ""
        return (
            "\n\nCodex-written file output:\n"
            f"- Output path: {output_file_path}\n"
            "- Write, edit, or create this output file yourself before finishing.\n"
            "- The file must be UTF-8 encoded text.\n"
            "- Your final response can be concise; LGWF runtime will validate the file after Codex exits.\n"
        )

    def _target_paths(
        self,
        cwd: pathlib.Path,
        value: Any,
        label: str,
        *,
        expected_type: str,
    ) -> list[str]:
        if value is None:
            return []
        if not isinstance(value, list):
            raise ValueError(f"codex instruction payload {label} must be a list.")
        resolved: list[str] = []
        for index, item in enumerate(value):
            item_label = f"{label}[{index}]"
            if not isinstance(item, str) or not item.strip():
                raise ValueError(f"codex instruction payload {item_label} must be a non-empty string.")
            path = pathlib.Path(item).expanduser()
            if not path.is_absolute():
                path = cwd / path
            path = path.resolve()
            if expected_type == "dir" and not path.is_dir():
                raise ValueError(f"codex instruction payload {item_label} must be a directory: {path}")
            if expected_type == "file" and not path.is_file():
                raise ValueError(f"codex instruction payload {item_label} must be a file: {path}")
            resolved.append(str(path))
        return resolved

