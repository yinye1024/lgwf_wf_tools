import json
import re
from typing import Any


def parse_token_usage(stdout: str, stderr: str) -> dict[str, int] | None:
    text = "\n".join(part for part in (stdout, stderr) if part)
    if not text:
        return None

    usage = parse_json_usage(text)
    if usage is None:
        usage = parse_text_usage(text)
    if usage is None:
        return None

    normalized = normalize_token_usage(usage)
    if not any(normalized.values()):
        return None
    return normalized


def token_usage_from_json_line(line: str) -> dict[str, int] | None:
    stripped = line.strip()
    if not stripped.startswith("{"):
        return None
    try:
        data = json.loads(stripped)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict) or data.get("type") != "turn.completed":
        return None
    usage = data.get("usage")
    if not isinstance(usage, dict):
        return None
    normalized = normalize_token_usage(usage)
    return normalized if any(normalized.values()) else None


def parse_json_usage(text: str) -> dict[str, Any] | None:
    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        usage = find_usage_object(data)
        if usage is not None:
            return usage
    return None


def find_usage_object(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        for key in ("token_usage", "usage"):
            candidate = value.get(key)
            if isinstance(candidate, dict):
                return candidate
        if any(key in value for key in ("input_tokens", "output_tokens", "total_tokens")):
            return value
        for item in value.values():
            candidate = find_usage_object(item)
            if candidate is not None:
                return candidate
    elif isinstance(value, list):
        for item in value:
            candidate = find_usage_object(item)
            if candidate is not None:
                return candidate
    return None


def parse_text_usage(text: str) -> dict[str, int] | None:
    usage: dict[str, int] = {}
    patterns = {
        "input_tokens": [
            r"\binput(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
            r"\bprompt(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
        ],
        "output_tokens": [
            r"\boutput(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
            r"\bcompletion(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
        ],
        "total_tokens": [
            r"\btotal(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
        ],
        "cached_input_tokens": [
            r"\bcached(?:\s+input)?(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
            r"\+\s*([0-9][0-9,]*)\s+cached",
        ],
        "reasoning_output_tokens": [
            r"\breasoning(?:\s+output)?(?:\s+tokens)?\s*[:=]\s*([0-9][0-9,]*)",
            r"\(reasoning\s+([0-9][0-9,]*)\)",
        ],
    }
    for key, key_patterns in patterns.items():
        for pattern in key_patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                usage[key] = parse_int(match.group(1))
                break
    return usage or None


def normalize_token_usage(usage: dict[str, Any]) -> dict[str, int]:
    aliases = {
        "input_tokens": ("input_tokens", "prompt_tokens", "input", "prompt"),
        "output_tokens": ("output_tokens", "completion_tokens", "output", "completion"),
        "total_tokens": ("total_tokens", "total"),
        "cached_input_tokens": ("cached_input_tokens", "cached_tokens", "cached_input", "cached"),
        "reasoning_output_tokens": (
            "reasoning_output_tokens",
            "reasoning_tokens",
            "output_reasoning_tokens",
            "reasoning",
        ),
    }
    normalized: dict[str, int] = {}
    for target_key, source_keys in aliases.items():
        normalized[target_key] = 0
        for source_key in source_keys:
            if source_key in usage:
                normalized[target_key] = parse_int(usage[source_key])
                break
    if normalized["total_tokens"] == 0:
        normalized["total_tokens"] = normalized["input_tokens"] + normalized["output_tokens"]
    return normalized


def empty_token_usage() -> dict[str, int]:
    return {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "cached_input_tokens": 0,
        "reasoning_output_tokens": 0,
    }


def add_token_usage(total: dict[str, int], usage: dict[str, int]) -> None:
    normalized = normalize_token_usage(usage)
    for key in total:
        total[key] += normalized.get(key, 0)


def token_budget(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {"token_max": None, "on_token_limit": "warn", "used_before": 0}
    on_token_limit = raw.get("on_token_limit", "warn")
    if on_token_limit not in {"warn", "fail"}:
        on_token_limit = "warn"
    return {
        "token_max": positive_int_or_none(raw.get("token_max")),
        "on_token_limit": on_token_limit,
        "used_before": parse_int(raw.get("used_before")),
    }


def check_token_budget(
    budget: dict[str, Any],
    node_token_usage: dict[str, int],
) -> dict[str, Any] | None:
    token_max = budget.get("token_max")
    if not isinstance(token_max, int) or token_max <= 0:
        return None
    used_before = parse_int(budget.get("used_before"))
    used_current = parse_int(node_token_usage.get("total_tokens"))
    used_total = used_before + used_current
    if used_total <= token_max:
        return None
    exceeded = {
        "token_max": token_max,
        "on_token_limit": budget.get("on_token_limit", "warn"),
        "used_before": used_before,
        "used_current": used_current,
        "used_total": used_total,
        "over_by": used_total - token_max,
    }
    if exceeded["on_token_limit"] != "fail":
        return None
    return exceeded


def token_budget_message(budget: dict[str, Any] | None) -> str:
    if not isinstance(budget, dict):
        return "Codex token budget exceeded."
    return (
        "Codex token budget exceeded: "
        f"used_total={budget.get('used_total')} "
        f"token_max={budget.get('token_max')} "
        f"over_by={budget.get('over_by')}"
    )


def positive_int_or_none(value: Any) -> int | None:
    parsed = parse_int(value)
    return parsed if parsed > 0 else None


def parse_int(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        return max(value, 0)
    if isinstance(value, float):
        return max(int(value), 0)
    if isinstance(value, str):
        cleaned = value.replace(",", "").strip()
        if cleaned.isdigit():
            return int(cleaned)
    return 0
