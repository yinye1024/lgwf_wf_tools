from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import pathlib
import re
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module


SESSION_VERSION = 1
SESSION_ID_KEYS = ("session_id", "thread_id", "conversation_id")


@dataclass(frozen=True)
class SessionPlan:
    scope: str
    logical_session_id: str
    session_file: pathlib.Path
    workspace_root: pathlib.Path
    node_id: str
    model: str
    cwd: str
    match_root: str
    run_id: str
    parent_node_id: str | None = None
    slot_name: str | None = None
    workflow_key: str | None = None
    group: str | None = None


def build_session_plan(
    *,
    workspace_root: pathlib.Path,
    cwd: pathlib.Path,
    instruction_id: str,
    session: dict[str, Any] | None,
    model: str,
) -> SessionPlan | None:
    if not isinstance(session, dict) or session.get("enabled") is not True:
        return None
    node_id = _non_empty_string(session.get("node_id")) or _node_id_from_instruction_id(instruction_id)
    run_id = _non_empty_string(session.get("run_id")) or "adhoc"
    scope = _non_empty_string(session.get("scope")) or "node_run"
    if scope == "auto":
        scope = "node_run"
    parent_node_id = _non_empty_string(session.get("parent_node_id"))
    slot_name = _non_empty_string(session.get("slot_name"))
    workflow_key = _non_empty_string(session.get("workflow_key"))
    group = _non_empty_string(session.get("group"))
    logical_session_id = _logical_session_id(
        run_id=run_id,
        scope=scope,
        node_id=node_id,
        parent_node_id=parent_node_id,
        slot_name=slot_name,
        workflow_key=workflow_key,
        group=group,
    )
    resolved_cwd = cwd.resolve()
    match_root = _resolve_optional_path_string(
        session.get("match_root"),
        base=workspace_root,
    ) or str(resolved_cwd)
    session_file = _session_dir(workspace_root, session) / f"{_safe_session_filename(logical_session_id)}.json"
    return SessionPlan(
        scope=scope,
        logical_session_id=logical_session_id,
        session_file=session_file,
        workspace_root=workspace_root,
        node_id=node_id,
        model=model,
        cwd=str(resolved_cwd),
        match_root=match_root,
        run_id=run_id,
        parent_node_id=parent_node_id,
        slot_name=slot_name,
        workflow_key=workflow_key,
        group=group,
    )


def sessions_dir(workspace_root: pathlib.Path) -> pathlib.Path:
    return workspace_layout_module.codex_dir(workspace_root) / "sessions"


def _session_dir(workspace_root: pathlib.Path, session: dict[str, Any]) -> pathlib.Path:
    session_dir = _resolve_optional_path_string(session.get("session_dir"), base=workspace_root)
    if session_dir is None:
        return sessions_dir(workspace_root)
    return pathlib.Path(session_dir)


def matching_manifest(plan: SessionPlan) -> dict[str, Any] | None:
    if not plan.session_file.is_file():
        return None
    try:
        manifest = file_ops_module.read_json_object(plan.session_file, label="Codex session manifest")
    except file_ops_module.FileOperationError:
        return None
    if manifest.get("logical_session_id") != plan.logical_session_id:
        return None
    if manifest.get("scope") != plan.scope:
        return None
    if manifest.get("model") != plan.model:
        return None
    manifest_match_root = _non_empty_string(manifest.get("match_root")) or _non_empty_string(manifest.get("cwd"))
    if manifest_match_root != plan.match_root:
        return None
    codex_session_id = manifest.get("codex_session_id")
    if not isinstance(codex_session_id, str) or not codex_session_id.strip():
        return None
    return manifest


def write_manifest(plan: SessionPlan, codex_session_id: str) -> dict[str, Any]:
    previous = matching_manifest(plan) or {}
    now = _now()
    payload: dict[str, Any] = {
        "version": SESSION_VERSION,
        "logical_session_id": plan.logical_session_id,
        "codex_session_id": codex_session_id,
        "scope": plan.scope,
        "node_id": plan.node_id,
        "run_id": plan.run_id,
        "model": plan.model,
        "cwd": plan.cwd,
        "match_root": plan.match_root,
        "workspace_root": str(plan.workspace_root),
        "session_dir": str(plan.session_file.parent),
        "created_at": previous.get("created_at") if isinstance(previous.get("created_at"), str) else now,
        "last_used_at": now,
        "status": "active",
    }
    if plan.parent_node_id is not None:
        payload["parent_node_id"] = plan.parent_node_id
    if plan.slot_name is not None:
        payload["slot_name"] = plan.slot_name
    if plan.workflow_key is not None:
        payload["workflow_key"] = plan.workflow_key
    if plan.group is not None:
        payload["group"] = plan.group
    file_ops_module.write_json_atomic(plan.session_file, payload, sort_keys=False)
    return payload


def extract_codex_session_id(*texts: str) -> str | None:
    events: list[dict[str, Any]] = []
    for text in texts:
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                value = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                events.append(value)

    for key in SESSION_ID_KEYS:
        for event in events:
            event_type = event.get("type")
            if isinstance(event_type, str) and ("session" in event_type or "thread" in event_type or "conversation" in event_type):
                value = event.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()

    for key in SESSION_ID_KEYS:
        for event in events:
            value = _find_string_key(event, key)
            if value is not None:
                return value
    return None


def metadata(plan: SessionPlan, *, resumed: bool, codex_session_id: str | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "enabled": True,
        "resumed": resumed,
        "scope": plan.scope,
        "logical_session_id": plan.logical_session_id,
        "session_file": str(plan.session_file),
        "node_id": plan.node_id,
        "run_id": plan.run_id,
        "model": plan.model,
        "cwd": plan.cwd,
        "match_root": plan.match_root,
        "session_dir": str(plan.session_file.parent),
    }
    if codex_session_id is not None:
        payload["codex_session_id"] = codex_session_id
    if plan.parent_node_id is not None:
        payload["parent_node_id"] = plan.parent_node_id
    if plan.slot_name is not None:
        payload["slot_name"] = plan.slot_name
    if plan.workflow_key is not None:
        payload["workflow_key"] = plan.workflow_key
    if plan.group is not None:
        payload["group"] = plan.group
    return payload


def _logical_session_id(
    *,
    run_id: str,
    scope: str,
    node_id: str,
    parent_node_id: str | None,
    slot_name: str | None,
    workflow_key: str | None,
    group: str | None,
) -> str:
    if scope == "workflow_group":
        if workflow_key is None or group is None:
            raise ValueError("Codex session scope workflow_group requires workflow_key and group.")
        return f"run:{run_id}/workflow:{workflow_key}/group:{group}"
    if scope == "react_slot":
        if parent_node_id is None or slot_name is None:
            raise ValueError("Codex session scope react_slot requires parent_node_id and slot_name.")
        return f"run:{run_id}/react:{parent_node_id}/slot:{slot_name}"
    if scope == "agent_loop_slot":
        if parent_node_id is None or slot_name is None:
            raise ValueError("Codex session scope agent_loop_slot requires parent_node_id and slot_name.")
        return f"run:{run_id}/agent_loop:{parent_node_id}/slot:{slot_name}"
    if scope != "node_run":
        raise ValueError("Codex session scope must be node_run, react_slot, agent_loop_slot, or workflow_group.")
    return f"run:{run_id}/node:{node_id}"


def _safe_session_filename(logical_session_id: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", logical_session_id).strip("._-")
    if len(safe) > 72:
        safe = safe[:72].rstrip("._-")
    digest = hashlib.sha256(logical_session_id.encode("utf-8")).hexdigest()[:16]
    return f"{safe or 'codex_session'}-{digest}"


def _node_id_from_instruction_id(instruction_id: str) -> str:
    if ":" in instruction_id:
        return instruction_id.split(":", 1)[0]
    return instruction_id


def _non_empty_string(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _resolve_optional_path_string(value: Any, *, base: pathlib.Path) -> str | None:
    raw = _non_empty_string(value)
    if raw is None:
        return None
    path = pathlib.Path(raw).expanduser()
    if not path.is_absolute():
        path = base / path
    return str(path.resolve())


def _find_string_key(value: Any, key: str) -> str | None:
    if isinstance(value, dict):
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
        for item in value.values():
            found = _find_string_key(item, key)
            if found is not None:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _find_string_key(item, key)
            if found is not None:
                return found
    return None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
