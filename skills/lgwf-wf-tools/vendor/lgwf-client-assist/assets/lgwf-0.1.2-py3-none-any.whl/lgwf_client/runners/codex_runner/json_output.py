import json
import pathlib
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.types as client_types


class MissingOutputError(ValueError):
    def __init__(self, output_kind: str, path: pathlib.Path, message: str) -> None:
        super().__init__(message)
        self.output_kind = output_kind
        self.path = path


def output_json_path(cwd: pathlib.Path, output_json: Any) -> pathlib.Path | None:
    if output_json is None:
        return None
    if not isinstance(output_json, dict):
        raise ValueError("codex instruction payload output_json must be an object when provided.")
    raw_path = output_json.get("path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("codex instruction payload output_json.path must be a non-empty string.")
    if pathlib.Path(raw_path).suffix.lower() != ".json":
        raise ValueError("codex instruction payload output_json.path must reference a .json file.")
    return file_ops_module.resolve_under_root(cwd, raw_path)


def output_json_mode(output_json: Any) -> str:
    if output_json is None:
        return "managed"
    if not isinstance(output_json, dict):
        raise ValueError("codex instruction payload output_json must be an object when provided.")
    mode = output_json.get("mode", "managed")
    if mode not in {"managed", "file"}:
        raise ValueError("codex instruction payload output_json.mode must be 'managed' or 'file'.")
    return mode


def output_json_repair_attempts(output_json: Any) -> int:
    if output_json is None:
        return 0
    if not isinstance(output_json, dict):
        raise ValueError("codex instruction payload output_json must be an object when provided.")
    value = output_json.get("repair_attempts", 1)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("codex instruction payload output_json.repair_attempts must be an integer >= 0.")
    return value


def output_file_path(cwd: pathlib.Path, output_file: Any) -> pathlib.Path | None:
    if output_file is None:
        return None
    if not isinstance(output_file, dict):
        raise ValueError("codex instruction payload output_file must be an object when provided.")
    raw_path = output_file.get("path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("codex instruction payload output_file.path must be a non-empty string.")
    return file_ops_module.resolve_under_root(cwd, raw_path)


def write_output_json(
    output_json_path: pathlib.Path,
    mode: str,
    stdout: str,
    stderr: str,
    result: client_types.ExecutionResult,
    *,
    repair_attempts_used: int = 0,
) -> None:
    if mode == "file":
        data = read_file_output_json(output_json_path)
    else:
        data = extract_json_object(stdout, stderr)
    rendered = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
    report = mojibake_report(rendered)
    metadata = result.setdefault("metadata", {})
    if report["detected"]:
        raise ValueError(f"{mode} output JSON appears mojibake-corrupted: {report['reason']}")
    if mode == "managed":
        file_ops_module.write_json_atomic(output_json_path, data)
    output_metadata: dict[str, Any] = {
        "path": str(output_json_path),
        "mode": mode,
        "validated": True,
        "mojibake_detected": False,
    }
    if repair_attempts_used > 0:
        output_metadata["repair_attempts_used"] = repair_attempts_used
    if mode == "managed":
        output_metadata["data"] = data
    else:
        output_metadata["size_bytes"] = output_json_path.stat().st_size
    metadata["output_json"] = output_metadata
    result["artifacts"].append({"type": f"{mode}_json_output", "path": str(output_json_path)})


def output_json_repair_prompt(
    mode: str,
    output_json_path: pathlib.Path,
    exc: BaseException,
    stdout: str,
    stderr: str,
) -> str:
    if mode == "file":
        return file_output_json_repair_prompt(output_json_path, exc, stdout, stderr)
    return managed_output_json_repair_prompt(output_json_path, exc, stdout, stderr)


def managed_output_json_repair_prompt(
    output_json_path: pathlib.Path,
    exc: BaseException,
    stdout: str,
    stderr: str,
) -> str:
    return (
        "Previous managed output JSON validation failed.\n\n"
        f"Output path: {output_json_path}\n"
        f"Validation error: {type(exc).__name__}: {exc}\n\n"
        "Return exactly one valid JSON object in your final response.\n"
        "Do not include Markdown fences, comments, prose, trailing commas, or non-JSON literals.\n"
        "Use double-quoted strings, true/false/null, numbers, arrays, and objects only.\n\n"
        "Previous stdout excerpt:\n"
        f"{compact_output_for_repair(stdout)}\n\n"
        "Previous stderr excerpt:\n"
        f"{compact_output_for_repair(stderr)}\n"
    )


def file_output_json_repair_prompt(
    output_json_path: pathlib.Path,
    exc: BaseException,
    stdout: str,
    stderr: str,
) -> str:
    return (
        "Previous file output JSON validation failed.\n\n"
        f"Output path: {output_json_path}\n"
        f"Validation error: {type(exc).__name__}: {exc}\n\n"
        "Rewrite or create the output file at the exact output path as UTF-8 JSON.\n"
        "The file must contain exactly one top-level JSON object.\n"
        "Do not write an array, Markdown, comments, prose, trailing commas, or non-JSON literals into the file.\n"
        "Your final response can be concise after the file has been fixed.\n\n"
        "Previous stdout excerpt:\n"
        f"{compact_output_for_repair(stdout)}\n\n"
        "Previous stderr excerpt:\n"
        f"{compact_output_for_repair(stderr)}\n"
    )


def compact_output_for_repair(text: str, limit: int = 4000) -> str:
    if not text:
        return "<empty>"
    stripped = text.strip()
    if len(stripped) <= limit:
        return stripped
    return stripped[:limit] + "\n...<truncated>"


def read_file_output_json(output_json_path: pathlib.Path) -> dict[str, Any]:
    if not output_json_path.is_file():
        raise MissingOutputError(
            "output_json",
            output_json_path,
            f"file output JSON was requested, but Codex did not create the file: {output_json_path}",
        )
    try:
        text = output_json_path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("file output JSON must be UTF-8 encoded.") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"file output JSON is invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("file output JSON must be a JSON object.")
    return data


def write_output_file(output_file_path: pathlib.Path, result: client_types.ExecutionResult) -> None:
    if not output_file_path.is_file():
        raise MissingOutputError(
            "output_file",
            output_file_path,
            f"output file was requested, but Codex did not create the file: {output_file_path}",
        )
    try:
        text = output_file_path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("output file must be UTF-8 encoded.") from exc
    report = mojibake_report(text)
    if report["detected"]:
        raise ValueError(f"output file appears mojibake-corrupted: {report['reason']}")
    metadata = result.setdefault("metadata", {})
    metadata["output_file"] = {
        "path": str(output_file_path),
        "validated": True,
        "mojibake_detected": False,
        "size_bytes": output_file_path.stat().st_size,
    }
    result["artifacts"].append({"type": "file_output", "path": str(output_file_path)})


def extract_json_object(stdout: str, stderr: str) -> dict[str, Any]:
    for text in (stdout, stderr):
        data = json_object_from_json_events(text)
        if data is not None:
            return data
    if any(looks_like_json_events(text) for text in (stdout, stderr)):
        raise ValueError("managed output JSON was requested, but Codex JSON events did not contain a JSON object.")
    for text in (stdout, stderr):
        data = first_json_value(text)
        if data is not None:
            if not isinstance(data, dict):
                raise ValueError("managed output JSON must be a JSON object.")
            return data
    raise ValueError("managed output JSON was requested, but Codex output did not contain a JSON object.")


def json_object_from_json_events(text: str) -> dict[str, Any] | None:
    for event in reversed(json_event_objects(text)):
        for candidate in event_text_values(event):
            data, object_error = first_json_value_with_object_error(candidate)
            if data is None:
                continue
            if not isinstance(data, dict):
                if object_error is not None:
                    line, column, message = object_error
                    raise ValueError(
                        "managed output JSON object is invalid at "
                        f"line {line} column {column}: {message}"
                    )
                raise ValueError("managed output JSON must be a JSON object.")
            return data
    return None


def looks_like_json_events(text: str) -> bool:
    return any(isinstance(event.get("type"), str) for event in json_event_objects(text))


def json_event_objects(text: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            events.append(data)
    return events


def event_text_values(value: Any) -> list[str]:
    values: list[str] = []
    if isinstance(value, str):
        values.append(value)
    elif isinstance(value, dict):
        for key in ("message", "text", "content", "output", "final", "last_message", "item", "delta"):
            if key in value:
                values.extend(event_text_values(value[key]))
    elif isinstance(value, list):
        for item in value:
            values.extend(event_text_values(item))
    return values


def first_json_value(text: str) -> Any | None:
    data, _object_error = first_json_value_with_object_error(text)
    return data


def first_json_value_with_object_error(text: str) -> tuple[Any | None, tuple[int, int, str] | None]:
    decoder = json.JSONDecoder()
    first_object_error: tuple[int, int, str] | None = None
    for index, char in enumerate(text):
        if char not in "{[":
            continue
        try:
            data, _end = decoder.raw_decode(text[index:])
        except json.JSONDecodeError as exc:
            if char == "{" and first_object_error is None:
                first_object_error = json_decode_location(text, index, exc)
            continue
        return data, first_object_error
    return None, first_object_error


def json_decode_location(text: str, start_index: int, exc: BaseException | None) -> tuple[int, int, str]:
    if not isinstance(exc, json.JSONDecodeError):
        return (1, 1, "invalid JSON")
    absolute_index = start_index + exc.pos
    line = text.count("\n", 0, absolute_index) + 1
    last_newline = text.rfind("\n", 0, absolute_index)
    column = absolute_index + 1 if last_newline == -1 else absolute_index - last_newline
    return line, column, exc.msg


def mojibake_report(text: str) -> dict[str, Any]:
    if not text:
        return {"detected": False, "reason": ""}
    markers = ("楠", "鐢", "閺", "鏂", "绛", "闃", "銆", "锛", "濂", "妫")
    marker_count = sum(text.count(marker) for marker in markers)
    question_count = text.count("?")
    cjk_count = sum(1 for char in text if "\u4e00" <= char <= "\u9fff")
    if marker_count >= 20:
        return {"detected": True, "reason": f"mojibake marker count is {marker_count}"}
    if cjk_count >= 20 and question_count / max(len(text), 1) > 0.05:
        return {"detected": True, "reason": f"question mark ratio is {question_count / max(len(text), 1):.3f}"}
    return {"detected": False, "reason": ""}
