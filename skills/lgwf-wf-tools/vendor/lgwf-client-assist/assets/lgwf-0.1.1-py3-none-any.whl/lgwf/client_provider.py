import contextlib
import contextvars
from typing import Any

import lgwf_client.client_factory as client_factory_module
import lgwf.runs.trace as trace_module
import lgwf_tools.timing as timing_module


_CURRENT_CLIENT: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "lgwf_current_client",
    default=None,
)
_DEFAULT_CLIENT: Any | None = None


def get_client() -> Any:
    current_client = _CURRENT_CLIENT.get()
    if current_client is not None:
        return _trace_client(current_client)

    global _DEFAULT_CLIENT
    if _DEFAULT_CLIENT is None:
        _DEFAULT_CLIENT = client_factory_module.create_default_client()
    return _trace_client(_DEFAULT_CLIENT)


@contextlib.contextmanager
def use_client(client: Any):
    token = _CURRENT_CLIENT.set(client)
    try:
        yield
    finally:
        _CURRENT_CLIENT.reset(token)


class _TracingClient:
    def __init__(self, wrapped: Any, recorder: Any) -> None:
        self._wrapped = wrapped
        self._recorder = recorder

    def execute(self, instruction: dict[str, Any]) -> Any:
        node_id = trace_module.current_node_id()
        timer = timing_module.Timer.start()
        self._recorder.client_started(instruction, node_id)
        try:
            result = self._wrapped.execute(instruction)
        except Exception as exc:
            self._recorder.client_failed(instruction, exc, timer.elapsed_ms())
            raise
        self._recorder.client_completed(instruction, result, timer.elapsed_ms())
        return result


def _trace_client(client: Any) -> Any:
    recorder = trace_module.current_recorder()
    if recorder is None or isinstance(client, _TracingClient):
        return client
    return _TracingClient(client, recorder)

