import datetime
from typing import Any

import lgwf.capabilities.catalog as capability_catalog_module
import lgwf.runs.eval_cases as eval_cases_module
import lgwf.runs.eval_schema as eval_schema_module
import lgwf.runs.trace as trace_module
import lgwf_tools.file_ops as file_ops_module
import lgwf_tools.workspace_layout as workspace_layout_module


Trace = dict[str, Any]
EvalSpec = dict[str, Any]
EvalResult = dict[str, Any]
EvalSuiteResult = dict[str, Any]


def evaluate_run(
    workspace_root,
    run_id: str,
    spec: EvalSpec,
    *,
    golden_trace: Trace | None = None,
) -> EvalResult:
    trace_path = workspace_layout_module.run_trace_path(workspace_root, run_id)
    trace = trace_module.load_trace(trace_path)
    result = evaluate_trace(trace, spec, golden_trace=golden_trace)
    save_eval(workspace_root, run_id, result)
    return result


def evaluate_suite(workspace_root, run_id: str, cases_dir) -> EvalSuiteResult:
    trace_path = workspace_layout_module.run_trace_path(workspace_root, run_id)
    trace = trace_module.load_trace(trace_path)
    cases = []
    for eval_case in eval_cases_module.load_eval_cases(cases_dir):
        metadata = eval_case["case"]
        result = evaluate_trace(
            trace,
            eval_case["spec"],
            golden_trace=eval_case["golden_trace"],
        )
        cases.append(
            {
                "case_id": metadata["case_id"],
                "kind": metadata["kind"],
                "description": metadata["description"],
                "tags": metadata["tags"],
                "passed": result["passed"],
                "summary": result["summary"],
                "checks": result["checks"],
            }
        )
    failed = sum(1 for item in cases if not item["passed"])
    suite = {
        "version": 1,
        "run_id": run_id,
        "passed": failed == 0,
        "evaluated_at": _utc_now(),
        "summary": {
            "total": len(cases),
            "passed": len(cases) - failed,
            "failed": failed,
        },
        "cases": cases,
    }
    save_eval_suite(workspace_root, run_id, suite)
    return suite


def evaluate_trace(trace: Trace, spec: EvalSpec, *, golden_trace: Trace | None = None) -> EvalResult:
    if not isinstance(spec, dict):
        raise ValueError("eval spec root must be an object.")
    eval_schema_module.validate_eval_spec(spec)
    run_id = _string(trace.get("run_id")) or "unknown"
    checks: list[dict[str, Any]] = []
    trajectory = spec.get("trajectory", {})
    if trajectory is not None and not isinstance(trajectory, dict):
        raise ValueError("eval spec trajectory must be an object.")
    if isinstance(trajectory, dict):
        checks.extend(_trajectory_checks(trace, trajectory))
    policy = spec.get("policy")
    if policy is not None:
        if not isinstance(policy, dict):
            raise ValueError("eval spec policy must be an object.")
        checks.extend(_policy_checks(trace, policy))
    if golden_trace is not None:
        checks.append(_golden_check(trace, golden_trace))
    failed = sum(1 for check in checks if not check["passed"])
    result: EvalResult = {
        "version": 1,
        "run_id": run_id,
        "passed": failed == 0,
        "evaluated_at": _utc_now(),
        "summary": {
            "total": len(checks),
            "passed": len(checks) - failed,
            "failed": failed,
        },
        "checks": checks,
        "spec_summary": _spec_summary(spec, golden_trace is not None),
    }
    return result


def save_eval(workspace_root, run_id: str, result: EvalResult) -> None:
    path = workspace_layout_module.run_eval_path(workspace_root, run_id)
    file_ops_module.write_json_atomic(path, result, sort_keys=False)


def save_eval_suite(workspace_root, run_id: str, result: EvalSuiteResult) -> None:
    path = workspace_layout_module.run_eval_suite_path(workspace_root, run_id)
    file_ops_module.write_json_atomic(path, result, sort_keys=False)


def load_eval(path) -> EvalResult:
    data = file_ops_module.read_json(path)
    if not isinstance(data, dict):
        raise ValueError("eval root must be an object.")
    return data


def load_eval_suite(path) -> EvalSuiteResult:
    data = file_ops_module.read_json(path)
    if not isinstance(data, dict):
        raise ValueError("eval suite root must be an object.")
    return data


def load_golden_trace(path) -> Trace:
    return trace_module.load_trace(path)


def _trajectory_checks(trace: Trace, trajectory: dict[str, Any]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    if "status" in trajectory:
        checks.append(_check_equal("trajectory.status", trace.get("status"), trajectory["status"]))
    if "nodes" in trajectory:
        checks.append(_check_equal("trajectory.nodes", _node_ids(trace), trajectory["nodes"]))
    if "ordered_subsequence" in trajectory:
        checks.append(_check_ordered_subsequence(trace, trajectory["ordered_subsequence"]))
    if "must_happen_before" in trajectory:
        checks.append(_check_must_happen_before(trace, trajectory["must_happen_before"]))
    if "node_status" in trajectory:
        checks.append(_check_node_status(trace, trajectory["node_status"]))
    if "capabilities" in trajectory:
        checks.append(_check_equal("trajectory.capabilities", _capabilities(trace), trajectory["capabilities"]))
    if "required_events" in trajectory:
        checks.append(
            _check_contains_all(
                "trajectory.required_events",
                _event_types(trace),
                trajectory["required_events"],
            )
        )
    if "routes" in trajectory:
        checks.append(_check_routes(trace, trajectory["routes"]))
    if "forbidden_routes" in trajectory:
        checks.append(_check_forbidden_routes(trace, trajectory["forbidden_routes"]))
    if "client_calls" in trajectory:
        checks.append(_check_client_calls(trace, trajectory["client_calls"]))
    if "client_call_counts" in trajectory:
        checks.append(_check_client_call_counts(trace, trajectory["client_call_counts"]))
    if "forbidden_capabilities" in trajectory:
        checks.append(_check_forbidden_capabilities(trace, trajectory["forbidden_capabilities"]))
    if "max_total_tokens" in trajectory:
        checks.append(_check_max_total_tokens(trace, trajectory["max_total_tokens"]))
    if "token_budget" in trajectory:
        checks.append(_check_token_budget(trace, trajectory["token_budget"]))
    if trajectory.get("no_failed_nodes") is True:
        checks.append(_check_no_failed_nodes(trace))
    return checks


def _check_equal(name: str, actual: Any, expected: Any) -> dict[str, Any]:
    passed = actual == expected
    return {
        "name": name,
        "passed": passed,
        "message": "matched" if passed else f"expected {expected!r}, got {actual!r}",
        "expected": expected,
        "actual": actual,
        "severity": "error",
        "evidence": [],
    }


def _check_contains_all(name: str, actual: list[Any], expected: Any) -> dict[str, Any]:
    expected_list = expected if isinstance(expected, list) else []
    missing = [item for item in expected_list if item not in actual]
    return {
        "name": name,
        "passed": not missing,
        "message": "matched" if not missing else f"missing: {missing!r}",
        "expected": expected_list,
        "actual": actual,
        "severity": "error",
        "evidence": [],
    }


def _check_ordered_subsequence(trace: Trace, expectations: Any) -> dict[str, Any]:
    failures = []
    actual_by_kind = {
        "node": _node_ids(trace),
        "event": _event_types(trace),
        "capability": _capabilities(trace),
    }
    for expectation in expectations if isinstance(expectations, list) else []:
        kind = expectation.get("kind") if isinstance(expectation, dict) else None
        expected_items = expectation.get("items", []) if isinstance(expectation, dict) else []
        actual_items = actual_by_kind.get(kind, [])
        if not _is_ordered_subsequence(actual_items, expected_items):
            failures.append({"kind": kind, "expected": expected_items, "actual": actual_items})
    return _result(
        "trajectory.ordered_subsequence",
        not failures,
        "matched" if not failures else f"ordered subsequence mismatches: {failures!r}",
        expectations if isinstance(expectations, list) else [],
        actual_by_kind,
        failures,
    )


def _check_must_happen_before(trace: Trace, expectations: Any) -> dict[str, Any]:
    failures = []
    actual_by_kind = {
        "node": _node_ids(trace),
        "event": _event_types(trace),
        "capability": _capabilities(trace),
    }
    for expectation in expectations if isinstance(expectations, list) else []:
        if not isinstance(expectation, dict):
            continue
        kind = expectation.get("kind")
        before = expectation.get("before")
        after = expectation.get("after")
        actual_items = actual_by_kind.get(kind, [])
        before_index = _index_of(actual_items, before)
        after_index = _index_of(actual_items, after)
        if before_index is None or after_index is None or before_index >= after_index:
            failures.append(
                {
                    "kind": kind,
                    "before": before,
                    "after": after,
                    "before_index": before_index,
                    "after_index": after_index,
                    "actual": actual_items,
                }
            )
    return _result(
        "trajectory.must_happen_before",
        not failures,
        "matched" if not failures else f"ordering violations: {failures!r}",
        expectations if isinstance(expectations, list) else [],
        actual_by_kind,
        failures,
    )


def _check_node_status(trace: Trace, expectations: Any) -> dict[str, Any]:
    nodes = {
        node.get("node_id"): node
        for node in trace.get("nodes", []) or []
        if isinstance(node, dict)
    }
    failures = []
    actual = []
    for expectation in expectations if isinstance(expectations, list) else []:
        if not isinstance(expectation, dict):
            continue
        node_id = expectation.get("node_id")
        node = nodes.get(node_id)
        status = node.get("status") if isinstance(node, dict) else None
        actual.append({"node_id": node_id, "status": status})
        if status != expectation.get("status"):
            failures.append(
                {
                    "node_id": node_id,
                    "capability": node.get("capability") if isinstance(node, dict) else None,
                    "expected_status": expectation.get("status"),
                    "actual_status": status,
                }
            )
    return _result(
        "trajectory.node_status",
        not failures,
        "matched" if not failures else f"node status mismatches: {failures!r}",
        expectations if isinstance(expectations, list) else [],
        actual,
        failures,
    )


def _check_routes(trace: Trace, expected: Any) -> dict[str, Any]:
    expected_routes = expected if isinstance(expected, list) else []
    actual_routes = [
        {
            "source_node": route.get("source_node"),
            "route_key": route.get("route_key"),
            "target_node": route.get("target_node"),
        }
        for route in trace.get("routes", []) or []
        if isinstance(route, dict)
    ]
    missing = [route for route in expected_routes if route not in actual_routes]
    return {
        "name": "trajectory.routes",
        "passed": not missing,
        "message": "matched" if not missing else f"missing routes: {missing!r}",
        "expected": expected_routes,
        "actual": actual_routes,
        "severity": "error",
        "evidence": missing,
    }


def _check_forbidden_routes(trace: Trace, forbidden: Any) -> dict[str, Any]:
    forbidden_routes = forbidden if isinstance(forbidden, list) else []
    actual_routes = [
        {
            "source_node": route.get("source_node"),
            "route_key": route.get("route_key"),
            "target_node": route.get("target_node"),
        }
        for route in trace.get("routes", []) or []
        if isinstance(route, dict)
    ]
    found = [
        {"route": actual_route}
        for actual_route in actual_routes
        if actual_route in forbidden_routes
    ]
    return _result(
        "trajectory.forbidden_routes",
        not found,
        "matched" if not found else f"forbidden routes used: {found!r}",
        forbidden_routes,
        actual_routes,
        found,
    )


def _check_client_calls(trace: Trace, expected: Any) -> dict[str, Any]:
    expected_calls = expected if isinstance(expected, list) else []
    actual_calls = [_client_call_signature(call) for call in trace.get("client_calls", []) or [] if isinstance(call, dict)]
    missing = [
        expected_call
        for expected_call in expected_calls
        if not any(_dict_contains(actual_call, expected_call) for actual_call in actual_calls)
    ]
    return {
        "name": "trajectory.client_calls",
        "passed": not missing,
        "message": "matched" if not missing else f"missing client calls: {missing!r}",
        "expected": expected_calls,
        "actual": actual_calls,
        "severity": "error",
        "evidence": missing,
    }


def _check_client_call_counts(trace: Trace, expectations: Any) -> dict[str, Any]:
    actual_calls = [_client_call_signature(call) for call in trace.get("client_calls", []) or [] if isinstance(call, dict)]
    failures = []
    actual_counts = []
    for expectation in expectations if isinstance(expectations, list) else []:
        if not isinstance(expectation, dict):
            continue
        filters = {
            key: expectation[key]
            for key in ("instruction_id", "type", "node_id", "status", "ok", "exit_code")
            if key in expectation
        }
        count = sum(1 for call in actual_calls if _dict_contains(call, filters))
        actual_counts.append({"filters": filters, "count": count})
        if "exact" in expectation and count != expectation["exact"]:
            failures.append({"filters": filters, "expected": {"exact": expectation["exact"]}, "actual": count})
        if "min" in expectation and count < expectation["min"]:
            failures.append({"filters": filters, "expected": {"min": expectation["min"]}, "actual": count})
        if "max" in expectation and count > expectation["max"]:
            failures.append({"filters": filters, "expected": {"max": expectation["max"]}, "actual": count})
    return _result(
        "trajectory.client_call_counts",
        not failures,
        "matched" if not failures else f"client call count mismatches: {failures!r}",
        expectations if isinstance(expectations, list) else [],
        actual_counts,
        failures,
    )


def _check_forbidden_capabilities(trace: Trace, forbidden: Any) -> dict[str, Any]:
    forbidden_set = set(forbidden if isinstance(forbidden, list) else [])
    actual = _capabilities(trace)
    found = [capability for capability in actual if capability in forbidden_set]
    return {
        "name": "trajectory.forbidden_capabilities",
        "passed": not found,
        "message": "matched" if not found else f"forbidden capabilities used: {found!r}",
        "expected": sorted(forbidden_set),
        "actual": actual,
        "severity": "error",
        "evidence": [{"capability": capability} for capability in found],
    }


def _check_max_total_tokens(trace: Trace, expected: Any) -> dict[str, Any]:
    max_tokens = expected if isinstance(expected, int) else 0
    actual = _total_tokens(trace)
    passed = actual <= max_tokens
    return {
        "name": "trajectory.max_total_tokens",
        "passed": passed,
        "message": "matched" if passed else f"total tokens {actual} exceeded {max_tokens}",
        "expected": max_tokens,
        "actual": actual,
        "severity": "error",
        "evidence": [],
    }


def _check_token_budget(trace: Trace, budget: Any) -> dict[str, Any]:
    if not isinstance(budget, dict):
        return _result("trajectory.token_budget", False, "token budget must be an object", {}, {}, [])
    failures = []
    actual: dict[str, Any] = {"total": _total_tokens(trace), "by_node": {}, "by_capability": {}}
    if "total" in budget and actual["total"] > budget["total"]:
        failures.append({"scope": "total", "expected_max": budget["total"], "actual": actual["total"]})

    steps = trace.get("token_usage", {}).get("steps", []) if isinstance(trace.get("token_usage"), dict) else []
    if not isinstance(steps, list):
        steps = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        amount = _step_tokens(step)
        node_id = step.get("node_id")
        capability = step.get("capability")
        if isinstance(node_id, str):
            actual["by_node"][node_id] = actual["by_node"].get(node_id, 0) + amount
        if isinstance(capability, str):
            actual["by_capability"][capability] = actual["by_capability"].get(capability, 0) + amount

    for item in budget.get("by_node", []) or []:
        node_id = item.get("node_id") if isinstance(item, dict) else None
        max_tokens = item.get("max") if isinstance(item, dict) else None
        if node_id not in actual["by_node"]:
            failures.append({"scope": "node", "node_id": node_id, "message": "missing token usage for node"})
        elif actual["by_node"][node_id] > max_tokens:
            failures.append({"scope": "node", "node_id": node_id, "expected_max": max_tokens, "actual": actual["by_node"][node_id]})
    for item in budget.get("by_capability", []) or []:
        capability = item.get("capability") if isinstance(item, dict) else None
        max_tokens = item.get("max") if isinstance(item, dict) else None
        if capability not in actual["by_capability"]:
            failures.append({"scope": "capability", "capability": capability, "message": "missing token usage for capability"})
        elif actual["by_capability"][capability] > max_tokens:
            failures.append(
                {
                    "scope": "capability",
                    "capability": capability,
                    "expected_max": max_tokens,
                    "actual": actual["by_capability"][capability],
                }
            )
    return _result(
        "trajectory.token_budget",
        not failures,
        "matched" if not failures else f"token budget violations: {failures!r}",
        budget,
        actual,
        failures,
    )


def _check_no_failed_nodes(trace: Trace) -> dict[str, Any]:
    failed = [
        {"node_id": node.get("node_id"), "status": node.get("status")}
        for node in trace.get("nodes", []) or []
        if isinstance(node, dict) and node.get("status") == "failed"
    ]
    return {
        "name": "trajectory.no_failed_nodes",
        "passed": not failed,
        "message": "matched" if not failed else f"failed nodes: {failed!r}",
        "expected": [],
        "actual": failed,
        "severity": "error",
        "evidence": failed,
    }


def _policy_checks(trace: Trace, policy: dict[str, Any]) -> list[dict[str, Any]]:
    catalog = capability_catalog_module.load_catalog()
    entries = capability_catalog_module.entry_by_name(catalog)
    used_capabilities = _used_capabilities(trace)
    checks: list[dict[str, Any]] = []

    unknown = [
        {"node_id": item["node_id"], "capability": item["capability"]}
        for item in used_capabilities
        if item["capability"] not in entries
    ]
    if unknown:
        checks.append(_result("policy.catalog", False, f"capabilities missing from catalog: {unknown!r}", [], [], unknown))
        return checks

    if policy.get("forbidden_destructive") is True:
        found = [
            _catalog_evidence(item, entries[item["capability"]])
            for item in used_capabilities
            if entries[item["capability"]].get("destructive") is True
        ]
        checks.append(
            _result(
                "policy.forbidden_destructive",
                not found,
                "matched" if not found else f"destructive capabilities used: {found!r}",
                False,
                found,
                found,
            )
        )

    if "forbidden_capabilities" in policy:
        checks.append(_check_policy_forbidden_capabilities(used_capabilities, policy["forbidden_capabilities"]))

    if "required_permissions" in policy:
        required = set(policy["required_permissions"])
        missing = [
            _catalog_evidence(item, entries[item["capability"]], missing_permissions=sorted(required - set(entries[item["capability"]].get("permissions", []))))
            for item in used_capabilities
            if not required.issubset(set(entries[item["capability"]].get("permissions", [])))
        ]
        checks.append(
            _result(
                "policy.required_permissions",
                not missing,
                "matched" if not missing else f"required permissions missing: {missing!r}",
                sorted(required),
                [],
                missing,
            )
        )

    if "forbidden_permissions" in policy:
        forbidden = set(policy["forbidden_permissions"])
        found = []
        for item in used_capabilities:
            entry = entries[item["capability"]]
            permissions = set(entry.get("permissions", []))
            overlap = sorted(permissions & forbidden)
            if overlap:
                found.append(_catalog_evidence(item, entry, forbidden_permissions=overlap))
        checks.append(
            _result(
                "policy.forbidden_permissions",
                not found,
                "matched" if not found else f"forbidden permissions used: {found!r}",
                sorted(forbidden),
                found,
                found,
            )
        )

    if "allowed_error_codes" in policy:
        allowed = set(policy["allowed_error_codes"])
        error_codes = _trace_error_codes(trace)
        unexpected = [code for code in error_codes if code not in allowed]
        checks.append(
            _result(
                "policy.allowed_error_codes",
                not unexpected,
                "matched" if not unexpected else f"unexpected error codes: {unexpected!r}",
                sorted(allowed),
                error_codes,
                [{"error_code": code} for code in unexpected],
            )
        )
    return checks


def _check_policy_forbidden_capabilities(used_capabilities: list[dict[str, Any]], forbidden: Any) -> dict[str, Any]:
    forbidden_set = set(forbidden if isinstance(forbidden, list) else [])
    found = [
        {"node_id": item["node_id"], "capability": item["capability"]}
        for item in used_capabilities
        if item["capability"] in forbidden_set
    ]
    return _result(
        "policy.forbidden_capabilities",
        not found,
        "matched" if not found else f"forbidden capabilities used: {found!r}",
        sorted(forbidden_set),
        [item["capability"] for item in used_capabilities],
        found,
    )


def _golden_check(trace: Trace, golden_trace: Trace) -> dict[str, Any]:
    actual = normalize_trace_trajectory(trace)
    expected = normalize_trace_trajectory(golden_trace)
    if actual == expected:
        return {
            "name": "golden.trajectory",
            "passed": True,
            "message": "matched",
            "expected": expected,
            "actual": actual,
            "severity": "error",
            "evidence": [],
        }
    differing = [key for key in sorted(set(actual) | set(expected)) if actual.get(key) != expected.get(key)]
    return {
        "name": "golden.trajectory",
        "passed": False,
        "message": f"normalized trajectory differs in: {', '.join(differing)}",
        "expected": expected,
        "actual": actual,
        "severity": "error",
        "evidence": [{"field": key} for key in differing],
    }


def normalize_trace_trajectory(trace: Trace) -> dict[str, Any]:
    return {
        "status": trace.get("status"),
        "nodes": [
            {
                "node_id": node.get("node_id"),
                "capability": node.get("capability"),
                "status": node.get("status"),
                "route_key": node.get("route_key"),
                "client_call_ids": node.get("client_call_ids", []),
            }
            for node in trace.get("nodes", []) or []
            if isinstance(node, dict)
        ],
        "routes": [
            {
                "source_node": route.get("source_node"),
                "route_key": route.get("route_key"),
                "target_node": route.get("target_node"),
            }
            for route in trace.get("routes", []) or []
            if isinstance(route, dict)
        ],
        "client_calls": [
            _client_call_signature(call)
            for call in trace.get("client_calls", []) or []
            if isinstance(call, dict)
        ],
        "token_usage": trace.get("token_usage", {}).get("totals", {}) if isinstance(trace.get("token_usage"), dict) else {},
        "failure_summary": trace.get("failure_summary"),
    }


def _client_call_signature(call: dict[str, Any]) -> dict[str, Any]:
    result = call.get("result") if isinstance(call.get("result"), dict) else {}
    return {
        "instruction_id": call.get("instruction_id"),
        "type": call.get("type"),
        "node_id": call.get("node_id"),
        "status": call.get("status"),
        "ok": result.get("ok"),
        "exit_code": result.get("exit_code"),
    }


def _used_capabilities(trace: Trace) -> list[dict[str, Any]]:
    return [
        {"node_id": node.get("node_id"), "capability": node.get("capability")}
        for node in trace.get("nodes", []) or []
        if isinstance(node, dict) and isinstance(node.get("capability"), str)
    ]


def _node_ids(trace: Trace) -> list[Any]:
    return [node.get("node_id") for node in trace.get("nodes", []) or [] if isinstance(node, dict)]


def _capabilities(trace: Trace) -> list[Any]:
    return [node.get("capability") for node in trace.get("nodes", []) or [] if isinstance(node, dict)]


def _event_types(trace: Trace) -> list[Any]:
    return [event.get("type") for event in trace.get("events", []) or [] if isinstance(event, dict)]


def _total_tokens(trace: Trace) -> int:
    token_usage = trace.get("token_usage")
    if not isinstance(token_usage, dict):
        return 0
    totals = token_usage.get("totals")
    if not isinstance(totals, dict):
        return 0
    value = totals.get("total_tokens")
    return value if isinstance(value, int) else 0


def _step_tokens(step: dict[str, Any]) -> int:
    for key in ("total_tokens", "tokens"):
        value = step.get(key)
        if isinstance(value, int):
            return value
    input_tokens = step.get("input_tokens")
    output_tokens = step.get("output_tokens")
    total = 0
    if isinstance(input_tokens, int):
        total += input_tokens
    if isinstance(output_tokens, int):
        total += output_tokens
    return total


def _dict_contains(actual: dict[str, Any], expected: dict[str, Any]) -> bool:
    return all(actual.get(key) == value for key, value in expected.items())


def _is_ordered_subsequence(actual: list[Any], expected: Any) -> bool:
    expected_items = expected if isinstance(expected, list) else []
    cursor = 0
    for item in actual:
        if cursor < len(expected_items) and item == expected_items[cursor]:
            cursor += 1
    return cursor == len(expected_items)


def _index_of(items: list[Any], value: Any) -> int | None:
    try:
        return items.index(value)
    except ValueError:
        return None


def _catalog_evidence(
    used: dict[str, Any],
    entry: dict[str, Any],
    **extra: Any,
) -> dict[str, Any]:
    evidence = {
        "node_id": used.get("node_id"),
        "capability": used.get("capability"),
        "catalog": {
            "destructive": entry.get("destructive"),
            "permissions": entry.get("permissions", []),
            "error_codes": entry.get("error_codes", []),
        },
    }
    evidence.update(extra)
    return evidence


def _trace_error_codes(trace: Trace) -> list[str]:
    codes: list[str] = []
    failure_summary = trace.get("failure_summary")
    if isinstance(failure_summary, dict):
        _append_error_code(codes, failure_summary)
    for node in trace.get("nodes", []) or []:
        if not isinstance(node, dict):
            continue
        _append_error_code(codes, node)
        for signal in node.get("failure_signals", []) or []:
            if isinstance(signal, dict):
                _append_error_code(codes, signal)
    return codes


def _append_error_code(codes: list[str], payload: dict[str, Any]) -> None:
    value = payload.get("error_code") or payload.get("code")
    if isinstance(value, str) and value:
        codes.append(value)


def _result(
    name: str,
    passed: bool,
    message: str,
    expected: Any,
    actual: Any,
    evidence: list[Any],
    *,
    severity: str = "error",
) -> dict[str, Any]:
    return {
        "name": name,
        "passed": passed,
        "message": message,
        "expected": expected,
        "actual": actual,
        "severity": severity,
        "evidence": evidence,
    }


def _spec_summary(spec: EvalSpec, has_golden_trace: bool) -> dict[str, Any]:
    trajectory = spec.get("trajectory") if isinstance(spec, dict) else None
    trajectory_keys = sorted(trajectory) if isinstance(trajectory, dict) else []
    return {
        "version": spec.get("version") if isinstance(spec, dict) else None,
        "trajectory_keys": trajectory_keys,
        "has_golden_trace": has_golden_trace,
    }


def _string(value: Any) -> str | None:
    return value if isinstance(value, str) and value else None


def _utc_now() -> str:
    return datetime.datetime.now(datetime.UTC).isoformat()
