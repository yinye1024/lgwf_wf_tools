from typing import Any


def human_approval_action(request: dict[str, Any]) -> dict[str, Any]:
    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("human approval request_id must be a non-empty string.")
    return {
        "type": "human_approval",
        "request_id": request_id,
        "prompt": request.get("prompt"),
        "context": request.get("context"),
        "allowed_responses": ["approve", "reject"],
    }


def human_review_action(request: dict[str, Any]) -> dict[str, Any]:
    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("human review request_id must be a non-empty string.")
    options = request.get("options", ["approve", "revise", "reject"])
    if not isinstance(options, list) or not all(isinstance(option, str) for option in options):
        options = ["approve", "revise", "reject"]
    action = {
        "type": "human_review",
        "request_id": request_id,
        "prompt": request.get("prompt"),
        "context": request.get("context"),
        "options": options,
        "allowed_responses": options,
    }
    option_labels = request.get("option_labels")
    if isinstance(option_labels, dict) and all(
        isinstance(key, str) and isinstance(value, str)
        for key, value in option_labels.items()
    ):
        action["option_labels"] = option_labels
    return action


def agent_handoff_action(action: dict[str, Any]) -> dict[str, Any]:
    request_id = action.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("agent handoff request_id must be a non-empty string.")
    return dict(action)
