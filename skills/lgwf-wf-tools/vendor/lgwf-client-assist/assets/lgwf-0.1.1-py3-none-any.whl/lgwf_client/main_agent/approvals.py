import datetime
import pathlib
from typing import Any

import lgwf.human_approval as human_approval_module
import lgwf_tools.file_ops as file_ops_module
import lgwf_tools.workspace_layout as workspace_layout_module


MISSING = object()


def submit_main_agent_approval(
    work_dir: str | pathlib.Path,
    request_id: str,
    *,
    decision: str,
    value: Any = MISSING,
    comment: str | None = None,
) -> dict[str, Any]:
    root = pathlib.Path(work_dir).expanduser().resolve()
    approval_root = _approval_root(root, request_id)
    payload = _controller_payload(
        request_id=request_id,
        decision=decision,
        value=value,
        comment=comment,
    )
    human_approval_module.write_controller_payload(approval_root, request_id, payload)
    response_path = human_approval_module.submit_controller_payload(approval_root, request_id, final_user_confirmed=True)
    return {
        "ok": True,
        "request_id": request_id,
        "response_path": str(response_path),
        "work_dir": str(approval_root),
    }


def _controller_payload(
    *,
    request_id: str,
    decision: str,
    value: Any,
    comment: str | None,
) -> dict[str, Any]:
    if decision not in {"approve", "reject"}:
        raise ValueError("decision must be approve or reject.")
    if decision == "approve" and value is MISSING:
        raise ValueError("approve requires value-json.")
    if decision == "reject" and (comment is None or not comment.strip()):
        raise ValueError("reject requires comment.")

    payload: dict[str, Any] = {
        "request_id": request_id,
        "decision": decision,
        "created_by": "main_agent_ask",
        "created_at": datetime.datetime.now(datetime.UTC).isoformat(),
    }
    if value is not MISSING:
        payload["value"] = value
    if comment is not None:
        payload["comment"] = comment
    return payload


def _approval_root(root: pathlib.Path, request_id: str) -> pathlib.Path:
    try:
        human_approval_module.load_request(root, request_id)
        return root
    except Exception:
        pass
    child_root = _child_approval_root(root, request_id)
    if child_root is not None:
        return child_root
    return root


def _child_approval_root(root: pathlib.Path, request_id: str) -> pathlib.Path | None:
    child_dir = workspace_layout_module.child_runs_dir(root)
    if not child_dir.is_dir():
        return None
    for record_path in sorted(child_dir.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True):
        try:
            record = file_ops_module.read_json(record_path)
        except (OSError, ValueError, file_ops_module.FileOperationError):
            continue
        if not isinstance(record, dict):
            continue
        work_dir = record.get("work_dir")
        if not isinstance(work_dir, str) or not work_dir:
            continue
        child_root = pathlib.Path(work_dir).expanduser().resolve()
        try:
            human_approval_module.load_request(child_root, request_id)
            return child_root
        except Exception:
            continue
    return None
