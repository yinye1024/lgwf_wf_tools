﻿import argparse
import pathlib
import time
from typing import Any

import lgwf_client.file_ops as file_ops_module
import lgwf_client.workspace_layout as workspace_layout_module
import lgwf_client.codex_config as codex_config_module
import lgwf_client.commands.common as command_common_module


def add_parsers(subparsers: argparse._SubParsersAction) -> None:
    codex = subparsers.add_parser("codex")
    codex_subparsers = codex.add_subparsers(dest="codex_command", required=True)
    codex_model = codex_subparsers.add_parser("model")
    codex_model_subparsers = codex_model.add_subparsers(dest="model_command", required=True)
    codex_model_get = codex_model_subparsers.add_parser("get")
    codex_model_get.add_argument("--work-dir", required=True)
    codex_model_get.set_defaults(handler=handle_codex)
    codex_model_set = codex_model_subparsers.add_parser("set")
    codex_model_set.add_argument("--work-dir", required=True)
    codex_model_set.add_argument("--model", required=True)
    codex_model_set.set_defaults(handler=handle_codex)
    codex_model_reset = codex_model_subparsers.add_parser("reset")
    codex_model_reset.add_argument("--work-dir", required=True)
    codex_model_reset.set_defaults(handler=handle_codex)

    codex_token_limit = codex_subparsers.add_parser("token-limit")
    codex_token_limit_subparsers = codex_token_limit.add_subparsers(dest="token_limit_command", required=True)
    codex_token_limit_get = codex_token_limit_subparsers.add_parser("get")
    codex_token_limit_get.add_argument("--work-dir", required=True)
    codex_token_limit_get.set_defaults(handler=handle_codex)
    codex_token_limit_set = codex_token_limit_subparsers.add_parser("set")
    codex_token_limit_set.add_argument("--work-dir", required=True)
    codex_token_limit_set.add_argument("--token-max", type=command_common_module.positive_int, required=True)
    codex_token_limit_set.add_argument("--on-token-limit", choices=["warn", "fail"], default="fail")
    codex_token_limit_set.set_defaults(handler=handle_codex)
    codex_token_limit_reset = codex_token_limit_subparsers.add_parser("reset")
    codex_token_limit_reset.add_argument("--work-dir", required=True)
    codex_token_limit_reset.set_defaults(handler=handle_codex)

    codex_token_status = codex_subparsers.add_parser("token-status")
    codex_token_status.add_argument("--work-dir", required=True)
    codex_token_status.add_argument("--limit", type=command_common_module.positive_int, default=5)
    codex_token_status.add_argument("--token-max", type=command_common_module.positive_int)
    codex_token_status.add_argument("--stale-seconds", type=command_common_module.positive_int, default=300)
    codex_token_status.set_defaults(handler=handle_codex)


def handle_codex(args: argparse.Namespace) -> dict[str, Any]:
    if args.codex_command == "model":
        work_dir = command_common_module.resolve_work_dir(args.work_dir)
        if args.model_command == "get":
            return codex_config_module.get_codex_model(work_dir)
        if args.model_command == "set":
            return codex_config_module.set_codex_model(work_dir, args.model)
        if args.model_command == "reset":
            return codex_config_module.reset_codex_model(work_dir)
        raise ValueError(f"Unknown codex model command: {args.model_command}")
    if args.codex_command == "token-limit":
        work_dir = command_common_module.resolve_work_dir(args.work_dir)
        if args.token_limit_command == "get":
            return codex_config_module.get_codex_token_limit(work_dir)
        if args.token_limit_command == "set":
            return codex_config_module.set_codex_token_limit(
                work_dir,
                token_max=args.token_max,
                on_token_limit=args.on_token_limit,
            )
        if args.token_limit_command == "reset":
            return codex_config_module.reset_codex_token_limit(work_dir)
        raise ValueError(f"Unknown codex token-limit command: {args.token_limit_command}")
    if args.codex_command == "token-status":
        return codex_token_status(
            command_common_module.resolve_work_dir(args.work_dir),
            limit=args.limit,
            token_max=args.token_max,
            stale_seconds=args.stale_seconds,
        )
    raise ValueError(f"Unknown codex command: {args.codex_command}")


def codex_token_status(
    work_dir: pathlib.Path,
    *,
    limit: int,
    token_max: int | None,
    stale_seconds: int,
) -> dict[str, Any]:
    del limit
    status_path = workspace_layout_module.codex_status_path(work_dir)
    status = read_json_object(status_path)
    token_usage = normalize_token_usage(status.get("token_usage", {}))
    configured_limit = codex_config_module.get_codex_token_limit(work_dir)
    effective_token_max = token_max if token_max is not None else configured_limit["token_max"]
    updated_at_unix = non_negative_float(status.get("updated_at_unix"))
    seconds_since_update = seconds_since_update_from(updated_at_unix)
    over_token_limit = effective_token_max is not None and token_usage["total_tokens"] > effective_token_max
    return {
        "work_dir": str(work_dir.resolve()),
        "status_file": str(status_path),
        "available": bool(status),
        "status": status.get("status") if status else "unavailable",
        "current_instruction_id": status.get("current_instruction_id"),
        "track_dir": status.get("track_dir"),
        "turn_count": non_negative_int(status.get("turn_count")),
        "token_usage": token_usage,
        "updated_at_unix": updated_at_unix or None,
        "token_max": effective_token_max,
        "token_limit_source": "argument" if token_max is not None else configured_limit["source"],
        "on_token_limit": configured_limit["on_token_limit"],
        "over_token_limit": over_token_limit,
        "health": codex_live_token_health(status, seconds_since_update, stale_seconds),
    }


def codex_live_token_health(
    status: dict[str, Any],
    seconds_since_update: float | None,
    stale_seconds: int,
) -> dict[str, Any]:
    raw_status = status.get("status") if status else None
    stale = (
        raw_status == "running"
        and isinstance(seconds_since_update, int | float)
        and seconds_since_update > stale_seconds
    )
    if not status:
        phase = "unavailable"
    elif stale:
        phase = "stale"
    else:
        phase = str(raw_status or "unknown")
    return {
        "phase": phase,
        "stale": stale,
        "stale_seconds": stale_seconds,
        "seconds_since_update": seconds_since_update,
    }


def normalize_token_usage(usage: dict[str, Any]) -> dict[str, int]:
    normalized = {
        "input_tokens": non_negative_int(usage.get("input_tokens") or usage.get("prompt_tokens")),
        "output_tokens": non_negative_int(usage.get("output_tokens") or usage.get("completion_tokens")),
        "total_tokens": non_negative_int(usage.get("total_tokens") or usage.get("total")),
        "cached_input_tokens": non_negative_int(usage.get("cached_input_tokens") or usage.get("cached_tokens")),
        "reasoning_output_tokens": non_negative_int(
            usage.get("reasoning_output_tokens") or usage.get("reasoning_tokens")
        ),
    }
    if normalized["total_tokens"] == 0:
        normalized["total_tokens"] = normalized["input_tokens"] + normalized["output_tokens"]
    return normalized


def read_json_object(path: pathlib.Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        data = file_ops_module.read_json(path)
    except file_ops_module.FileOperationError:
        return {}
    return data if isinstance(data, dict) else {}


def seconds_since_update_from(updated_at_unix: float) -> float | None:
    if updated_at_unix <= 0:
        return None
    return max(time.time() - updated_at_unix, 0.0)


def non_negative_int(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, int | float):
        return max(int(value), 0)
    if isinstance(value, str):
        cleaned = value.replace(",", "").strip()
        if cleaned.isdigit():
            return int(cleaned)
    return 0


def non_negative_float(value: Any) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, int | float):
        return max(float(value), 0.0)
    if isinstance(value, str):
        try:
            return max(float(value), 0.0)
        except ValueError:
            return 0.0
    return 0.0
