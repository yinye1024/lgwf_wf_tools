from collections.abc import Iterable
import pathlib
from pathlib import PurePosixPath

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module
import lgwf_dsl.parser as parser_module
import lgwf_dsl.validator as validator_module


class WorkflowLinter:
    """Authoring-time checks for workflow contracts that are legal but risky."""

    def __init__(self, package_root: str | pathlib.Path | None = None) -> None:
        self.package_root = pathlib.Path(package_root).resolve() if package_root is not None else None
        self._visited_workflows: set[pathlib.Path] = set()

    def lint(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        previous_source_dir = getattr(self, "_current_source_dir", None)
        self._current_source_dir = self._source_dir_for_ast(ast)
        source_path = pathlib.Path(ast.source_name).expanduser().resolve() if ast.source_name is not None else None
        if source_path is not None and source_path in self._visited_workflows:
            return []
        if source_path is not None:
            self._visited_workflows.add(source_path)
        try:
            context_sets = self._context_sets(ast)
            defaults = self._defaults(ast)
            diagnostics: list[diagnostics_module.Diagnostic] = []
            diagnostics.extend(self._lint_authoring_resources(ast, context_sets))
            for statement in ast.statements:
                if isinstance(statement, ast_module.ReactDecl):
                    diagnostics.extend(self._lint_react_observe_scope(statement, context_sets))
                    diagnostics.extend(self._lint_react_observe_feedback_loop(statement, context_sets))
                elif isinstance(statement, ast_module.ParallelDecl):
                    diagnostics.extend(self._lint_parallel_contexts(statement, context_sets))
            diagnostics.extend(self._lint_approval_routes(ast))
            diagnostics.extend(self._lint_run_workflow_handoffs(ast, defaults))
            return diagnostics
        finally:
            self._current_source_dir = previous_source_dir

    def _lint_authoring_resources(
        self,
        ast: ast_module.WorkflowAst,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        if ast.source_name is None and self.package_root is None:
            return []

        defaults = self._defaults(ast)
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            diagnostics.extend(self._lint_statement_resources(statement, defaults, context_sets))
        return diagnostics

    def _lint_statement_resources(
        self,
        statement: ast_module.StatementDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        if isinstance(statement, ast_module.PythonDecl):
            missing = self._missing_task_resource(statement.script_path, "SCRIPT", defaults, statement.location)
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.CodexDecl):
            diagnostics = [self._missing_task_resource(statement.prompt_path, "PROMPT", defaults, statement.location)]
            diagnostics.extend(self._lint_context_resources(statement.contexts, context_sets))
            return [diagnostic for diagnostic in diagnostics if diagnostic is not None]
        if isinstance(statement, ast_module.ApprovalDecl) and statement.prompt_ref_path is not None:
            missing = self._missing_workflow_resource(
                statement.prompt_ref_path,
                "PROMPT_REF",
                statement.location,
            )
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.ReviewDecl):
            missing = self._missing_workflow_resource(
                statement.prompt_ref_path,
                "PROMPT",
                statement.location,
            )
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.ReactDecl):
            diagnostics: list[diagnostics_module.Diagnostic] = []
            if statement.spec_path is not None:
                missing = self._missing_task_resource(
                    statement.spec_path,
                    "SPEC",
                    defaults,
                    statement.location,
                )
                if missing is not None:
                    diagnostics.append(missing)
            for slot in statement.slots.values():
                diagnostics.extend(self._lint_statement_resources(slot.task, defaults, context_sets))
            return diagnostics
        if isinstance(statement, ast_module.AgentLoopDecl):
            diagnostics = []
            diagnostics.extend(self._lint_context_resources(statement.contexts, context_sets))
            for slot in statement.slots.values():
                diagnostics.extend(self._lint_statement_resources(slot.task, defaults, context_sets))
            return diagnostics
        if isinstance(statement, ast_module.WorkflowRefDecl):
            missing = self._missing_workflow_ref(statement.workflow_path, statement.location)
            if missing is not None:
                return [missing]
            return self._lint_child_workflow(statement)
        if isinstance(statement, ast_module.RunWorkflowDecl):
            diagnostics = []
            invalid_work_dir = self._invalid_run_workflow_work_dir(statement)
            if invalid_work_dir is not None:
                diagnostics.append(invalid_work_dir)
            missing = self._missing_external_workflow(statement.workflow_path, statement.location)
            if missing is not None:
                diagnostics.append(missing)
            return diagnostics
        if isinstance(statement, ast_module.ParallelDecl):
            diagnostics = []
            for step in statement.steps:
                diagnostics.extend(self._lint_statement_resources(step.task, defaults, context_sets))
            return diagnostics
        return []

    def _lint_context_resources(
        self,
        contexts: Iterable[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for context in contexts:
            resources: list[ast_module.ResourceRef] = []
            if context.resource is not None:
                resources.append(context.resource)
            elif context.context_set is not None and context.context_set in context_sets:
                resources.extend(context_sets[context.context_set].resources)
            for resource in resources:
                if resource.root != "workflow":
                    continue
                missing = self._missing_workflow_resource(resource.path, f"CONTEXT workflow {resource.type}", resource.location)
                if missing is not None:
                    diagnostics.append(missing)
        return diagnostics

    def _defaults(self, ast: ast_module.WorkflowAst) -> ast_module.DefaultsDecl:
        defaults = ast_module.DefaultsDecl()
        for statement in ast.statements:
            if isinstance(statement, ast_module.DefaultsDecl):
                defaults = statement
        return defaults

    def _missing_task_resource(
        self,
        raw_path: str,
        label: str,
        defaults: ast_module.DefaultsDecl,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        root = defaults.ref_root.get("root", "workflow")
        if root != "workflow":
            return None
        ref_root_path = defaults.ref_root.get("path", ".")
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved_base = self._resolve_relative(base_dir, ref_root_path)
        if resolved_base is None:
            return self._resource_diagnostic(ref_root_path, "ref_root", location, "ref_root path must be relative and stay inside the workflow package.")
        resolved = self._resolve_relative(resolved_base, raw_path)
        if resolved is None or not resolved.is_file():
            return self._resource_diagnostic(raw_path, label, location, f"Create the {label} file or update its path to an existing workflow package file.")
        return None

    def _missing_workflow_resource(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved = self._resolve_relative(base_dir, raw_path)
        if resolved is None:
            return self._resource_diagnostic(raw_path, label, location, "Use a relative path inside the workflow package.")
        if not resolved.exists():
            return self._resource_diagnostic(raw_path, label, location, f"Create the referenced {label} resource or update the path.")
        return None

    def _missing_workflow_ref(
        self,
        raw_path: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved = self._resolve_relative(base_dir, raw_path)
        if resolved is None or pathlib.PurePath(raw_path).suffix.lower() != ".lgwf" or not resolved.is_file():
            return self._resource_diagnostic(raw_path, "STEP WORKFLOW", location, "Point STEP WORKFLOW at an existing relative .lgwf file inside the workflow package.")
        return None

    def _missing_external_workflow(
        self,
        raw_path: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        path = pathlib.Path(raw_path)
        if path.is_absolute() or ".." in path.parts or path.suffix.lower() != ".lgwf":
            return self._resource_diagnostic(
                raw_path,
                "RUN_WORKFLOW WORKFLOW",
                location,
                "Use a relative path to an existing child workflow.lgwf file.",
            )
        if not path.resolve().is_file():
            return self._resource_diagnostic(
                raw_path,
                "RUN_WORKFLOW WORKFLOW",
                location,
                "Create the child workflow.lgwf file or update RUN_WORKFLOW WORKFLOW.",
            )
        return None

    def _invalid_run_workflow_work_dir(
        self,
        statement: ast_module.RunWorkflowDecl,
    ) -> diagnostics_module.Diagnostic | None:
        path = pathlib.Path(statement.work_dir)
        if not path.is_absolute() and ".." not in path.parts:
            return None
        return diagnostics_module.Diagnostic(
            f"RUN_WORKFLOW WORK_DIR path is invalid: {statement.work_dir}",
            statement.location,
            severity="error",
            code="LGWF_RUN_WORKFLOW_WORK_DIR_INVALID",
            suggestion="Use a relative WORK_DIR path without '..'. The child workflow owns that work_dir runtime state.",
        )

    def _resolve_relative(self, base_dir: pathlib.Path, raw_path: str) -> pathlib.Path | None:
        path = pathlib.Path(raw_path)
        if path.is_absolute() or ".." in path.parts:
            return None
        resolved = (base_dir / path).resolve()
        if self.package_root is not None and not resolved.is_relative_to(self.package_root):
            return None
        return resolved

    def _source_dir(self) -> pathlib.Path | None:
        return getattr(self, "_current_source_dir", None)

    def _source_dir_for_ast(self, ast: ast_module.WorkflowAst) -> pathlib.Path | None:
        if self.package_root is None:
            return None
        if ast.source_name is not None:
            return pathlib.Path(ast.source_name).expanduser().resolve().parent
        return self.package_root

    def _lint_child_workflow(self, ref: ast_module.WorkflowRefDecl) -> list[diagnostics_module.Diagnostic]:
        base_dir = self._source_dir()
        if base_dir is None:
            return []
        child_path = self._resolve_relative(base_dir, ref.workflow_path)
        if child_path is None or not child_path.is_file():
            return []
        source = child_path.read_text(encoding="utf-8")
        child_ast = parser_module.Parser.from_text(source, source_name=str(child_path)).parse_workflow()
        validator_module.WorkflowValidator().validate(child_ast)
        return self.lint(child_ast)

    def _lint_run_workflow_handoffs(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        run_workflows = [
            statement
            for statement in ast.statements
            if isinstance(statement, ast_module.RunWorkflowDecl)
        ]
        if not run_workflows:
            return []

        diagnostics: list[diagnostics_module.Diagnostic] = []
        diagnostics.extend(self._lint_reused_run_workflow_work_dirs(run_workflows))
        diagnostics.extend(self._lint_run_workflow_state_links(ast, run_workflows))
        diagnostics.extend(self._lint_python_child_runs_data_channel(ast, defaults))
        return diagnostics

    def _lint_approval_routes(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        approval_locations = {
            statement.id: statement.location
            for statement in ast.statements
            if isinstance(statement, ast_module.ApprovalDecl) and statement.route_on_decision
        }
        if not approval_locations:
            return []
        diagnostics: list[diagnostics_module.Diagnostic] = []
        allowed = {"approve", "reject"}
        for statement in ast.statements:
            if not isinstance(statement, ast_module.RouteDecl):
                continue
            if statement.from_node not in approval_locations:
                continue
            invalid = sorted(key for key in statement.branches if key not in allowed)
            if not invalid:
                continue
            node_id = statement.from_node
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"APPROVAL {node_id} uses non-binary route keys: {', '.join(invalid)}. APPROVAL route keys must be approve/reject only.",
                    statement.location or approval_locations[node_id],
                    severity="error",
                    code="LGWF_APPROVAL_NON_BINARY_ROUTE",
                    suggestion=(
                        "Use REVIEW ... OPTIONS [\"approve\", \"revise\", \"reject\"] for review/revise flows, "
                        "or keep APPROVAL routes limited to approve/reject and move business branching into a downstream node."
                    ),
                )
            )
        return diagnostics

    def _lint_reused_run_workflow_work_dirs(
        self,
        run_workflows: list[ast_module.RunWorkflowDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        first_by_work_dir: dict[str, ast_module.RunWorkflowDecl] = {}
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in run_workflows:
            normalized = self._normalize_path(statement.work_dir)
            previous = first_by_work_dir.get(normalized)
            if previous is None:
                first_by_work_dir[normalized] = statement
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"RUN_WORKFLOW {statement.id} reuses WORK_DIR '{statement.work_dir}' already used by {previous.id}.",
                    statement.location,
                    severity="info",
                    code="LGWF_RUN_WORKFLOW_WORK_DIR_REUSED",
                    suggestion="Give each child workflow a distinct WORK_DIR unless runs are guaranteed never to overlap.",
                )
            )
        return diagnostics

    def _lint_run_workflow_state_links(
        self,
        ast: ast_module.WorkflowAst,
        run_workflows: list[ast_module.RunWorkflowDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        reads = self._state_reads_by_path(ast)
        writes = self._state_writes_by_path(ast)
        diagnostics: list[diagnostics_module.Diagnostic] = []
        final_run_workflow = run_workflows[-1] if len(run_workflows) > 1 else None
        for statement in run_workflows:
            result_path = statement.result_path.path
            result_readers = [
                node_id
                for node_id in reads.get(result_path, [])
                if node_id != statement.id
            ]
            if not result_readers and statement != final_run_workflow:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"RUN_WORKFLOW {statement.id} RESULT state.{result_path} is not consumed by a later node.",
                        statement.location,
                        severity="info",
                        code="LGWF_RUN_WORKFLOW_RESULT_UNCONSUMED",
                        suggestion="Feed the child result into a PY map_* node or a downstream workflow input, or remove the unused RESULT.",
                    )
                )

            input_path = statement.input_path.path
            if self._is_external_initial_input(input_path):
                continue
            input_writers = [
                node_id
                for node_id in writes.get(input_path, [])
                if node_id != statement.id
            ]
            if not input_writers:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"RUN_WORKFLOW {statement.id} INPUT state.{input_path} has no obvious upstream writer.",
                        statement.location,
                        severity="info",
                        code="LGWF_RUN_WORKFLOW_INPUT_UNWRITTEN",
                        suggestion="Prepare the child input with an upstream PY map_* node or document it as an initial workflow input.",
                    )
                )
        return diagnostics

    def _lint_python_child_runs_data_channel(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            for python in self._python_decls(statement):
                if python.input_path is None:
                    continue
                script_path = self._resolve_python_script_path(python.script_path, defaults)
                if script_path is None or not script_path.is_file():
                    continue
                try:
                    content = script_path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    continue
                normalized = content.replace("\\", "/")
                if ".lgwf/child-runs" not in normalized:
                    continue
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PY {python.id} reads .lgwf/child-runs as a data channel.",
                        python.location,
                        severity="info",
                        code="LGWF_PY_CHILD_RUNS_DATA_CHANNEL",
                        suggestion="Read the upstream object from PY INPUT stdin or from RUN_WORKFLOW RESULT state instead of .lgwf/child-runs.",
                    )
                )
        return diagnostics

    def _state_reads_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        reads: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_reads(statement):
                reads.setdefault(path, []).append(node_id)
        return reads

    def _state_writes_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        writes: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_writes(statement):
                writes.setdefault(path, []).append(node_id)
        return writes

    def _statement_state_reads(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        if isinstance(statement, ast_module.PythonDecl):
            return [(statement.id, statement.input_path.path)] if statement.input_path is not None else []
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.input_path.path)]
        if isinstance(statement, ast_module.ApprovalDecl):
            return [(statement.id, statement.read_path.path)]
        if isinstance(statement, ast_module.ReviewDecl):
            return [(statement.id, statement.context_path.path)]
        if isinstance(statement, ast_module.HandoffDecl):
            return [(statement.id, statement.context_path.path)]
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.source_path.path)]
        if isinstance(statement, ast_module.CodexDecl):
            reads = []
            if statement.target_dirs_path is not None:
                reads.append((statement.id, statement.target_dirs_path.path))
            if statement.target_files_path is not None:
                reads.append((statement.id, statement.target_files_path.path))
            return reads
        if isinstance(statement, ast_module.ReactDecl):
            return [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_reads(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            reads = []
            for slot in statement.slots.values():
                reads.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_reads(slot.task))
            return reads
        if isinstance(statement, ast_module.ParallelDecl):
            return [
                (f"{statement.id}.{step.id}", path)
                for step in statement.steps
                for _, path in self._statement_state_reads(step.task)
            ]
        return []

    def _statement_state_writes(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        if isinstance(statement, ast_module.PythonDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.ToolDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.CodexDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.ApprovalDecl):
            writes = [(statement.id, statement.write_path.path)]
            if statement.result_path is not None:
                writes.append((statement.id, statement.result_path.path))
            return writes
        if isinstance(statement, ast_module.ReviewDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.HandoffDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.result_path.path)]
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.result_path.path)]
        if isinstance(statement, ast_module.WorkflowRefDecl):
            return [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
        if isinstance(statement, ast_module.ReactDecl):
            return [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_writes(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            writes = []
            if statement.status_path is not None:
                writes.append((statement.id, statement.status_path.path))
            if statement.report_path is not None:
                writes.append((statement.id, statement.report_path.path))
            for slot in statement.slots.values():
                writes.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_writes(slot.task))
            return writes
        if isinstance(statement, ast_module.ParallelDecl):
            writes = []
            for step in statement.steps:
                writes.append((f"{statement.id}.{step.id}", step.output_path.path))
                writes.append((f"{statement.id}.{step.id}", step.result_path.path))
                writes.extend((f"{statement.id}.{step.id}", path) for _, path in self._statement_state_writes(step.task))
            return writes
        return []

    def _python_decls(self, statement: ast_module.StatementDecl) -> list[ast_module.PythonDecl]:
        if isinstance(statement, ast_module.PythonDecl):
            return [statement]
        if isinstance(statement, ast_module.ReactDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.ParallelDecl):
            return [
                step.task
                for step in statement.steps
                if isinstance(step.task, ast_module.PythonDecl)
            ]
        return []

    def _resolve_python_script_path(
        self,
        raw_path: str,
        defaults: ast_module.DefaultsDecl,
    ) -> pathlib.Path | None:
        root = defaults.ref_root.get("root", "workflow")
        if root != "workflow":
            return None
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        ref_root_path = defaults.ref_root.get("path", ".")
        resolved_base = self._resolve_relative(base_dir, ref_root_path)
        if resolved_base is None:
            return None
        return self._resolve_relative(resolved_base, raw_path)

    def _is_external_initial_input(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        return normalized in {"input", "target", "pipeline.target"}

    def _resource_diagnostic(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
        suggestion: str,
    ) -> diagnostics_module.Diagnostic:
        return diagnostics_module.Diagnostic(
            f"{label} resource not found or invalid: {raw_path}",
            location,
            severity="error",
            code="LGWF_RESOURCE_MISSING",
            suggestion=suggestion,
        )

    def _lint_parallel_contexts(
        self,
        parallel: ast_module.ParallelDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for step in parallel.steps:
            codex_tasks = self._codex_tasks(step.task)
            if codex_tasks and not any(self._has_explicit_codex_scope(task) for task in codex_tasks):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PARALLEL {parallel.id} step {step.id} has no CODEX context_refs or targets; parallel steps should organize context through files, explicit refs, or analysis targets.",
                        step.location or parallel.location,
                    )
                )
            if isinstance(step.task, ast_module.ReactDecl):
                diagnostics.extend(self._lint_react_observe_scope(step.task, context_sets))
                diagnostics.extend(self._lint_react_observe_feedback_loop(step.task, context_sets))
        return diagnostics

    def _codex_tasks(
        self,
        task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.ReactDecl,
    ) -> list[ast_module.CodexDecl]:
        if isinstance(task, ast_module.CodexDecl):
            return [task]
        if isinstance(task, ast_module.ReactDecl):
            return [
                slot.task
                for slot in task.slots.values()
                if isinstance(slot.task, ast_module.CodexDecl)
            ]
        return []

    def _has_explicit_codex_scope(self, task: ast_module.CodexDecl) -> bool:
        return bool(
            task.contexts
            or task.target_dirs
            or task.target_files
            or task.target_dirs_path is not None
            or task.target_files_path is not None
        )

    def _lint_react_observe_scope(
        self,
        react: ast_module.ReactDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        observe_slot = react.slots.get("observe")
        if observe_slot is None or not isinstance(observe_slot.task, ast_module.CodexDecl):
            return []

        observed_paths = {
            self._normalize_path(resource.path)
            for resource in self._expand_contexts(observe_slot.task.contexts, context_sets)
            if resource.type == "file"
        }

        required_paths: set[str] = set()
        for slot_name in ("reason", "act"):
            slot = react.slots.get(slot_name)
            if slot is None or not isinstance(slot.task, ast_module.CodexDecl):
                continue
            for resource in self._expand_contexts(slot.task.contexts, context_sets):
                path = self._normalize_path(resource.path)
                if self._is_factual_data_file(resource.type, path):
                    required_paths.add(path)

        missing_paths = sorted(required_paths - observed_paths)
        if not missing_paths:
            return []

        missing_text = ", ".join(missing_paths)
        return [
            diagnostics_module.Diagnostic(
                f"REACT {react.id} observe context_refs missing input file used by reason/act: {missing_text}",
                observe_slot.location or react.location,
            )
        ]

    def _lint_react_observe_feedback_loop(
        self,
        react: ast_module.ReactDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        observe_slot = react.slots.get("observe")
        reason_slot = react.slots.get("reason")
        if (
            observe_slot is None
            or reason_slot is None
            or not isinstance(observe_slot.task, ast_module.CodexDecl)
            or not isinstance(reason_slot.task, ast_module.CodexDecl)
            or observe_slot.task.output_json_path is None
        ):
            return []

        observe_output_path = self._normalize_path(observe_slot.task.output_json_path)
        reason_context_paths = {
            self._normalize_path(resource.path)
            for resource in self._expand_contexts(reason_slot.task.contexts, context_sets)
            if resource.root == "workspace" and resource.type == "file"
        }
        if observe_output_path in reason_context_paths:
            return []

        return [
            diagnostics_module.Diagnostic(
                f"REACT {react.id} reason context_refs missing observe OUTPUT_JSON feedback file: {observe_output_path}",
                reason_slot.location or react.location,
                code="LGWF_REACT_FEEDBACK_LOOP_MISSING",
                suggestion=(
                    f'Add CONTEXT workspace file "{observe_output_path}" to the REACT reason slot. '
                    "If the file is absent on the first iteration, initialize an empty/default artifact before the REACT block."
                ),
            )
        ]

    def _context_sets(self, ast: ast_module.WorkflowAst) -> dict[str, ast_module.ContextSetDecl]:
        return {
            statement.name: statement
            for statement in ast.statements
            if isinstance(statement, ast_module.ContextSetDecl)
        }

    def _expand_contexts(
        self,
        contexts: Iterable[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[ast_module.ResourceRef]:
        resources: list[ast_module.ResourceRef] = []
        for context in contexts:
            if context.resource is not None:
                resources.append(context.resource)
            elif context.context_set is not None and context.context_set in context_sets:
                resources.extend(context_sets[context.context_set].resources)
        return resources

    def _is_factual_data_file(self, resource_type: str, path: str) -> bool:
        parsed = PurePosixPath(path)
        return resource_type == "file" and parsed.parts[:1] == ("data",) and parsed.suffix in {".json", ".md"}

    def _normalize_path(self, path: str) -> str:
        return path.replace("\\", "/")
