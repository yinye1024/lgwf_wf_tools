from collections.abc import Iterable
import ast as python_ast
import pathlib
from pathlib import PurePosixPath

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module
import lgwf_dsl.parser as parser_module
import lgwf_dsl.validator as validator_module


class WorkflowLinter:
    """Authoring-time checks for workflow contracts that are legal but risky."""

    def __init__(self, package_root: str | pathlib.Path | None = None) -> None:
        self.package_root = pathlib.Path(package_root).resolve() if package_root is not None else None
        self._visited_workflows: set[pathlib.Path] = set()

    def lint(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        previous_source_dir = getattr(self, "_current_source_dir", None)
        self._current_source_dir = self._source_dir_for_ast(ast)
        source_path = pathlib.Path(ast.source_name).expanduser().resolve() if ast.source_name is not None else None
        if source_path is not None and source_path in self._visited_workflows:
            return []
        if source_path is not None:
            self._visited_workflows.add(source_path)
        try:
            context_sets = self._context_sets(ast)
            defaults = self._defaults(ast)
            diagnostics: list[diagnostics_module.Diagnostic] = []
            diagnostics.extend(self._lint_entry_kind(ast))
            diagnostics.extend(self._lint_authoring_resources(ast, context_sets))
            for statement in ast.statements:
                if isinstance(statement, ast_module.ReactDecl):
                    diagnostics.extend(self._lint_react_observe_scope(statement, context_sets))
                    diagnostics.extend(self._lint_react_observe_feedback_loop(statement, context_sets))
                    diagnostics.extend(self._lint_repeated_react_inline_contexts(statement))
                elif isinstance(statement, ast_module.ParallelDecl):
                    diagnostics.extend(self._lint_parallel_contexts(statement, context_sets))
            diagnostics.extend(self._lint_approval_routes(ast))
            diagnostics.extend(self._lint_review_contracts(ast))
            diagnostics.extend(self._lint_review_control_plane_data_use(ast, defaults))
            diagnostics.extend(self._lint_human_control_plane_data_use(ast, defaults))
            diagnostics.extend(self._lint_python_contracts(ast, defaults))
            diagnostics.extend(self._lint_redundant_contract_state_writes(ast))
            diagnostics.extend(self._lint_run_workflow_handoffs(ast, defaults))
            return diagnostics
        finally:
            self._current_source_dir = previous_source_dir

    def _lint_entry_kind(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        if ast.entry_kind is not None:
            return []
        if not any(isinstance(statement, ast_module.FlowDecl) and statement.name is not None for statement in ast.statements):
            return []
        return [
            diagnostics_module.Diagnostic(
                f"ENTRY {ast.entry_point} is untyped; use ENTRY NODE {ast.entry_point} or ENTRY FLOW <flow_name>.",
                ast.location,
                code="LGWF_ENTRY_UNTYPED",
                suggestion="Use ENTRY NODE for a concrete runtime node, or ENTRY FLOW for a named authoring flow.",
            )
        ]

    def _lint_authoring_resources(
        self,
        ast: ast_module.WorkflowAst,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        if ast.source_name is None and self.package_root is None:
            return []

        defaults = self._defaults(ast)
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            diagnostics.extend(self._lint_statement_resources(statement, defaults, context_sets))
        return diagnostics

    def _lint_statement_resources(
        self,
        statement: ast_module.StatementDecl,
        defaults: ast_module.DefaultsDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        if isinstance(statement, ast_module.PythonDecl):
            missing = self._missing_task_resource(statement.script_path, "SCRIPT", defaults, statement.location)
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.CodexDecl):
            diagnostics = [self._missing_task_resource(statement.prompt_path, "PROMPT", defaults, statement.location)]
            diagnostics.extend(self._lint_context_resources(statement.contexts, context_sets))
            return [diagnostic for diagnostic in diagnostics if diagnostic is not None]
        if isinstance(statement, ast_module.ApprovalDecl) and statement.prompt_ref_path is not None:
            missing = self._missing_workflow_resource(
                statement.prompt_ref_path,
                "PROMPT_REF",
                statement.location,
            )
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.ReviewDecl):
            missing = self._missing_workflow_resource(
                statement.prompt_ref_path,
                "PROMPT",
                statement.location,
            )
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.ChoiceDecl):
            missing = self._missing_workflow_resource(
                statement.prompt_ref_path,
                "PROMPT_REF",
                statement.location,
            )
            return [missing] if missing is not None else []
        if isinstance(statement, ast_module.ReactDecl):
            diagnostics: list[diagnostics_module.Diagnostic] = []
            if statement.spec_path is not None:
                missing = self._missing_task_resource(
                    statement.spec_path,
                    "SPEC",
                    defaults,
                    statement.location,
                )
                if missing is not None:
                    diagnostics.append(missing)
            for slot in statement.slots.values():
                diagnostics.extend(self._lint_statement_resources(slot.task, defaults, context_sets))
            return diagnostics
        if isinstance(statement, ast_module.AgentLoopDecl):
            diagnostics = []
            diagnostics.extend(self._lint_context_resources(statement.contexts, context_sets))
            for slot in statement.slots.values():
                diagnostics.extend(self._lint_statement_resources(slot.task, defaults, context_sets))
            return diagnostics
        if isinstance(statement, ast_module.WorkflowRefDecl):
            missing = self._missing_workflow_ref(statement.workflow_path, statement.location)
            if missing is not None:
                return [missing]
            return self._lint_child_workflow(statement)
        if isinstance(statement, ast_module.RunWorkflowDecl):
            diagnostics = []
            invalid_work_dir = self._invalid_run_workflow_work_dir(statement)
            if invalid_work_dir is not None:
                diagnostics.append(invalid_work_dir)
            missing = self._missing_external_workflow(statement.workflow_path, statement.location)
            if missing is not None:
                diagnostics.append(missing)
            return diagnostics
        if isinstance(statement, ast_module.ParallelDecl):
            diagnostics = []
            for step in statement.steps:
                diagnostics.extend(self._lint_statement_resources(step.task, defaults, context_sets))
            return diagnostics
        return []

    def _lint_context_resources(
        self,
        contexts: Iterable[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for context in contexts:
            resources: list[ast_module.ResourceRef] = []
            if context.resource is not None:
                resources.append(context.resource)
            elif context.context_set is not None and context.context_set in context_sets:
                resources.extend(self._context_set_resources(context.context_set, context_sets))
            for resource in resources:
                if resource.root != "workflow":
                    continue
                missing = self._missing_workflow_resource(resource.path, f"CONTEXT workflow {resource.type}", resource.location)
                if missing is not None:
                    diagnostics.append(missing)
        return diagnostics

    def _defaults(self, ast: ast_module.WorkflowAst) -> ast_module.DefaultsDecl:
        defaults = ast_module.DefaultsDecl()
        for statement in ast.statements:
            if isinstance(statement, ast_module.DefaultsDecl):
                defaults = statement
        return defaults

    def _missing_task_resource(
        self,
        raw_path: str,
        label: str,
        defaults: ast_module.DefaultsDecl,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        root = defaults.ref_root.get("root", "workflow")
        if root != "workflow":
            return None
        ref_root_path = defaults.ref_root.get("path", ".")
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved_base = self._resolve_relative(base_dir, ref_root_path)
        if resolved_base is None:
            return self._resource_diagnostic(ref_root_path, "ref_root", location, "ref_root path must be relative and stay inside the workflow package.")
        resolved = self._resolve_relative(resolved_base, raw_path)
        if resolved is None or not resolved.is_file():
            return self._resource_diagnostic(raw_path, label, location, f"Create the {label} file or update its path to an existing workflow package file.")
        return None

    def _missing_workflow_resource(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved = self._resolve_relative(base_dir, raw_path)
        if resolved is None:
            return self._resource_diagnostic(raw_path, label, location, "Use a relative path inside the workflow package.")
        if not resolved.exists():
            return self._resource_diagnostic(raw_path, label, location, f"Create the referenced {label} resource or update the path.")
        return None

    def _missing_workflow_ref(
        self,
        raw_path: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved = self._resolve_relative(base_dir, raw_path)
        if resolved is None or pathlib.PurePath(raw_path).suffix.lower() != ".lgwf" or not resolved.is_file():
            return self._resource_diagnostic(raw_path, "STEP WORKFLOW", location, "Point STEP WORKFLOW at an existing relative .lgwf file inside the workflow package.")
        return None

    def _missing_external_workflow(
        self,
        raw_path: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> diagnostics_module.Diagnostic | None:
        path = pathlib.Path(raw_path)
        if path.is_absolute() or ".." in path.parts or path.suffix.lower() != ".lgwf":
            return self._resource_diagnostic(
                raw_path,
                "RUN_WORKFLOW WORKFLOW",
                location,
                "Use a relative path to an existing child workflow.lgwf file.",
            )
        if not path.resolve().is_file():
            return self._resource_diagnostic(
                raw_path,
                "RUN_WORKFLOW WORKFLOW",
                location,
                "Create the child workflow.lgwf file or update RUN_WORKFLOW WORKFLOW.",
            )
        return None

    def _invalid_run_workflow_work_dir(
        self,
        statement: ast_module.RunWorkflowDecl,
    ) -> diagnostics_module.Diagnostic | None:
        path = pathlib.Path(statement.work_dir)
        if not path.is_absolute() and ".." not in path.parts:
            return None
        return diagnostics_module.Diagnostic(
            f"RUN_WORKFLOW WORK_DIR path is invalid: {statement.work_dir}",
            statement.location,
            severity="error",
            code="LGWF_RUN_WORKFLOW_WORK_DIR_INVALID",
            suggestion="Use a relative WORK_DIR path without '..'. The child workflow owns that work_dir runtime state.",
        )

    def _resolve_relative(self, base_dir: pathlib.Path, raw_path: str) -> pathlib.Path | None:
        path = pathlib.Path(raw_path)
        if path.is_absolute() or ".." in path.parts:
            return None
        resolved = (base_dir / path).resolve()
        if self.package_root is not None and not resolved.is_relative_to(self.package_root):
            return None
        return resolved

    def _source_dir(self) -> pathlib.Path | None:
        return getattr(self, "_current_source_dir", None)

    def _source_dir_for_ast(self, ast: ast_module.WorkflowAst) -> pathlib.Path | None:
        if self.package_root is None:
            return None
        if ast.source_name is not None:
            return pathlib.Path(ast.source_name).expanduser().resolve().parent
        return self.package_root

    def _lint_child_workflow(self, ref: ast_module.WorkflowRefDecl) -> list[diagnostics_module.Diagnostic]:
        base_dir = self._source_dir()
        if base_dir is None:
            return []
        child_path = self._resolve_relative(base_dir, ref.workflow_path)
        if child_path is None or not child_path.is_file():
            return []
        source = child_path.read_text(encoding="utf-8")
        child_ast = parser_module.Parser.from_text(source, source_name=str(child_path)).parse_workflow()
        validator_module.WorkflowValidator().validate(child_ast)
        return self.lint(child_ast)

    def _lint_run_workflow_handoffs(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        run_workflows = [
            statement
            for statement in ast.statements
            if isinstance(statement, ast_module.RunWorkflowDecl)
        ]
        if not run_workflows:
            return []

        diagnostics: list[diagnostics_module.Diagnostic] = []
        diagnostics.extend(self._lint_reused_run_workflow_work_dirs(run_workflows))
        diagnostics.extend(self._lint_run_workflow_state_links(ast, run_workflows))
        diagnostics.extend(self._lint_python_child_runs_data_channel(ast, defaults))
        return diagnostics

    def _lint_approval_routes(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        approval_locations = {
            statement.id: statement.location
            for statement in ast.statements
            if isinstance(statement, ast_module.ApprovalDecl) and statement.route_on_decision
        }
        if not approval_locations:
            return []
        diagnostics: list[diagnostics_module.Diagnostic] = []
        allowed = {"approve", "reject"}
        for statement in ast.statements:
            if not isinstance(statement, ast_module.RouteDecl):
                continue
            if statement.from_node not in approval_locations:
                continue
            invalid = sorted(key for key in statement.branches if key not in allowed)
            if not invalid:
                continue
            node_id = statement.from_node
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"APPROVAL {node_id} uses non-binary route keys: {', '.join(invalid)}. APPROVAL route keys must be approve/reject only.",
                    statement.location or approval_locations[node_id],
                    severity="error",
                    code="LGWF_APPROVAL_NON_BINARY_ROUTE",
                    suggestion=(
                        "Use fixed-option REVIEW for approve/revise/reject flows, "
                        "or keep APPROVAL routes limited to approve/reject and move business branching into a downstream node."
                    ),
                )
            )
        return diagnostics

    def _lint_review_contracts(self, ast: ast_module.WorkflowAst) -> list[diagnostics_module.Diagnostic]:
        reviews = {
            statement.id: statement
            for statement in ast.statements
            if isinstance(statement, ast_module.ReviewDecl)
        }
        if not reviews:
            return []

        diagnostics: list[diagnostics_module.Diagnostic] = []
        route_map = self._route_map(ast)
        edges = self._edge_map(ast)
        control_state = self._human_control_state_paths(ast)
        for review_id, review in reviews.items():
            if review.result_path is None:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} omits explicit RESULT state path.",
                        review.location,
                        severity="warning",
                        code="LGWF_REVIEW_RESULT_RECOMMENDED",
                        suggestion=f"Add RESULT state.{review_id}_result or another explicit review result path for traceability.",
                    )
                )

            prompt_empty = self._review_prompt_empty_diagnostic(review)
            if prompt_empty is not None:
                diagnostics.append(prompt_empty)

            context_path = review.context_path.path
            if self._review_context_looks_control_plane(context_path, control_state):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} CONTEXT state.{context_path} looks like human control-plane data.",
                        review.location,
                        severity="warning",
                        code="LGWF_REVIEW_CONTEXT_CONTROL_PLANE",
                        suggestion="Use the business proposal JSON object as REVIEW CONTEXT, not approval/review result state.",
                    )
                )
            elif self._review_context_name_suspicious(context_path):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} CONTEXT state.{context_path} has suspicious control-plane naming.",
                        review.location,
                        severity="warning",
                        code="LGWF_REVIEW_CONTEXT_NAME_SUSPICIOUS",
                        suggestion="Prefer names such as proposal, requirements, design, or plan for REVIEW context JSON.",
                    )
                )

            plain_successors = edges.get(review_id, [])
            risky_successors = [node for node in plain_successors if self._looks_like_apply_or_finalize_node(node)]
            if risky_successors:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} has plain FLOW/EDGE to apply/finalize node(s): {', '.join(risky_successors)}.",
                        review.location,
                        severity="error",
                        code="LGWF_REVIEW_APPROVE_ONLY_APPLY",
                        suggestion='Route REVIEW explicitly and only send WHEN "approve" to apply/finalize.',
                    )
                )

            branches = route_map.get(review_id)
            if branches is None:
                continue
            missing = sorted({"approve", "revise", "reject"} - set(branches))
            if missing:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} missing route branches: {', '.join(missing)}.",
                        review.location,
                        severity="error",
                        code="LGWF_REVIEW_ROUTE_MISSING_FIXED_BRANCH",
                        suggestion=(
                            "Route REVIEW with approve/revise/reject. Usually revise returns to the "
                            "REVIEW node and reject routes to FAIL_ALL."
                        ),
                    )
                )
            reject_target = branches.get("reject")
            if reject_target is not None and reject_target != "FAIL_ALL":
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"REVIEW {review_id} reject route targets {reject_target}; reject should usually target FAIL_ALL.",
                        review.location,
                        severity="warning",
                        code="LGWF_REVIEW_REJECT_SHOULD_FAIL_ALL",
                        suggestion='Use WHEN "reject" THEN FAIL_ALL unless the workflow has an explicit cleanup/summarize branch.',
                    )
                )
            revise_target = branches.get("revise")
            if revise_target is not None and revise_target != review_id:
                returns_to_review = self._can_reach(revise_target, review_id, edges)
                reachable_apply = sorted(
                    node
                    for node in self._reachable_nodes(revise_target, edges)
                    if self._looks_like_apply_or_finalize_node(node)
                )
                if not returns_to_review or reachable_apply:
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            (
                                f"REVIEW {review_id} revise route must return to the same REVIEW before "
                                f"apply/finalize. Target {revise_target} reaches: "
                                f"{', '.join(reachable_apply) or '<none>'}."
                            ),
                            review.location,
                            severity="error",
                            code="LGWF_REVIEW_REVISE_SHOULD_RETURN_TO_REVIEW",
                            suggestion=(
                                'Make WHEN "revise" target the same REVIEW node, or target a revision '
                                "node whose next edge returns to the REVIEW node."
                            ),
                        )
                    )
        return diagnostics

    def _route_map(self, ast: ast_module.WorkflowAst) -> dict[str, dict[str, str]]:
        routes: dict[str, dict[str, str]] = {}
        for statement in ast.statements:
            if isinstance(statement, ast_module.RouteDecl):
                routes[statement.from_node] = dict(statement.branches)
        return routes

    def _edge_map(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        edges: dict[str, list[str]] = {}
        for statement in ast.statements:
            if isinstance(statement, ast_module.FlowDecl):
                for left, right in zip(statement.nodes, statement.nodes[1:]):
                    edges.setdefault(left, []).append(right)
            elif isinstance(statement, ast_module.EdgeDecl):
                edges.setdefault(statement.from_node, []).append(statement.to_node)
        return edges

    def _can_reach(
        self,
        start: str,
        target: str,
        edges: dict[str, list[str]],
        *,
        max_depth: int = 8,
    ) -> bool:
        frontier = [(start, 0)]
        visited: set[str] = set()
        while frontier:
            node, depth = frontier.pop(0)
            if node == target:
                return True
            if node in visited or depth >= max_depth:
                continue
            visited.add(node)
            for next_node in edges.get(node, []):
                frontier.append((next_node, depth + 1))
        return False

    def _reachable_nodes(
        self,
        start: str,
        edges: dict[str, list[str]],
        *,
        max_depth: int = 8,
    ) -> set[str]:
        result: set[str] = set()
        frontier = [(start, 0)]
        while frontier:
            node, depth = frontier.pop(0)
            if node in result or depth > max_depth:
                continue
            result.add(node)
            for next_node in edges.get(node, []):
                frontier.append((next_node, depth + 1))
        return result

    def _looks_like_apply_or_finalize_node(self, node_id: str) -> bool:
        normalized = node_id.lower()
        tokens = ("apply", "finalize", "confirmed", "persist", "save_confirmed")
        return any(token in normalized for token in tokens)

    def _review_context_looks_control_plane(self, path: str, control_state: set[str]) -> bool:
        if path in control_state:
            return True
        lowered = path.lower()
        return any(
            token in lowered
            for token in ("review_result", "approval_result", "human_approval", "human_review")
        )

    def _review_context_name_suspicious(self, path: str) -> bool:
        lowered = path.lower()
        return any(
            token in lowered
            for token in ("result", "decision", "approval", "review_response", "choice")
        )

    def _review_prompt_empty_diagnostic(
        self,
        review: ast_module.ReviewDecl,
    ) -> diagnostics_module.Diagnostic | None:
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        resolved = self._resolve_relative(base_dir, review.prompt_ref_path)
        if resolved is None or not resolved.is_file():
            return None
        try:
            content = resolved.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return None
        if content.strip():
            return None
        return diagnostics_module.Diagnostic(
            f"REVIEW {review.id} prompt file is empty: {review.prompt_ref_path}",
            review.location,
            severity="warning",
            code="LGWF_REVIEW_PROMPT_EMPTY",
            suggestion=(
                "Write a concrete review prompt that tells the main agent how to present "
                "the JSON object and ask for approve/revise/reject."
            ),
        )

    def _lint_human_control_plane_data_use(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        control_state = self._human_control_state_paths(ast)
        control_files = self._human_control_persist_paths(ast)
        if not control_state and not control_files:
            return []

        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            if self._is_human_decision_statement(statement):
                continue
            reads_control_state = [
                path
                for _, path in self._statement_state_reads(statement)
                if path in control_state
            ]
            business_writes = [
                path
                for _, path in self._statement_state_writes(statement)
                if self._looks_like_business_artifact_state(path)
            ]
            if reads_control_state and business_writes:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"{getattr(statement, 'id', '<anonymous>')} reads human decision control state "
                            f"{', '.join(sorted(set(reads_control_state)))} and writes business artifact state "
                            f"{', '.join(sorted(set(business_writes)))}."
                        ),
                        getattr(statement, "location", None),
                        severity="error",
                        code="LGWF_HUMAN_CONTROL_PLANE_AS_DATA",
                        suggestion=(
                            "Keep APPROVAL/REVIEW/CHOICE RESULT and decision records as route/control data only. "
                            "Have downstream nodes read a fixed proposal or normalized business artifact instead."
                        ),
                    )
                )

            for python in self._python_decls(statement):
                diagnostics.extend(self._lint_python_human_persist_reads(python, defaults, control_files))
        return diagnostics

    def _lint_review_control_plane_data_use(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        review_state = {
            statement.result_path.path
            for statement in ast.statements
            if isinstance(statement, ast_module.ReviewDecl) and statement.result_path is not None
        }
        review_files = {
            self._normalize_path(statement.persist_path)
            for statement in ast.statements
            if isinstance(statement, ast_module.ReviewDecl) and statement.persist_path
        }
        if not review_state and not review_files:
            return []

        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            if isinstance(statement, ast_module.ReviewDecl):
                continue
            reads_review_state = [
                path
                for _, path in self._statement_state_reads(statement)
                if path in review_state
            ]
            business_writes = [
                path
                for _, path in self._statement_state_writes(statement)
                if self._looks_like_business_artifact_state(path)
            ]
            if reads_review_state and business_writes:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"{getattr(statement, 'id', '<anonymous>')} reads REVIEW result state "
                            f"{', '.join(sorted(set(reads_review_state)))} and writes business artifact state "
                            f"{', '.join(sorted(set(business_writes)))}."
                        ),
                        getattr(statement, "location", None),
                        severity="error",
                        code="LGWF_REVIEW_RESULT_AS_BUSINESS_DATA",
                        suggestion=(
                            "Read the REVIEW CONTEXT proposal JSON, not REVIEW RESULT/PERSIST control-plane "
                            "records, when applying confirmed business artifacts."
                        ),
                    )
                )
            for python in self._python_decls(statement):
                for diagnostic in self._lint_python_human_persist_reads(python, defaults, review_files):
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            diagnostic.message,
                            diagnostic.location,
                            severity="error",
                            code="LGWF_REVIEW_RESULT_AS_BUSINESS_DATA",
                            suggestion=(
                                "Read the fixed proposal artifact, not REVIEW PERSIST decision JSON, "
                                "when applying confirmed business artifacts."
                            ),
                        )
                    )
        return diagnostics

    def _human_control_state_paths(self, ast: ast_module.WorkflowAst) -> set[str]:
        paths: set[str] = set()
        for statement in ast.statements:
            if isinstance(statement, ast_module.ApprovalDecl) and statement.result_path is not None:
                paths.add(statement.result_path.path)
            elif isinstance(statement, ast_module.ReviewDecl) and statement.result_path is not None:
                paths.add(statement.result_path.path)
            elif isinstance(statement, ast_module.ChoiceDecl) and statement.result_path is not None:
                paths.add(statement.result_path.path)
        return paths

    def _human_control_persist_paths(self, ast: ast_module.WorkflowAst) -> set[str]:
        paths: set[str] = set()
        for statement in ast.statements:
            if isinstance(statement, (ast_module.ReviewDecl, ast_module.ChoiceDecl)) and statement.persist_path:
                paths.add(self._normalize_path(statement.persist_path))
        return paths

    def _is_human_decision_statement(self, statement: ast_module.StatementDecl) -> bool:
        return isinstance(statement, (ast_module.ApprovalDecl, ast_module.ReviewDecl, ast_module.ChoiceDecl))

    def _looks_like_business_artifact_state(self, path: str) -> bool:
        normalized = self._normalize_path(path).lower()
        keywords = (
            "confirmed",
            "proposal",
            "business_flow",
            "requirements",
            "step_design",
            "final",
        )
        return any(keyword in normalized for keyword in keywords)

    def _lint_python_human_persist_reads(
        self,
        python: ast_module.PythonDecl,
        defaults: ast_module.DefaultsDecl,
        control_files: set[str],
    ) -> list[diagnostics_module.Diagnostic]:
        if not control_files:
            return []
        script_path = self._resolve_python_script_path(python.script_path, defaults)
        if script_path is None or not script_path.is_file():
            return []
        try:
            content = script_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return []
        normalized = content.replace("\\", "/")
        matched = [
            path
            for path in sorted(control_files)
            if path in normalized or pathlib.PurePosixPath(path).name in normalized
        ]
        if not matched:
            return []
        if "proposal" in normalized or "normaliz" in normalized or "normalize" in normalized:
            return []
        if python.result_path is None or not self._looks_like_business_artifact_state(python.result_path.path):
            return []
        return [
            diagnostics_module.Diagnostic(
                f"PY {python.id} reads human decision persist file(s) as business data: {', '.join(matched)}.",
                python.location,
                severity="error",
                code="LGWF_HUMAN_CONTROL_PLANE_AS_DATA",
                suggestion=(
                    "Use REVIEW/CHOICE persist files only for route decision audit. "
                    "Read a fixed proposal or normalized business artifact before writing confirmed/final state."
                ),
            )
        ]

    def _lint_reused_run_workflow_work_dirs(
        self,
        run_workflows: list[ast_module.RunWorkflowDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        first_by_work_dir: dict[str, ast_module.RunWorkflowDecl] = {}
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in run_workflows:
            normalized = self._normalize_path(statement.work_dir)
            previous = first_by_work_dir.get(normalized)
            if previous is None:
                first_by_work_dir[normalized] = statement
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"RUN_WORKFLOW {statement.id} reuses WORK_DIR '{statement.work_dir}' already used by {previous.id}.",
                    statement.location,
                    severity="info",
                    code="LGWF_RUN_WORKFLOW_WORK_DIR_REUSED",
                    suggestion="Give each child workflow a distinct WORK_DIR unless runs are guaranteed never to overlap.",
                )
            )
        return diagnostics

    def _lint_run_workflow_state_links(
        self,
        ast: ast_module.WorkflowAst,
        run_workflows: list[ast_module.RunWorkflowDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        reads = self._state_reads_by_path(ast)
        writes = self._state_writes_by_path(ast)
        diagnostics: list[diagnostics_module.Diagnostic] = []
        final_run_workflow = run_workflows[-1] if len(run_workflows) > 1 else None
        for statement in run_workflows:
            result_path = statement.result_path.path
            result_readers = [
                node_id
                for node_id in reads.get(result_path, [])
                if node_id != statement.id
            ]
            if not result_readers and statement != final_run_workflow:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"RUN_WORKFLOW {statement.id} RESULT state.{result_path} is not consumed by a later node.",
                        statement.location,
                        severity="info",
                        code="LGWF_RUN_WORKFLOW_RESULT_UNCONSUMED",
                        suggestion="Feed the child result into a PY map_* node or a downstream workflow input, or remove the unused RESULT.",
                    )
                )

            input_path = statement.input_path.path
            if self._is_external_initial_input(input_path):
                continue
            input_writers = [
                node_id
                for node_id in writes.get(input_path, [])
                if node_id != statement.id
            ]
            if not input_writers:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"RUN_WORKFLOW {statement.id} INPUT state.{input_path} has no obvious upstream writer.",
                        statement.location,
                        severity="info",
                        code="LGWF_RUN_WORKFLOW_INPUT_UNWRITTEN",
                        suggestion="Prepare the child input with an upstream PY map_* node or document it as an initial workflow input.",
                    )
                )
        return diagnostics

    def _lint_python_child_runs_data_channel(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            for python in self._python_decls(statement):
                if python.input_path is None:
                    continue
                script_path = self._resolve_python_script_path(python.script_path, defaults)
                if script_path is None or not script_path.is_file():
                    continue
                try:
                    content = script_path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    continue
                normalized = content.replace("\\", "/")
                if ".lgwf/child-runs" not in normalized:
                    continue
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PY {python.id} reads .lgwf/child-runs as a data channel.",
                        python.location,
                        severity="info",
                        code="LGWF_PY_CHILD_RUNS_DATA_CHANNEL",
                        suggestion="Read the upstream object from PY INPUT stdin or from RUN_WORKFLOW RESULT state instead of .lgwf/child-runs.",
                    )
                )
        return diagnostics

    def _lint_python_contracts(
        self,
        ast: ast_module.WorkflowAst,
        defaults: ast_module.DefaultsDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            for python in self._python_decls(statement):
                contract = python.contract
                reads = self._python_script_file_reads(python, defaults)
                business_reads = sorted(path for path in reads["paths"] if self._is_business_artifact_read_path(path))
                has_unknown_business_read = bool(reads["unknown"]) and contract is None
                if business_reads or has_unknown_business_read:
                    if contract is None:
                        paths = ", ".join(business_reads) if business_reads else "unknown dynamic path"
                        diagnostics.append(
                            diagnostics_module.Diagnostic(
                                f"PY {python.id} reads business artifact file(s) without CONTRACT: {paths}.",
                                python.location,
                                severity="error",
                                code="LGWF_PY_FILE_READ_CONTRACT_MISSING",
                                suggestion="Declare CONTRACT READ workspace file entries for every business artifact read by this Python script.",
                            )
                        )
                    else:
                        declared_reads = self._contract_read_resource_paths(contract)
                        missing_reads = [path for path in business_reads if path not in declared_reads]
                        if missing_reads:
                            declared_text = ", ".join(sorted(declared_reads)) if declared_reads else "<none>"
                            diagnostics.append(
                                diagnostics_module.Diagnostic(
                                    (
                                        f"PY {python.id} reads file(s) not declared in CONTRACT: "
                                        f"{', '.join(missing_reads)}. Declared reads: {declared_text}."
                                    ),
                                    python.location,
                                    severity="error",
                                    code="LGWF_PY_FILE_READ_CONTRACT_MISMATCH",
                                    suggestion="Add matching CONTRACT READ workspace file entries, or update the script to read only declared artifacts.",
                                )
                            )

                writes = self._python_script_file_writes(python, defaults)
                business_writes = sorted(path for path in writes["paths"] if self._is_business_artifact_path(path))
                has_unknown_business_write = bool(writes["unknown"]) and contract is None
                if not business_writes and not has_unknown_business_write:
                    continue

                if contract is None:
                    paths = ", ".join(business_writes) if business_writes else "unknown dynamic path"
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            f"PY {python.id} writes business artifact file(s) without CONTRACT: {paths}.",
                            python.location,
                            severity="error",
                            code="LGWF_PY_FILE_WRITE_CONTRACT_MISSING",
                            suggestion="Declare CONTRACT WRITE workspace file entries for every business artifact written by this Python script.",
                        )
                    )
                    continue

                declared = self._contract_write_resource_paths(contract)
                missing = [path for path in business_writes if path not in declared]
                if missing:
                    declared_text = ", ".join(sorted(declared)) if declared else "<none>"
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            (
                                f"PY {python.id} writes file(s) not declared in CONTRACT: "
                                f"{', '.join(missing)}. Declared writes: {declared_text}."
                            ),
                            python.location,
                            severity="error",
                            code="LGWF_PY_FILE_WRITE_CONTRACT_MISMATCH",
                            suggestion="Add matching CONTRACT WRITE workspace file entries, or update the script to write only declared artifacts.",
                        )
                    )
        return diagnostics

    def _lint_redundant_contract_state_writes(
        self,
        ast: ast_module.WorkflowAst,
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for statement in ast.statements:
            diagnostics.extend(self._lint_statement_redundant_contract_state_writes(statement))
        return diagnostics

    def _lint_statement_redundant_contract_state_writes(
        self,
        statement: ast_module.StatementDecl,
        label_prefix: str | None = None,
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        contract = getattr(statement, "contract", None)
        node_id = getattr(statement, "id", "")
        label = f"{label_prefix}.{node_id}" if label_prefix and node_id else node_id or label_prefix or "node"
        if contract is not None:
            contract_writes = {item.path for item in contract.writes_state}
            result_path = getattr(statement, "result_path", None)
            if isinstance(result_path, ast_module.StateRef) and result_path.path in contract_writes:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"{label} CONTRACT WRITE state.{result_path.path} repeats "
                            f"RESULT state.{result_path.path}."
                        ),
                        getattr(statement, "location", None),
                        severity="error",
                        code="LGWF_CONTRACT_RESULT_WRITE_REDUNDANT",
                        suggestion="RESULT already declares this execution result state path; remove the duplicate CONTRACT WRITE state entry.",
                    )
                )
            if isinstance(statement, ast_module.PythonDecl):
                update_paths = {item.path for item in statement.state_update_writes}
                for path in sorted(contract_writes & update_paths):
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            f"{label} CONTRACT WRITE state.{path} repeats UPDATES_STATE WRITE state.{path}.",
                            statement.location,
                            severity="error",
                            code="LGWF_CONTRACT_UPDATES_STATE_WRITE_REDUNDANT",
                            suggestion="UPDATES_STATE already declares this stdout state patch path; remove the duplicate CONTRACT WRITE state entry.",
                        )
                    )

        if isinstance(statement, ast_module.ReactDecl):
            for slot in statement.slots.values():
                diagnostics.extend(
                    self._lint_statement_redundant_contract_state_writes(
                        slot.task,
                        f"{statement.id}.{slot.slot_name}",
                    )
                )
        elif isinstance(statement, ast_module.AgentLoopDecl):
            for slot in statement.slots.values():
                diagnostics.extend(
                    self._lint_statement_redundant_contract_state_writes(
                        slot.task,
                        f"{statement.id}.{slot.slot_name}",
                    )
                )
        elif isinstance(statement, ast_module.ParallelDecl):
            for step in statement.steps:
                diagnostics.extend(
                    self._lint_statement_redundant_contract_state_writes(
                        step.task,
                        f"{statement.id}.{step.id}",
                    )
                )
        return diagnostics

    def _python_script_file_reads(
        self,
        python: ast_module.PythonDecl,
        defaults: ast_module.DefaultsDecl,
    ) -> dict[str, object]:
        script_path = self._resolve_python_script_path(python.script_path, defaults)
        if script_path is None or not script_path.is_file():
            return {"paths": set(), "unknown": False}
        try:
            content = script_path.read_text(encoding="utf-8")
            tree = python_ast.parse(content)
        except (UnicodeDecodeError, SyntaxError):
            return {"paths": set(), "unknown": False}

        paths: set[str] = set()
        unknown = False
        for node in python_ast.walk(tree):
            if not isinstance(node, python_ast.Call):
                continue
            path = self._read_path_from_call(node)
            if path is None:
                if self._is_file_read_call(node):
                    unknown = True
                continue
            paths.add(path)
        return {"paths": paths, "unknown": unknown}

    def _python_script_file_writes(
        self,
        python: ast_module.PythonDecl,
        defaults: ast_module.DefaultsDecl,
    ) -> dict[str, object]:
        script_path = self._resolve_python_script_path(python.script_path, defaults)
        if script_path is None or not script_path.is_file():
            return {"paths": set(), "unknown": False}
        try:
            content = script_path.read_text(encoding="utf-8")
            tree = python_ast.parse(content)
        except (UnicodeDecodeError, SyntaxError):
            return {"paths": set(), "unknown": False}

        paths: set[str] = set()
        unknown = False
        for node in python_ast.walk(tree):
            if not isinstance(node, python_ast.Call):
                continue
            path = self._write_path_from_call(node)
            if path is None:
                if self._is_file_write_call(node):
                    unknown = True
                continue
            paths.add(path)
        return {"paths": paths, "unknown": unknown}

    def _read_path_from_call(self, node: python_ast.Call) -> str | None:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"read_text", "read_bytes"}:
            return self._literal_path_expr(node.func.value)
        if self._call_name(node.func) == "open" and self._open_call_reads(node):
            return self._literal_path_expr(node.args[0]) if node.args else None
        if self._call_name(node.func) in {"load_json", "read_json"} and node.args:
            return self._literal_path_expr(node.args[0])
        return None

    def _is_file_read_call(self, node: python_ast.Call) -> bool:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"read_text", "read_bytes"}:
            return True
        if self._call_name(node.func) == "open":
            return self._open_call_reads(node)
        return self._call_name(node.func) in {"load_json", "read_json"}

    def _write_path_from_call(self, node: python_ast.Call) -> str | None:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"write_text", "write_bytes"}:
            return self._literal_path_expr(node.func.value)
        if self._call_name(node.func) == "open" and self._open_call_writes(node):
            return self._literal_path_expr(node.args[0]) if node.args else None
        if self._call_name(node.func) == "write_json" and node.args:
            return self._literal_path_expr(node.args[0])
        return None

    def _is_file_write_call(self, node: python_ast.Call) -> bool:
        if isinstance(node.func, python_ast.Attribute) and node.func.attr in {"write_text", "write_bytes"}:
            return True
        if self._call_name(node.func) == "open":
            return self._open_call_writes(node)
        return self._call_name(node.func) == "write_json"

    def _literal_path_expr(self, node: python_ast.AST) -> str | None:
        if isinstance(node, python_ast.Constant) and isinstance(node.value, str):
            return self._normalize_path(node.value)
        if isinstance(node, python_ast.Call) and self._call_name(node.func) in {"Path", "pathlib.Path"} and node.args:
            return self._literal_path_expr(node.args[0])
        if isinstance(node, python_ast.BinOp) and isinstance(node.op, python_ast.Div):
            left = node.left
            right = node.right
            right_path = self._literal_path_expr(right)
            if right_path is None:
                return None
            left_path = self._literal_path_expr(left)
            if left_path is not None:
                return self._normalize_path(f"{left_path}/{right_path}")
            if isinstance(left, python_ast.Name) and left.id == "lgwf_dir":
                return self._normalize_path(f".lgwf/{right_path}")
            if isinstance(left, python_ast.Name) or isinstance(left, python_ast.Call):
                return right_path
        return None

    def _open_call_reads(self, node: python_ast.Call) -> bool:
        mode = None
        if len(node.args) >= 2 and isinstance(node.args[1], python_ast.Constant) and isinstance(node.args[1].value, str):
            mode = node.args[1].value
        for keyword in node.keywords:
            if keyword.arg == "mode" and isinstance(keyword.value, python_ast.Constant) and isinstance(keyword.value.value, str):
                mode = keyword.value.value
        if mode is None:
            return True
        return isinstance(mode, str) and "r" in mode and not any(flag in mode for flag in ("w", "a", "x"))

    def _open_call_writes(self, node: python_ast.Call) -> bool:
        mode = None
        if len(node.args) >= 2 and isinstance(node.args[1], python_ast.Constant) and isinstance(node.args[1].value, str):
            mode = node.args[1].value
        for keyword in node.keywords:
            if keyword.arg == "mode" and isinstance(keyword.value, python_ast.Constant) and isinstance(keyword.value.value, str):
                mode = keyword.value.value
        return isinstance(mode, str) and any(flag in mode for flag in ("w", "a", "x"))

    def _call_name(self, node: python_ast.AST) -> str | None:
        if isinstance(node, python_ast.Name):
            return node.id
        if isinstance(node, python_ast.Attribute):
            parent = self._call_name(node.value)
            return f"{parent}.{node.attr}" if parent else node.attr
        return None

    def _contract_read_resource_paths(self, contract: ast_module.ContractDecl) -> set[str]:
        return {
            self._normalize_path(resource.path)
            for resource in contract.reads_resources
            if resource.type in {"file", "dir"}
        }

    def _contract_write_resource_paths(self, contract: ast_module.ContractDecl) -> set[str]:
        return {
            self._normalize_path(resource.path)
            for resource in contract.writes_resources
            if resource.type in {"file", "dir"}
        }

    def _is_business_artifact_path(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        return normalized.startswith(".lgwf/") or normalized.startswith("reports/") or normalized.startswith("data/")

    def _is_business_artifact_read_path(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        if normalized.startswith(".lgwf/child-runs/"):
            return False
        return self._is_business_artifact_path(normalized)

    def _state_reads_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        reads: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_reads(statement):
                reads.setdefault(path, []).append(node_id)
        return reads

    def _state_writes_by_path(self, ast: ast_module.WorkflowAst) -> dict[str, list[str]]:
        writes: dict[str, list[str]] = {}
        for statement in ast.statements:
            for node_id, path in self._statement_state_writes(statement):
                writes.setdefault(path, []).append(node_id)
        return writes

    def _statement_state_reads(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        statement_id = getattr(statement, "id", "")
        contract_reads = self._contract_state_reads(statement, statement_id)
        if isinstance(statement, ast_module.PythonDecl):
            reads = [(statement.id, statement.input_path.path)] if statement.input_path is not None else []
            return reads + contract_reads
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.input_path.path)] + contract_reads
        if isinstance(statement, ast_module.ApprovalDecl):
            return [(statement.id, statement.read_path.path)] + contract_reads
        if isinstance(statement, ast_module.ReviewDecl):
            return [(statement.id, statement.context_path.path)] + contract_reads
        if isinstance(statement, ast_module.ChoiceDecl):
            return [(statement.id, "input")] + contract_reads
        if isinstance(statement, ast_module.SwitchRouteDecl):
            return [(statement.id, statement.read_path.path)] + contract_reads
        if isinstance(statement, ast_module.HandoffDecl):
            return [(statement.id, statement.context_path.path)] + contract_reads
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.source_path.path)] + contract_reads
        if isinstance(statement, ast_module.CodexDecl):
            reads = []
            if statement.target_dirs_path is not None:
                reads.append((statement.id, statement.target_dirs_path.path))
            if statement.target_files_path is not None:
                reads.append((statement.id, statement.target_files_path.path))
            return reads + contract_reads
        if isinstance(statement, ast_module.ReactDecl):
            return contract_reads + [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_reads(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            reads = contract_reads
            for slot in statement.slots.values():
                reads.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_reads(slot.task))
            return reads
        if isinstance(statement, ast_module.ParallelDecl):
            return contract_reads + [
                (f"{statement.id}.{step.id}", path)
                for step in statement.steps
                for _, path in self._statement_state_reads(step.task)
            ]
        return contract_reads

    def _statement_state_writes(self, statement: ast_module.StatementDecl) -> list[tuple[str, str]]:
        statement_id = getattr(statement, "id", "")
        contract_writes = self._contract_state_writes(statement, statement_id)
        if isinstance(statement, ast_module.PythonDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.ToolDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.CodexDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.ApprovalDecl):
            writes = [(statement.id, statement.write_path.path)]
            if statement.result_path is not None:
                writes.append((statement.id, statement.result_path.path))
            return writes + contract_writes
        if isinstance(statement, ast_module.ReviewDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.HandoffDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.HandoffFilesDecl):
            return [(statement.id, statement.result_path.path)] + contract_writes
        if isinstance(statement, ast_module.RunWorkflowDecl):
            return [(statement.id, statement.result_path.path)] + contract_writes
        if isinstance(statement, ast_module.WorkflowRefDecl):
            writes = [(statement.id, statement.result_path.path)] if statement.result_path is not None else []
            return writes + contract_writes
        if isinstance(statement, ast_module.ReactDecl):
            return contract_writes + [
                (f"{statement.id}.{slot.slot_name}", path)
                for slot in statement.slots.values()
                for _, path in self._statement_state_writes(slot.task)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            writes = contract_writes
            if statement.status_path is not None:
                writes.append((statement.id, statement.status_path.path))
            if statement.report_path is not None:
                writes.append((statement.id, statement.report_path.path))
            for slot in statement.slots.values():
                writes.extend((f"{statement.id}.{slot.slot_name}", path) for _, path in self._statement_state_writes(slot.task))
            return writes
        if isinstance(statement, ast_module.ParallelDecl):
            writes = contract_writes
            for step in statement.steps:
                writes.append((f"{statement.id}.{step.id}", step.output_path.path))
                writes.append((f"{statement.id}.{step.id}", step.result_path.path))
                writes.extend((f"{statement.id}.{step.id}", path) for _, path in self._statement_state_writes(step.task))
            return writes
        return contract_writes

    def _contract_state_reads(
        self,
        statement: ast_module.StatementDecl,
        node_id: str,
    ) -> list[tuple[str, str]]:
        contract = getattr(statement, "contract", None)
        if contract is None or not node_id:
            return []
        return [(node_id, item.path) for item in contract.reads_state]

    def _contract_state_writes(
        self,
        statement: ast_module.StatementDecl,
        node_id: str,
    ) -> list[tuple[str, str]]:
        contract = getattr(statement, "contract", None)
        if contract is None or not node_id:
            return []
        return [(node_id, item.path) for item in contract.writes_state]

    def _python_decls(self, statement: ast_module.StatementDecl) -> list[ast_module.PythonDecl]:
        if isinstance(statement, ast_module.PythonDecl):
            return [statement]
        if isinstance(statement, ast_module.ReactDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.AgentLoopDecl):
            return [
                slot.task
                for slot in statement.slots.values()
                if isinstance(slot.task, ast_module.PythonDecl)
            ]
        if isinstance(statement, ast_module.ParallelDecl):
            return [
                step.task
                for step in statement.steps
                if isinstance(step.task, ast_module.PythonDecl)
            ]
        return []

    def _resolve_python_script_path(
        self,
        raw_path: str,
        defaults: ast_module.DefaultsDecl,
    ) -> pathlib.Path | None:
        root = defaults.ref_root.get("root", "workflow")
        if root != "workflow":
            return None
        base_dir = self._source_dir()
        if base_dir is None:
            return None
        ref_root_path = defaults.ref_root.get("path", ".")
        resolved_base = self._resolve_relative(base_dir, ref_root_path)
        if resolved_base is None:
            return None
        return self._resolve_relative(resolved_base, raw_path)

    def _is_external_initial_input(self, path: str) -> bool:
        normalized = self._normalize_path(path)
        return normalized in {"input", "target", "pipeline.target"}

    def _resource_diagnostic(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
        suggestion: str,
    ) -> diagnostics_module.Diagnostic:
        return diagnostics_module.Diagnostic(
            f"{label} resource not found or invalid: {raw_path}",
            location,
            severity="error",
            code="LGWF_RESOURCE_MISSING",
            suggestion=suggestion,
        )

    def _lint_parallel_contexts(
        self,
        parallel: ast_module.ParallelDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        diagnostics: list[diagnostics_module.Diagnostic] = []
        for step in parallel.steps:
            codex_tasks = self._codex_tasks(step.task)
            if codex_tasks and not any(self._has_explicit_codex_scope(task) for task in codex_tasks):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PARALLEL {parallel.id} step {step.id} has no CODEX context_refs or targets; parallel steps should organize context through files, explicit refs, or analysis targets.",
                        step.location or parallel.location,
                    )
                )
            if isinstance(step.task, ast_module.ReactDecl):
                diagnostics.extend(self._lint_react_observe_scope(step.task, context_sets))
                diagnostics.extend(self._lint_react_observe_feedback_loop(step.task, context_sets))
        return diagnostics

    def _codex_tasks(
        self,
        task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.ReactDecl,
    ) -> list[ast_module.CodexDecl]:
        if isinstance(task, ast_module.CodexDecl):
            return [task]
        if isinstance(task, ast_module.ReactDecl):
            return [
                slot.task
                for slot in task.slots.values()
                if isinstance(slot.task, ast_module.CodexDecl)
            ]
        return []

    def _has_explicit_codex_scope(self, task: ast_module.CodexDecl) -> bool:
        return bool(
            task.contexts
            or task.target_dirs
            or task.target_files
            or task.target_dirs_path is not None
            or task.target_files_path is not None
        )

    def _lint_react_observe_scope(
        self,
        react: ast_module.ReactDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        observe_slot = react.slots.get("observe")
        if observe_slot is None or not isinstance(observe_slot.task, ast_module.CodexDecl):
            return []

        observed_paths = {
            self._normalize_path(resource.path)
            for resource in self._react_slot_contexts(react, observe_slot.task, context_sets)
            if resource.type == "file"
        }

        required_paths: set[str] = set()
        for slot_name in ("reason", "act"):
            slot = react.slots.get(slot_name)
            if slot is None or not isinstance(slot.task, ast_module.CodexDecl):
                continue
            for resource in self._react_slot_contexts(react, slot.task, context_sets):
                path = self._normalize_path(resource.path)
                if self._is_factual_data_file(resource.type, path):
                    required_paths.add(path)

        missing_paths = sorted(required_paths - observed_paths)
        if not missing_paths:
            return []

        missing_text = ", ".join(missing_paths)
        return [
            diagnostics_module.Diagnostic(
                f"REACT {react.id} observe context_refs missing input file used by reason/act: {missing_text}",
                observe_slot.location or react.location,
            )
        ]

    def _lint_react_observe_feedback_loop(
        self,
        react: ast_module.ReactDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[diagnostics_module.Diagnostic]:
        observe_slot = react.slots.get("observe")
        reason_slot = react.slots.get("reason")
        if (
            observe_slot is None
            or reason_slot is None
            or not isinstance(observe_slot.task, ast_module.CodexDecl)
            or not isinstance(reason_slot.task, ast_module.CodexDecl)
            or observe_slot.task.output_json_path is None
        ):
            return []

        observe_output_path = self._normalize_path(observe_slot.task.output_json_path)
        reason_context_paths = {
            self._normalize_path(resource.path)
            for resource in self._react_slot_contexts(react, reason_slot.task, context_sets)
            if resource.root == "workspace" and resource.type == "file"
        }
        if observe_output_path in reason_context_paths:
            return []

        return [
            diagnostics_module.Diagnostic(
                f"REACT {react.id} reason context_refs missing observe OUTPUT_JSON feedback file: {observe_output_path}",
                reason_slot.location or react.location,
                code="LGWF_REACT_FEEDBACK_LOOP_MISSING",
                suggestion=(
                    f'Add CONTEXT workspace file "{observe_output_path}" to the REACT reason slot. '
                    "If the file is absent on the first iteration, initialize an empty/default artifact before the REACT block."
                ),
            )
        ]

    def _lint_repeated_react_inline_contexts(
        self,
        react: ast_module.ReactDecl,
    ) -> list[diagnostics_module.Diagnostic]:
        refs: dict[tuple[str, str, str], list[str]] = {}
        for slot_name, slot in react.slots.items():
            if not isinstance(slot.task, ast_module.CodexDecl):
                continue
            for context in slot.task.contexts:
                if context.resource is None:
                    continue
                resource = context.resource
                key = (resource.root, resource.type, self._normalize_path(resource.path))
                refs.setdefault(key, []).append(slot_name)
        repeated = [
            (key, sorted(set(slot_names)))
            for key, slot_names in refs.items()
            if len(set(slot_names)) >= 2
        ]
        if not repeated:
            return []
        details = ", ".join(
            f"{root} {resource_type} {path} in {','.join(slot_names)}"
            for (root, resource_type, path), slot_names in repeated
        )
        return [
            diagnostics_module.Diagnostic(
                f"REACT {react.id} repeats inline CONTEXT refs: {details}",
                react.location,
                code="LGWF_CONTEXT_REPEAT",
                suggestion=(
                    "Extract repeated refs into a CONTEXT_SET and reference it once at REACT level, "
                    "or keep the repeat only if each slot intentionally needs a separate explicit audit trail."
                ),
            )
        ]

    def _context_sets(self, ast: ast_module.WorkflowAst) -> dict[str, ast_module.ContextSetDecl]:
        return {
            statement.name: statement
            for statement in ast.statements
            if isinstance(statement, ast_module.ContextSetDecl)
        }

    def _expand_contexts(
        self,
        contexts: Iterable[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[ast_module.ResourceRef]:
        resources: list[ast_module.ResourceRef] = []
        for context in contexts:
            if context.resource is not None:
                resources.append(context.resource)
            elif context.context_set is not None and context.context_set in context_sets:
                resources.extend(self._context_set_resources(context.context_set, context_sets))
        return resources

    def _react_slot_contexts(
        self,
        react: ast_module.ReactDecl,
        task: ast_module.CodexDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> list[ast_module.ResourceRef]:
        return [
            *self._expand_contexts(react.contexts, context_sets),
            *self._expand_contexts(task.contexts, context_sets),
        ]

    def _context_set_resources(
        self,
        name: str,
        context_sets: dict[str, ast_module.ContextSetDecl],
        stack: tuple[str, ...] = (),
    ) -> list[ast_module.ResourceRef]:
        if name not in context_sets or name in stack:
            return []
        context_set = context_sets[name]
        resources: list[ast_module.ResourceRef] = []
        for parent in context_set.extends:
            resources.extend(self._context_set_resources(parent, context_sets, (*stack, name)))
        resources.extend(context_set.resources)
        return resources

    def _is_factual_data_file(self, resource_type: str, path: str) -> bool:
        parsed = PurePosixPath(path)
        return resource_type == "file" and parsed.parts[:1] == ("data",) and parsed.suffix in {".json", ".md"}

    def _normalize_path(self, path: str) -> str:
        return path.replace("\\", "/")
