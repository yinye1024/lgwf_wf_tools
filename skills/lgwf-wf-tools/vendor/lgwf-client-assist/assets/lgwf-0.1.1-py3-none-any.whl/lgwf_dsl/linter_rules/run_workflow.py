import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def invalid_run_workflow_work_dir(
    linter,
    statement: ast_module.RunWorkflowDecl,
) -> diagnostics_module.Diagnostic | None:
    path = pathlib.Path(statement.work_dir)
    if not path.is_absolute() and ".." not in path.parts:
        return None
    return diagnostics_module.Diagnostic(
        f"RUN_WORKFLOW WORK_DIR path is invalid: {statement.work_dir}",
        statement.location,
        severity="error",
        code="LGWF_RUN_WORKFLOW_WORK_DIR_INVALID",
        suggestion="Use a relative WORK_DIR path without '..'. The child workflow owns that work_dir runtime state.",
    )

def lint_run_workflow_handoffs(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    run_workflows = [
        statement
        for statement in ast.statements
        if isinstance(statement, ast_module.RunWorkflowDecl)
    ]
    if not run_workflows:
        return []

    diagnostics: list[diagnostics_module.Diagnostic] = []
    diagnostics.extend(_lint_reused_run_workflow_work_dirs(linter, run_workflows))
    diagnostics.extend(_lint_run_workflow_state_links(linter, ast, run_workflows))
    diagnostics.extend(_lint_python_child_runs_data_channel(linter, ast, defaults))
    return diagnostics

def _lint_reused_run_workflow_work_dirs(
    linter,
    run_workflows: list[ast_module.RunWorkflowDecl],
) -> list[diagnostics_module.Diagnostic]:
    first_by_work_dir: dict[str, ast_module.RunWorkflowDecl] = {}
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in run_workflows:
        normalized = linter._normalize_path(statement.work_dir)
        previous = first_by_work_dir.get(normalized)
        if previous is None:
            first_by_work_dir[normalized] = statement
            continue
        diagnostics.append(
            diagnostics_module.Diagnostic(
                f"RUN_WORKFLOW {statement.id} reuses WORK_DIR '{statement.work_dir}' already used by {previous.id}.",
                statement.location,
                severity="info",
                code="LGWF_RUN_WORKFLOW_WORK_DIR_REUSED",
                suggestion="Give each child workflow a distinct WORK_DIR unless runs are guaranteed never to overlap.",
            )
        )
    return diagnostics

def _lint_run_workflow_state_links(
    linter,
    ast: ast_module.WorkflowAst,
    run_workflows: list[ast_module.RunWorkflowDecl],
) -> list[diagnostics_module.Diagnostic]:
    reads = linter._state_reads_by_path(ast)
    writes = linter._state_writes_by_path(ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    final_run_workflow = run_workflows[-1] if len(run_workflows) > 1 else None
    for statement in run_workflows:
        result_path = statement.result_path.path
        result_readers = [
            node_id
            for node_id in reads.get(result_path, [])
            if node_id != statement.id
        ]
        if not result_readers and statement != final_run_workflow:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"RUN_WORKFLOW {statement.id} RESULT state.{result_path} is not consumed by a later node.",
                    statement.location,
                    severity="info",
                    code="LGWF_RUN_WORKFLOW_RESULT_UNCONSUMED",
                    suggestion="Feed the child result into a PY map_* node or a downstream workflow input, or remove the unused RESULT.",
                )
            )

        input_path = statement.input_path.path
        if linter._is_external_initial_input(input_path):
            continue
        input_writers = [
            node_id
            for node_id in writes.get(input_path, [])
            if node_id != statement.id
        ]
        if not input_writers:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"RUN_WORKFLOW {statement.id} INPUT state.{input_path} has no obvious upstream writer.",
                    statement.location,
                    severity="info",
                    code="LGWF_RUN_WORKFLOW_INPUT_UNWRITTEN",
                    suggestion="Prepare the child input with an upstream PY map_* node or document it as an initial workflow input.",
                )
            )
    return diagnostics

def _lint_python_child_runs_data_channel(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for python in linter._python_decls(statement):
            if python.input_path is None:
                continue
            script_path = linter._resolve_python_script_path(python.script_path, defaults)
            if script_path is None or not script_path.is_file():
                continue
            try:
                content = script_path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            normalized = content.replace("\\", "/")
            if ".lgwf/child-runs" not in normalized:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    f"PY {python.id} reads .lgwf/child-runs as a data channel.",
                    python.location,
                    severity="info",
                    code="LGWF_PY_CHILD_RUNS_DATA_CHANNEL",
                    suggestion="Read the upstream object from PY INPUT stdin or from RUN_WORKFLOW RESULT state instead of .lgwf/child-runs.",
                )
            )
    return diagnostics
