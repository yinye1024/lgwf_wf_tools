import pathlib
from pathlib import PurePosixPath
import re

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module


def lint_python_contracts(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for python in linter._python_decls(statement):
            contract = python.contract
            reads = linter._python_script_file_reads(python, defaults)
            business_reads = sorted(path for path in reads["paths"] if linter._is_business_artifact_read_path(path))
            has_unknown_business_read = bool(reads["unknown"]) and contract is None
            if business_reads or has_unknown_business_read:
                if contract is None:
                    paths = ", ".join(business_reads) if business_reads else "unknown dynamic path"
                    diagnostics.append(
                        diagnostics_module.Diagnostic(
                            f"PY {python.id} reads business artifact file(s) without CONTRACT: {paths}.",
                            python.location,
                            severity="error",
                            code="LGWF_PY_FILE_READ_CONTRACT_MISSING",
                            suggestion="Declare CONTRACT READ workspace file entries for every business artifact read by this Python script.",
                        )
                    )
                else:
                    declared_reads = linter._contract_read_resource_paths(contract)
                    missing_reads = [path for path in business_reads if path not in declared_reads]
                    if missing_reads:
                        declared_text = ", ".join(sorted(declared_reads)) if declared_reads else "<none>"
                        diagnostics.append(
                            diagnostics_module.Diagnostic(
                                (
                                    f"PY {python.id} reads file(s) not declared in CONTRACT: "
                                    f"{', '.join(missing_reads)}. Declared reads: {declared_text}."
                                ),
                                python.location,
                                severity="error",
                                code="LGWF_PY_FILE_READ_CONTRACT_MISMATCH",
                                suggestion="Add matching CONTRACT READ workspace file entries, or update the script to read only declared artifacts.",
                            )
                        )

            writes = linter._python_script_file_writes(python, defaults)
            business_writes = sorted(path for path in writes["paths"] if linter._is_business_artifact_path(path))
            has_unknown_business_write = bool(writes["unknown"]) and contract is None
            if not business_writes and not has_unknown_business_write:
                continue

            if contract is None:
                paths = ", ".join(business_writes) if business_writes else "unknown dynamic path"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"PY {python.id} writes business artifact file(s) without CONTRACT: {paths}.",
                        python.location,
                        severity="error",
                        code="LGWF_PY_FILE_WRITE_CONTRACT_MISSING",
                        suggestion="Declare CONTRACT WRITE workspace file entries for every business artifact written by this Python script.",
                    )
                )
                continue

            declared = linter._contract_write_resource_paths(contract)
            missing = [path for path in business_writes if path not in declared]
            if missing:
                declared_text = ", ".join(sorted(declared)) if declared else "<none>"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"PY {python.id} writes file(s) not declared in CONTRACT: "
                            f"{', '.join(missing)}. Declared writes: {declared_text}."
                        ),
                        python.location,
                        severity="error",
                        code="LGWF_PY_FILE_WRITE_CONTRACT_MISMATCH",
                        suggestion="Add matching CONTRACT WRITE workspace file entries, or update the script to write only declared artifacts.",
                    )
                )
    return diagnostics

def lint_codex_prompt_contracts(
    linter,
    ast: ast_module.WorkflowAst,
    defaults: ast_module.DefaultsDecl,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for codex in linter._codex_decls(statement):
            prompt_refs = _codex_prompt_file_refs(linter, codex, defaults)
            if not prompt_refs:
                continue
            if codex.contract is None:
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"CODEX {codex.id} prompt references business artifact file(s) "
                            f"without CONTRACT READ: {', '.join(prompt_refs)}."
                        ),
                        codex.location,
                        severity="error",
                        code="LGWF_CODEX_PROMPT_FILE_READ_CONTRACT_MISSING",
                        suggestion=(
                            "Declare CONTRACT READ workspace file entries for every business artifact "
                            "referenced by this Codex prompt."
                        ),
                    )
                )
                continue

            declared_reads = linter._contract_read_workspace_file_paths(codex.contract)
            missing = [path for path in prompt_refs if path not in declared_reads]
            if missing:
                declared_text = ", ".join(sorted(declared_reads)) if declared_reads else "<none>"
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        (
                            f"CODEX {codex.id} prompt references file(s) not declared in CONTRACT READ: "
                            f"{', '.join(missing)}. Declared reads: {declared_text}."
                        ),
                        codex.location,
                        severity="error",
                        code="LGWF_CODEX_PROMPT_FILE_READ_CONTRACT_MISMATCH",
                        suggestion=(
                            "Add matching CONTRACT READ workspace file entries, or remove the prompt references "
                            "to undeclared business artifacts."
                        ),
                    )
                )
    return diagnostics

def _codex_prompt_file_refs(
    linter,
    codex: ast_module.CodexDecl,
    defaults: ast_module.DefaultsDecl,
) -> list[str]:
    prompt_path = _resolve_codex_prompt_path(linter, codex.prompt_path, defaults)
    if prompt_path is None or not prompt_path.is_file():
        return []
    text = prompt_path.read_text(encoding="utf-8")
    refs: set[str] = set()

    for match in re.finditer(r"\[[^\]]*\]\(([^)\s]+)(?:\s+[^)]*)?\)", text):
        ref = _normalize_prompt_file_ref(linter, match.group(1))
        if ref is not None:
            refs.add(ref)
    for match in re.finditer(r"`([^`\n]+)`", text):
        ref = _normalize_prompt_file_ref(linter, match.group(1))
        if ref is not None:
            refs.add(ref)
    for match in re.finditer(
        r"(?<![\w./-])(?:\.lgwf|data|reports)/[A-Za-z0-9._~!$&'()*+,;=:@/%-]+\.[A-Za-z0-9][A-Za-z0-9._-]*",
        text,
    ):
        ref = _normalize_prompt_file_ref(linter, match.group(0))
        if ref is not None:
            refs.add(ref)

    return sorted(refs)

def _normalize_prompt_file_ref(linter, raw_path: str) -> str | None:
    value = raw_path.strip().strip("<>").strip()
    if not value or "://" in value or value.startswith("#"):
        return None
    value = value.split()[0]
    value = value.split("#", 1)[0].split("?", 1)[0]
    value = value.strip("\"'")
    value = value.rstrip(".,;:)]}\"'")
    value = value.replace("\\", "/")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.suffix:
        return None
    normalized = path.as_posix()
    if not linter._is_business_artifact_read_path(normalized):
        return None
    return normalized

def _resolve_codex_prompt_path(
    linter,
    raw_path: str,
    defaults: ast_module.DefaultsDecl,
) -> pathlib.Path | None:
    root = defaults.ref_root.get("root", "workflow")
    if root != "workflow":
        return None
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    ref_root_path = defaults.ref_root.get("path", ".")
    resolved_base = linter._resolve_relative(base_dir, ref_root_path)
    if resolved_base is None:
        return None
    return linter._resolve_relative(resolved_base, raw_path)

def lint_redundant_contract_state_writes(
    linter,
    ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        diagnostics.extend(_lint_statement_redundant_contract_state_writes(linter, statement))
    return diagnostics

def lint_redundant_codex_output_contract_writes(
    linter,
    ast: ast_module.WorkflowAst,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        for codex in linter._codex_decls(statement):
            contract = codex.contract
            if contract is None:
                continue
            output_paths = {
                linter._normalize_path(path)
                for path in (codex.output_json_path, codex.output_file_path)
                if path is not None
            }
            if not output_paths:
                continue
            redundant = sorted(
                linter._normalize_path(resource.path)
                for resource in contract.writes_resources
                if resource.root == "workspace"
                and resource.type == "file"
                and linter._normalize_path(resource.path) in output_paths
            )
            if not redundant:
                continue
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"CODEX {codex.id} CONTRACT WRITE repeats CODEX output file "
                        f"declaration: {', '.join(redundant)}."
                    ),
                    codex.location,
                    severity="error",
                    code="LGWF_CONTRACT_OUTPUT_WRITE_REDUNDANT",
                    suggestion=(
                        "OUTPUT_JSON/OUTPUT_FILE already declares this Codex output artifact; "
                        "remove the duplicate CONTRACT WRITE workspace file entry."
                    ),
                )
            )
    return diagnostics

def _lint_statement_redundant_contract_state_writes(
    linter,
    statement: ast_module.StatementDecl,
    label_prefix: str | None = None,
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    contract = getattr(statement, "contract", None)
    node_id = getattr(statement, "id", "")
    label = f"{label_prefix}.{node_id}" if label_prefix and node_id else node_id or label_prefix or "node"
    if contract is not None:
        contract_writes = {item.path for item in contract.writes_state}
        result_path = getattr(statement, "result_path", None)
        if isinstance(result_path, ast_module.StateRef) and result_path.path in contract_writes:
            diagnostics.append(
                diagnostics_module.Diagnostic(
                    (
                        f"{label} CONTRACT WRITE state.{result_path.path} repeats "
                        f"RESULT state.{result_path.path}."
                    ),
                    getattr(statement, "location", None),
                    severity="error",
                    code="LGWF_CONTRACT_RESULT_WRITE_REDUNDANT",
                    suggestion="RESULT already declares this execution result state path; remove the duplicate CONTRACT WRITE state entry.",
                )
            )
        if isinstance(statement, ast_module.PythonDecl):
            update_paths = {item.path for item in statement.state_update_writes}
            for path in sorted(contract_writes & update_paths):
                diagnostics.append(
                    diagnostics_module.Diagnostic(
                        f"{label} CONTRACT WRITE state.{path} repeats UPDATES_STATE WRITE state.{path}.",
                        statement.location,
                        severity="error",
                        code="LGWF_CONTRACT_UPDATES_STATE_WRITE_REDUNDANT",
                        suggestion="UPDATES_STATE already declares this stdout state patch path; remove the duplicate CONTRACT WRITE state entry.",
                    )
                )

    if isinstance(statement, ast_module.ReactDecl):
        for slot in statement.slots.values():
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    slot.task,
                    f"{statement.id}.{slot.slot_name}",
                )
            )
    elif isinstance(statement, ast_module.AgentLoopDecl):
        for slot in statement.slots.values():
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    slot.task,
                    f"{statement.id}.{slot.slot_name}",
                )
            )
    elif isinstance(statement, ast_module.ParallelDecl):
        for step in statement.steps:
            diagnostics.extend(
                _lint_statement_redundant_contract_state_writes(linter, 
                    step.task,
                    f"{statement.id}.{step.id}",
                )
            )
    return diagnostics
