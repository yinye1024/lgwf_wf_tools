from collections.abc import Iterable
import pathlib

import lgwf_dsl.ast as ast_module
import lgwf_dsl.diagnostics as diagnostics_module
import lgwf_dsl.linter_rules.run_workflow as run_workflow_rules_module
import lgwf_dsl.parser as parser_module
import lgwf_dsl.validator as validator_module


def lint_authoring_resources(
    linter,
    ast: ast_module.WorkflowAst,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    if ast.source_name is None and linter.package_root is None:
        return []

    defaults = linter._defaults(ast)
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for statement in ast.statements:
        diagnostics.extend(_lint_statement_resources(linter, statement, defaults, context_sets))
    return diagnostics

def _lint_statement_resources(
    linter,
    statement: ast_module.StatementDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    if isinstance(statement, ast_module.PythonDecl):
        missing = _missing_task_resource(linter, statement.script_path, "SCRIPT", defaults, statement.location)
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.CodexDecl):
        diagnostics = [_missing_task_resource(linter, statement.prompt_path, "PROMPT", defaults, statement.location)]
        diagnostics.extend(_lint_context_resources(linter, statement.contexts, context_sets))
        return [diagnostic for diagnostic in diagnostics if diagnostic is not None]
    if isinstance(statement, ast_module.ApprovalDecl) and statement.prompt_ref_path is not None:
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT_REF",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ReviewDecl):
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ChoiceDecl):
        missing = _missing_workflow_resource(linter, 
            statement.prompt_ref_path,
            "PROMPT_REF",
            statement.location,
        )
        return [missing] if missing is not None else []
    if isinstance(statement, ast_module.ReactDecl):
        diagnostics: list[diagnostics_module.Diagnostic] = []
        if statement.spec_path is not None:
            missing = _missing_task_resource(linter, 
                statement.spec_path,
                "SPEC",
                defaults,
                statement.location,
            )
            if missing is not None:
                diagnostics.append(missing)
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_resources(linter, slot.task, defaults, context_sets))
        return diagnostics
    if isinstance(statement, ast_module.AgentLoopDecl):
        diagnostics = []
        diagnostics.extend(_lint_context_resources(linter, statement.contexts, context_sets))
        for slot in statement.slots.values():
            diagnostics.extend(_lint_statement_resources(linter, slot.task, defaults, context_sets))
        return diagnostics
    if isinstance(statement, ast_module.WorkflowRefDecl):
        missing = _missing_workflow_ref(linter, statement.workflow_path, statement.location)
        if missing is not None:
            return [missing]
        return _lint_child_workflow(linter, statement)
    if isinstance(statement, ast_module.RunWorkflowDecl):
        diagnostics = []
        invalid_work_dir = run_workflow_rules_module.invalid_run_workflow_work_dir(linter, statement)
        if invalid_work_dir is not None:
            diagnostics.append(invalid_work_dir)
        missing = _missing_external_workflow(linter, statement.workflow_path, statement.location)
        if missing is not None:
            diagnostics.append(missing)
        return diagnostics
    if isinstance(statement, ast_module.ParallelDecl):
        diagnostics = []
        for step in statement.steps:
            diagnostics.extend(_lint_statement_resources(linter, step.task, defaults, context_sets))
        return diagnostics
    return []

def _lint_context_resources(
    linter,
    contexts: Iterable[ast_module.ContextRef],
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> list[diagnostics_module.Diagnostic]:
    diagnostics: list[diagnostics_module.Diagnostic] = []
    for context in contexts:
        resources: list[ast_module.ResourceRef] = []
        if context.resource is not None:
            resources.append(context.resource)
        elif context.context_set is not None and context.context_set in context_sets:
            resources.extend(linter._context_set_resources(context.context_set, context_sets))
        for resource in resources:
            if resource.root != "workflow":
                continue
            missing = _missing_workflow_resource(linter, resource.path, f"CONTEXT workflow {resource.type}", resource.location)
            if missing is not None:
                diagnostics.append(missing)
    return diagnostics

def _missing_task_resource(
    linter,
    raw_path: str,
    label: str,
    defaults: ast_module.DefaultsDecl,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    root = defaults.ref_root.get("root", "workflow")
    if root != "workflow":
        return None
    ref_root_path = defaults.ref_root.get("path", ".")
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved_base = linter._resolve_relative(base_dir, ref_root_path)
    if resolved_base is None:
        return linter._resource_diagnostic(ref_root_path, "ref_root", location, "ref_root path must be relative and stay inside the workflow package.")
    resolved = linter._resolve_relative(resolved_base, raw_path)
    if resolved is None or not resolved.is_file():
        return linter._resource_diagnostic(raw_path, label, location, f"Create the {label} file or update its path to an existing workflow package file.")
    return None

def _missing_workflow_resource(
    linter,
    raw_path: str,
    label: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, raw_path)
    if resolved is None:
        return linter._resource_diagnostic(raw_path, label, location, "Use a relative path inside the workflow package.")
    if not resolved.exists():
        return linter._resource_diagnostic(raw_path, label, location, f"Create the referenced {label} resource or update the path.")
    return None

def _missing_workflow_ref(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    base_dir = linter._source_dir()
    if base_dir is None:
        return None
    resolved = linter._resolve_relative(base_dir, raw_path)
    if resolved is None or pathlib.PurePath(raw_path).suffix.lower() != ".lgwf" or not resolved.is_file():
        return linter._resource_diagnostic(raw_path, "STEP WORKFLOW", location, "Point STEP WORKFLOW at an existing relative .lgwf file inside the workflow package.")
    return None

def _missing_external_workflow(
    linter,
    raw_path: str,
    location: diagnostics_module.SourceLocation | None,
) -> diagnostics_module.Diagnostic | None:
    path = pathlib.Path(raw_path)
    if path.is_absolute() or ".." in path.parts or path.suffix.lower() != ".lgwf":
        return linter._resource_diagnostic(
            raw_path,
            "RUN_WORKFLOW WORKFLOW",
            location,
            "Use a relative path to an existing child workflow.lgwf file.",
        )
    if not path.resolve().is_file():
        return linter._resource_diagnostic(
            raw_path,
            "RUN_WORKFLOW WORKFLOW",
            location,
            "Create the child workflow.lgwf file or update RUN_WORKFLOW WORKFLOW.",
        )
    return None


def _lint_child_workflow(linter, ref: ast_module.WorkflowRefDecl) -> list[diagnostics_module.Diagnostic]:
    base_dir = linter._source_dir()
    if base_dir is None:
        return []
    child_path = linter._resolve_relative(base_dir, ref.workflow_path)
    if child_path is None or not child_path.is_file():
        return []
    source = child_path.read_text(encoding="utf-8")
    child_ast = parser_module.Parser.from_text(source, source_name=str(child_path)).parse_workflow()
    validator_module.WorkflowValidator().validate(child_ast)
    return linter.lint(child_ast)
