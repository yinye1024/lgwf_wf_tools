import lgwf_dsl.ast as ast_module
import lgwf_dsl.catalog as catalog_module
import lgwf_dsl.diagnostics as diagnostics_module
import lgwf_dsl.errors as errors_module
import lgwf_dsl.statements.agent_loop as agent_loop_statement_module
import lgwf_dsl.statements.choice as choice_statement_module
import lgwf_dsl.statements.parallel as parallel_statement_module
import lgwf_dsl.statements.react as react_statement_module
import lgwf_dsl.statements.sandbox as sandbox_statement_module
import lgwf_client.tools.catalog as tool_catalog_module
import lgwf.control_flow as control_flow_module
import pathlib


class WorkflowValidator:
    def __init__(self, catalog: catalog_module.CapabilityCatalogView | None = None) -> None:
        self.catalog = catalog or catalog_module.CapabilityCatalogView.load_default()

    def validate(self, ast: ast_module.WorkflowAst) -> None:
        node_ids = self._node_ids(ast)
        flow_aliases = self._flow_aliases(ast, node_ids)
        target_ids = node_ids | set(flow_aliases)
        context_sets = self._context_sets(ast)
        self._validate_runtime_capabilities(ast)
        self._validate_defaults(ast)
        self._validate_sandbox(ast.sandbox)
        self._validate_codex_output_paths(ast)
        self._validate_route_source_conflicts(ast)
        self._validate_context_set_extends(context_sets)

        if ast.entry_kind == "FLOW":
            if ast.entry_point not in flow_aliases:
                self._raise(f"Unknown entry flow: {ast.entry_point}", ast.location)
        elif ast.entry_kind == "NODE":
            if ast.entry_point not in node_ids:
                self._raise(f"Unknown entry node: {ast.entry_point}", ast.location)
        elif ast.entry_point not in target_ids:
            self._raise(f"Unknown entry_point: {ast.entry_point}", ast.location)

        for name, context_set in context_sets.items():
            if name in node_ids:
                self._raise(f"Context set name collides with node id: {name}", context_set.location)

        for statement in ast.statements:
            self._validate_statement_contract(statement)
            if isinstance(statement, ast_module.EdgeDecl):
                self._validate_node_ref(statement.from_node, node_ids, "edge source", statement.location)
                self._validate_node_ref(statement.to_node, node_ids, "edge target", statement.location)
            elif isinstance(statement, ast_module.FlowDecl):
                for node_id in statement.nodes:
                    self._validate_node_ref(node_id, node_ids, "flow", statement.location)
            elif isinstance(statement, ast_module.RouteDecl):
                self._validate_node_ref(statement.from_node, node_ids, "route source", statement.location)
                for target in statement.branches.values():
                    if control_flow_module.is_fail_all_target(target):
                        continue
                    self._validate_node_ref(target, target_ids, "route target", statement.location)
            elif isinstance(statement, ast_module.SwitchRouteDecl):
                for target in statement.branches.values():
                    if control_flow_module.is_fail_all_target(target):
                        continue
                    self._validate_node_ref(target, target_ids, "route target", statement.location)
            elif isinstance(statement, ast_module.CodexDecl):
                self._validate_context_refs(statement.contexts, context_sets)
            elif isinstance(statement, ast_module.ApprovalDecl):
                if statement.persist_path is not None:
                    self._validate_relative_path(statement.persist_path, "APPROVAL PERSIST path", statement.location)
                for target in statement.routes.values():
                    if control_flow_module.is_fail_all_target(target):
                        continue
                    self._validate_node_ref(target, target_ids, "route target", statement.location)
            elif isinstance(statement, ast_module.ReviewDecl):
                self._validate_relative_path(statement.prompt_ref_path, "REVIEW PROMPT path", statement.location)
                if statement.persist_path is not None:
                    self._validate_relative_path(statement.persist_path, "REVIEW PERSIST path", statement.location)
                for target in statement.routes.values():
                    if control_flow_module.is_fail_all_target(target):
                        continue
                    self._validate_node_ref(target, target_ids, "route target", statement.location)
            elif isinstance(statement, ast_module.ChoiceDecl):
                choice_statement_module.validate_choice(self, statement, target_ids)
            elif isinstance(statement, ast_module.ToolDecl):
                self._validate_tool(statement)
            elif isinstance(statement, ast_module.RunWorkflowDecl):
                self._validate_run_workflow(statement)
            elif isinstance(statement, ast_module.ReactDecl):
                self._validate_react_context_refs(statement, context_sets)
            elif isinstance(statement, ast_module.AgentLoopDecl):
                self._validate_agent_loop(statement, context_sets)
            elif isinstance(statement, ast_module.ParallelDecl):
                self._validate_parallel(statement, context_sets)

    def _validate_defaults(self, ast: ast_module.WorkflowAst) -> None:
        for statement in ast.statements:
            if not isinstance(statement, ast_module.DefaultsDecl):
                continue
            root = statement.ref_root.get("root")
            if root not in {"workflow", "workspace"}:
                self._raise("ref_root root must be workflow or workspace.", statement.location)
            path = statement.ref_root.get("path")
            if not isinstance(path, str) or not path:
                self._raise("ref_root path must be a non-empty string.", statement.location)
            self._validate_relative_path(path, "ref_root path", statement.location)

    def _validate_run_workflow(self, statement: ast_module.RunWorkflowDecl) -> None:
        self._validate_relative_path(statement.workflow_path, "RUN_WORKFLOW WORKFLOW path", statement.location)
        if pathlib.PurePosixPath(statement.workflow_path.replace("\\", "/")).suffix.lower() != ".lgwf":
            self._raise("RUN_WORKFLOW WORKFLOW path must reference a .lgwf file.", statement.location)
        self._validate_run_workflow_work_dir(statement)

    def _validate_run_workflow_work_dir(self, statement: ast_module.RunWorkflowDecl) -> None:
        path_text = statement.work_dir.replace("\\", "/")
        path = pathlib.PurePosixPath(path_text)
        windows_path = pathlib.PureWindowsPath(statement.work_dir)
        if path.is_absolute() or windows_path.is_absolute() or windows_path.drive or ".." in path.parts:
            self._raise(
                f"RUN_WORKFLOW WORK_DIR path is invalid: {statement.work_dir}",
                statement.location,
                code="LGWF_RUN_WORKFLOW_WORK_DIR_INVALID",
                suggestion="Use a relative WORK_DIR path without '..'. The child workflow owns that work_dir runtime state.",
            )

    def _validate_codex_output_paths(self, ast: ast_module.WorkflowAst) -> None:
        paths: dict[str, str] = {}
        for codex in self._codex_decls(ast):
            self._validate_codex_output_path(paths, codex.output_json_path, "OUTPUT_JSON", codex.location)
            self._validate_codex_output_path(paths, codex.output_file_path, "OUTPUT_FILE", codex.location)

    def _validate_codex_output_path(
        self,
        paths: dict[str, str],
        raw_path: str | None,
        kind: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> None:
        if raw_path is None:
            return
        self._validate_relative_path(raw_path, f"CODEX {kind} path", location)
        path = pathlib.PurePosixPath(raw_path.replace("\\", "/")).as_posix()
        existing = paths.get(path)
        if existing is not None:
            self._raise(f"Duplicate CODEX output path: {path} ({existing} and {kind})", location)
        paths[path] = kind

    def _codex_decls(self, ast: ast_module.WorkflowAst) -> list[ast_module.CodexDecl]:
        codex_decls: list[ast_module.CodexDecl] = []
        for statement in ast.statements:
            self._collect_codex_decls(statement, codex_decls)
        return codex_decls

    def _validate_route_source_conflicts(self, ast: ast_module.WorkflowAst) -> None:
        inline_route_sources: dict[str, str] = {}
        external_route_sources: dict[str, ast_module.RouteDecl] = {}
        for statement in ast.statements:
            if isinstance(statement, ast_module.ApprovalDecl) and statement.routes:
                inline_route_sources[statement.id] = "APPROVAL"
            elif isinstance(statement, ast_module.ReviewDecl) and statement.routes:
                inline_route_sources[statement.id] = "REVIEW"
            elif isinstance(statement, ast_module.ChoiceDecl) and statement.routes:
                inline_route_sources[statement.id] = "CHOICE"
            elif isinstance(statement, ast_module.RouteDecl):
                external_route_sources[statement.from_node] = statement
        for source, route in external_route_sources.items():
            inline_kind = inline_route_sources.get(source)
            if inline_kind is not None:
                self._raise(
                    f"{inline_kind} inline ROUTES for {source} conflict with external ROUTE.",
                    route.location,
                )

    def _collect_codex_decls(self, statement: object, codex_decls: list[ast_module.CodexDecl]) -> None:
        if isinstance(statement, ast_module.CodexDecl):
            codex_decls.append(statement)
        elif isinstance(statement, ast_module.ReactDecl):
            for slot in statement.slots.values():
                self._collect_codex_decls(slot.task, codex_decls)
        elif isinstance(statement, ast_module.AgentLoopDecl):
            for slot in statement.slots.values():
                self._collect_codex_decls(slot.task, codex_decls)
        elif isinstance(statement, ast_module.ParallelDecl):
            for step in statement.steps:
                self._collect_codex_decls(step.task, codex_decls)

    def _node_ids(self, ast: ast_module.WorkflowAst) -> set[str]:
        node_ids: set[str] = set()
        for statement in ast.statements:
            if not isinstance(
                statement,
                (
                    ast_module.PythonDecl,
                    ast_module.ToolDecl,
                    ast_module.CodexDecl,
                    ast_module.ApprovalDecl,
                    ast_module.ReviewDecl,
                    ast_module.ChoiceDecl,
                    ast_module.HandoffDecl,
                    ast_module.HandoffFilesDecl,
                    ast_module.RunWorkflowDecl,
                    ast_module.ReactDecl,
                    ast_module.AgentLoopDecl,
                    ast_module.WorkflowRefDecl,
                    ast_module.ParallelDecl,
                    ast_module.SwitchRouteDecl,
                ),
            ):
                continue
            if control_flow_module.is_reserved_node_id(statement.id):
                self._raise(
                    f"Node id '{statement.id}' is a reserved control flow target.",
                    statement.location,
                )
            if statement.id in node_ids:
                self._raise(f"Duplicate node id: {statement.id}", statement.location)
            node_ids.add(statement.id)
        return node_ids

    def _context_sets(self, ast: ast_module.WorkflowAst) -> dict[str, ast_module.ContextSetDecl]:
        context_sets: dict[str, ast_module.ContextSetDecl] = {}
        for statement in ast.statements:
            if not isinstance(statement, ast_module.ContextSetDecl):
                continue
            if statement.name in context_sets:
                self._raise(f"Duplicate context set: {statement.name}", statement.location)
            context_sets[statement.name] = statement
        return context_sets

    def _validate_context_set_extends(
        self,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> None:
        for name, context_set in context_sets.items():
            for parent in context_set.extends:
                if parent not in context_sets:
                    self._raise(f"Unknown context set parent: {parent}", context_set.location)
            self._validate_context_set_cycle(name, context_sets, ())

    def _validate_context_set_cycle(
        self,
        name: str,
        context_sets: dict[str, ast_module.ContextSetDecl],
        stack: tuple[str, ...],
    ) -> None:
        if name in stack:
            chain = " -> ".join((*stack, name))
            self._raise(f"Context set inheritance cycle: {chain}", context_sets[name].location)
        for parent in context_sets[name].extends:
            if parent not in context_sets:
                continue
            self._validate_context_set_cycle(parent, context_sets, (*stack, name))

    def _flow_aliases(self, ast: ast_module.WorkflowAst, node_ids: set[str]) -> set[str]:
        aliases: set[str] = set()
        for statement in ast.statements:
            if not isinstance(statement, ast_module.FlowDecl) or statement.name is None:
                continue
            if statement.name in node_ids:
                self._raise(f"Flow name collides with node id: {statement.name}", statement.location)
            if statement.name in aliases:
                self._raise(f"Duplicate flow name: {statement.name}", statement.location)
            aliases.add(statement.name)
        return aliases

    def _validate_runtime_capabilities(self, ast: ast_module.WorkflowAst) -> None:
        for capability in (
            "exec.run_python",
            "exec.run_tool",
            "exec.codex_prompt",
            "flow.handoff",
            "flow.handoff_files",
            "flow.human_approval",
            "flow.human_choice",
            "flow.human_review",
            "flow.run_workflow",
            "flow.switch",
            "subgraph.agent_loop",
            "subgraph.react",
            "subgraph.parallel",
            "subgraph.workflow",
            "subgraph.validation_sandbox",
        ):
            self._validate_capability(capability, ast.location)

    def _validate_sandbox(self, sandbox: ast_module.SandboxDecl | None) -> None:
        sandbox_statement_module.validate_sandbox(self, sandbox)

    def _validate_patterns(
        self,
        patterns: list[str],
        label: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> None:
        for pattern in patterns:
            self._validate_relative_path(pattern, label, location)

    def _validate_relative_path(
        self,
        raw_path: str,
        label: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> None:
        path_text = raw_path.replace("\\", "/")
        path = pathlib.PurePosixPath(path_text)
        windows_path = pathlib.PureWindowsPath(raw_path)
        if path.is_absolute() or windows_path.is_absolute() or windows_path.drive:
            self._raise(f"{label} must be relative.", location)
        if ".." in path.parts:
            self._raise(f"{label} must not contain '..'.", location)

    def _validate_react_context_refs(
        self,
        react: ast_module.ReactDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> None:
        react_statement_module.validate_react_context_refs(self, react, context_sets)

    def _validate_agent_loop(
        self,
        loop: ast_module.AgentLoopDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> None:
        agent_loop_statement_module.validate_agent_loop(self, loop, context_sets)

    def _validate_statement_contract(self, statement: ast_module.StatementDecl) -> None:
        contract = getattr(statement, "contract", None)
        if contract is None:
            return
        for resource in [*contract.reads_resources, *contract.writes_resources]:
            self._validate_relative_path(resource.path, "CONTRACT resource path", resource.location)

    def _validate_parallel(
        self,
        parallel: ast_module.ParallelDecl,
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> None:
        parallel_statement_module.validate_parallel(self, parallel, context_sets)

    def _validate_tool(self, tool: ast_module.ToolDecl) -> None:
        try:
            tool_catalog_module.validate_public_tool_options(tool.tool_name, tool.options)
        except tool_catalog_module.ToolCatalogError as exc:
            self._raise(
                str(exc),
                tool.location,
                code=exc.code,
                suggestion="Use a public tool and provide OPTIONS that match its catalog schema.",
            )

    def _validate_context_refs(
        self,
        contexts: list[ast_module.ContextRef],
        context_sets: dict[str, ast_module.ContextSetDecl],
    ) -> None:
        for context in contexts:
            if context.context_set is not None and context.context_set not in context_sets:
                self._raise(f"Unknown context set: {context.context_set}", context.location)

    def _validate_capability(
        self,
        capability: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> None:
        if self.catalog.has_capability(capability):
            return
        suggestion = self.catalog.suggest_capability(capability)
        message = f"Unknown capability: {capability}"
        if suggestion:
            message = f"{message}. Did you mean '{suggestion}'?"
        self._raise(message, location)

    def _validate_node_ref(
        self,
        node_id: str,
        node_ids: set[str],
        label: str,
        location: diagnostics_module.SourceLocation | None,
    ) -> None:
        if node_id in node_ids:
            return
        self._raise(f"Unknown {label} node: {node_id}", location)

    def _raise(
        self,
        message: str,
        location: diagnostics_module.SourceLocation | None,
        *,
        code: str = "LGWF_DSL_ERROR",
        suggestion: str | None = None,
    ) -> None:
        raise errors_module.DSLValidationError(
            message,
            location,
            code=code,
            suggestion=suggestion,
        )
