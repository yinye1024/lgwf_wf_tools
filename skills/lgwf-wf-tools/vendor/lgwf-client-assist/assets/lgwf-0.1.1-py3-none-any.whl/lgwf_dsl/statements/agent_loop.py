from typing import Any

import lgwf_dsl.ast as ast_module


def lower_agent_loop(
    lowerer: Any,
    loop: ast_module.AgentLoopDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> dict[str, Any]:
    loop_context_refs = lowerer._lower_context_refs(loop.contexts, context_sets)
    config: dict[str, Any] = {
        "max_iterations": loop.max_iterations,
        "artifacts_path": loop.artifacts_path,
        "status_path": lowerer._state_path_or_default(loop.status_path, "agent_loop.{node}.status", loop.id),
        "report_path": lowerer._state_path_or_default(loop.report_path, "agent_loop.{node}.report", loop.id),
        "target_dirs_path": "targets.dirs",
        "target_files_path": "targets.files",
        "goal": loop.goal,
        "slot_order": list(loop.slot_order),
        "on_max": loop.on_max,
        "on_error": loop.on_error,
        "token_max": loop.token_max,
    }
    lowerer._attach_contract(config, loop.contract)
    with lowerer._instruction_path_scope(loop.id):
        for slot_name in loop.slot_order:
            lowered = lower_agent_loop_slot_task(
                lowerer,
                loop.slots[slot_name].task,
                defaults,
                context_sets,
                loop_context_refs,
            )
            slot_data = {"capability": lowered["capability"]}
            if lowered.get("config"):
                slot_data["config"] = lowered["config"]
            config[slot_name] = slot_data
    return {
        "id": loop.id,
        "capability": "subgraph.agent_loop",
        "config": config,
    }


def lower_agent_loop_slot_task(
    lowerer: Any,
    task: ast_module.PythonDecl | ast_module.ToolDecl | ast_module.CodexDecl | ast_module.WorkflowRefDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
    loop_context_refs: list[dict[str, str]],
) -> dict[str, Any]:
    if isinstance(task, ast_module.PythonDecl):
        return lowerer._lower_python(task, defaults)
    if isinstance(task, ast_module.ToolDecl):
        return lowerer._lower_tool(task, defaults)
    if isinstance(task, ast_module.WorkflowRefDecl):
        return lowerer._lower_workflow_ref(task)

    lowered = lowerer._lower_codex(task, defaults, context_sets)
    config = dict(lowered.get("config", {}))
    slot_context_refs = list(config.get("context_refs", []))
    config["context_refs"] = [*loop_context_refs, *slot_context_refs]
    config["target_dirs_path"] = "targets.dirs"
    config["target_files_path"] = "targets.files"
    return {
        "id": lowered["id"],
        "capability": lowered["capability"],
        "config": config,
    }


def validate_agent_loop(
    validator: Any,
    loop: ast_module.AgentLoopDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> None:
    validator._validate_relative_path(loop.artifacts_path, "AGENT_LOOP ARTIFACTS", loop.location)
    validator._validate_context_refs(loop.contexts, context_sets)
    for slot in loop.slots.values():
        if isinstance(slot.task, ast_module.CodexDecl):
            validator._validate_context_refs(slot.task.contexts, context_sets)
        elif isinstance(slot.task, ast_module.ToolDecl):
            validator._validate_tool(slot.task)
        elif isinstance(slot.task, ast_module.WorkflowRefDecl) and slot.task.result_path is None:
            validator._raise("AGENT_LOOP WORKFLOW requires RESULT state.*.", slot.task.location)
