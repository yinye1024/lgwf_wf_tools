from typing import Any

import lgwf_dsl.ast as ast_module


def lower_parallel(
    lowerer: Any,
    parallel: ast_module.ParallelDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> dict[str, Any]:
    with lowerer._instruction_path_scope(parallel.id):
        steps = [
            lower_parallel_step(lowerer, step, defaults, context_sets)
            for step in parallel.steps
        ]
    config: dict[str, Any] = {
        "steps": steps
    }
    if parallel.max_concurrency is not None:
        config["max_concurrency"] = parallel.max_concurrency
    if parallel.fail_strategy is not None:
        config["fail_strategy"] = parallel.fail_strategy
    return {
        "id": parallel.id,
        "capability": "subgraph.parallel",
        "config": config,
    }


def lower_parallel_step(
    lowerer: Any,
    step: ast_module.ParallelStepDecl,
    defaults: ast_module.DefaultsDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> dict[str, Any]:
    if isinstance(step.task, ast_module.PythonDecl):
        lowered = lowerer._lower_python(step.task, defaults)
    elif isinstance(step.task, ast_module.ToolDecl):
        lowered = lowerer._lower_tool(step.task, defaults)
    elif isinstance(step.task, ast_module.CodexDecl):
        lowered = lowerer._lower_codex(step.task, defaults, context_sets)
    else:
        if isinstance(step.task, ast_module.WorkflowRefDecl):
            lowered = lowerer._lower_workflow_ref(step.task)
        else:
            lowered = lowerer._lower_react(step.task, defaults, context_sets)

    result = {
        "id": step.id,
        "capability": lowered["capability"],
        "output_path": step.output_path.path,
        "result_path": step.result_path.path,
    }
    if lowered.get("config"):
        result["config"] = lowered["config"]
    return result


def validate_parallel(
    validator: Any,
    parallel: ast_module.ParallelDecl,
    context_sets: dict[str, ast_module.ContextSetDecl],
) -> None:
    step_ids: set[str] = set()
    result_paths: set[str] = set()
    for step in parallel.steps:
        if step.id in step_ids:
            validator._raise(f"Duplicate PARALLEL step id: {step.id}", step.location)
        step_ids.add(step.id)
        if step.result_path.path in result_paths:
            validator._raise(f"Duplicate PARALLEL result path: {step.result_path.path}", step.location)
        result_paths.add(step.result_path.path)
        if isinstance(step.task, ast_module.CodexDecl):
            validator._validate_context_refs(step.task.contexts, context_sets)
        elif isinstance(step.task, ast_module.ToolDecl):
            validator._validate_tool(step.task)
        elif isinstance(step.task, ast_module.ReactDecl):
            validator._validate_react_context_refs(step.task, context_sets)
